﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TomSharpControls;
using SharpMap;


namespace SharpMapTT
{
    public partial class FormTest : Form
    {

        private MapLegend mapLegend1;

        //private static readonly Dictionary<string, Type> MapDecorationTypes = new Dictionary<string, Type>();
        //private static bool AddToListView;

        public FormTest()
        {
            InitializeComponent();

            mapLegend1 = new MapLegend();

            mapLegend1.MapControl = mapBox1;

            mapLegend1.Dock = DockStyle.Top;

            splitContainer1.Panel1.Controls.Add(mapLegend1);

            //(new TomSharpControls.FormMapProperites()).ShowDialog();

            //Application.Exit();




            //if (false)
            //{
            //    GdalConfiguration.ConfigureGdal();
            //    GdalConfiguration.ConfigureOgr();


            //    int NDriveGDal = OSGeo.GDAL.Gdal.GetDriverCount();

            //    List<string> drvsGDal = new List<string>();

            //    for (int i = 0; i < NDriveGDal; i++)
            //    {
            //        OSGeo.GDAL.Driver d = OSGeo.GDAL.Gdal.GetDriver(i);

            //        drvsGDal.Add(d.ShortName + " " + d.LongName + "\r\n\r\n\t" + d.GetMetadata("").Aggregate((a, b) => a + "\r\n\t" + b) + "\r\n\r\n");
            //    }

            //    drvsGDal.Sort();
            //    drvsGDal.Insert(0, "GDAL:\r\n");

            //    drvsGDal.Add("\r\nOGR:\r\n");

            //    int NDriveOGR = OSGeo.OGR.Ogr.GetDriverCount();

            //    for (int i = 0; i < NDriveOGR; i++)
            //    {
            //        OSGeo.OGR.Driver d = OSGeo.OGR.Ogr.GetDriver(i);

            //        drvsGDal.Add(d.name + " " + "\r\n");
            //    }


            //    Form1 f = new Form1();
            //    f.textBox1.Lines = drvsGDal.ToArray();

            //    f.Show();
            //}
            ////MessageBox.Show(drvsGDal.Aggregate((a, b) => a + "\r\n" + b + "\r\n\r\n"));
        }

    
      
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            mapLegend1.AddFolder();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //mapLegend1.AddFile();
        }

        private void databaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To do");
        }

        private void serviceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To do");
        }

        private void FormTest_Load(object sender, EventArgs e)
        {

            //mapLegend1.AddFile(@"c:\Data\confine_bacini_pc2.Shp");
            //mapLegend1.AddFile(@"c:\Data\confine_idrografia_pc2.Shp");
            //mapLegend1.AddFile(@"c:\Data\250000u4.tif");
            //mapLegend1.AddFile(@"c:\Data\comuni_es32.shp");

            //mapBox1.Map.ZoomToExtents();

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            mapLegend1.CreateFromMap();
        }

        private void vectorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mapLegend1.AddVector();
        }

        private void rasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mapLegend1.AddRaster();
        }
    }
}
