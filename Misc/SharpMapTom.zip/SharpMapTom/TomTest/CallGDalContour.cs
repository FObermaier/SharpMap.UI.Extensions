﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpMapTT
{
    class CallGDalContour
    {

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    const string relativePath = @"C:\temp\TestSM\TestSM\GeoData\";

        //    ////SharpMap.Layers.GdalRasterLayer layer = new SharpMap.Layers.GdalRasterLayer("GeoTiff", relativePath + "GeoTiff\\utm.tif");
        //    //SharpMap.Layers.GdalRasterLayer layer = new SharpMap.Layers.GdalRasterLayer("GeoTiff", relativePath + "DEM\\Golden_CO.dem");


        //    //mapBox1.Map.Layers.Add(layer);

        //    //mapBox1.Map.ZoomToExtents();
        //    //mapBox1.Invalidate();
        //    //mapBox1.Refresh();

        //    GdalConfiguration.ConfigureGdal();
        //    GdalConfiguration.ConfigureOgr();



        //    //OSGeo.GDAL.Gdal.AllRegister();

        //    if (File.Exists("C:\\temp\\contour.shp")) File.Delete("C:\\temp\\contour.shp");
        //    if (File.Exists("C:\\temp\\contour.shx")) File.Delete("C:\\temp\\contour.shx");
        //    if (File.Exists("C:\\temp\\contour.dbf")) File.Delete("C:\\temp\\contour.dbf");
        //    if (File.Exists("C:\\temp\\contour.prj")) File.Delete("C:\\temp\\contour.prj");

        //    OSGeo.GDAL.Dataset ds = OSGeo.GDAL.Gdal.Open(relativePath + "DEM\\Golden_CO.dem", OSGeo.GDAL.Access.GA_ReadOnly);

        //    string[] opt = new string[0];

        //    OSGeo.OGR.DataSource ogr_ds = OSGeo.OGR.Ogr.GetDriverByName("Esri Shapefile").CreateDataSource("C:\\temp\\contour.shp", opt);

        //    string wkt = "GEOGCS[\"WGS 84\",DATUM[\"WGS_1984\",SPHEROID[\"WGS 84\",6378137,298.257223563,AUTHORITY[\"EPSG\",\"7030\"]],AUTHORITY[\"EPSG\",\"6326\"]],PRIMEM[\"Greenwich\",0,AUTHORITY[\"EPSG\",\"8901\"]],UNIT[\"degree\",0.0174532925199433,AUTHORITY[\"EPSG\",\"9108\"]],AUTHORITY[\"EPSG\",\"4326\"]]";
        //    OSGeo.OSR.SpatialReference sr = new OSGeo.OSR.SpatialReference(wkt);


        //    OSGeo.OGR.Layer ogr_lyr = ogr_ds.CreateLayer("contour", sr, OSGeo.OGR.wkbGeometryType.wkbLineString25D, opt);
        //    ogr_lyr.CreateField(new OSGeo.OGR.FieldDefn("ID", OSGeo.OGR.FieldType.OFTInteger), 0);
        //    ogr_lyr.CreateField(new OSGeo.OGR.FieldDefn("elev", OSGeo.OGR.FieldType.OFTReal), 0);


        //    OSGeo.GDAL.Gdal.GDALProgressFuncDelegate prg = Progress;

        //    //double[] q = new double[] { 5000, 5500, 6000, 7000, 8000 };
        //    double[] q = new double[] { 5000, 5100, 5200, 5300, 5400, 5500, 5600, 5700, 5800, 5900, 6000, 6100, 6200, 6300, 6400, 6500, 6600 };

        //    unsafe
        //    {
        //        fixed (double* pq = q)
        //        {

        //            IntPtr ptr = new IntPtr(pq);


        //            OSGeo.GDAL.SWIGTYPE_p_double x = new OSGeo.GDAL.SWIGTYPE_p_double(ptr, true, this);



        //            string cb = new string(' ', 255);
        //            //OSGeo.GDAL.Gdal.ContourGenerate(ds.GetRasterBand(1), 100, 0, 30, x, 1, -9999, ogr_lyr, 0, 1, Progress, cb);
        //            //OSGeo.GDAL.Gdal.ContourGenerate(ds.GetRasterBand(1), 100, 0, 30, x, 1, -32767, ogr_lyr, 0, 1, Progress, cb);
        //            OSGeo.GDAL.Gdal.ContourGenerate(ds.GetRasterBand(1), 100, 0, 30, x, 1, -32767, ogr_lyr, 0, 1, Progress, cb);
        //            MessageBox.Show("Fatto");
        //        }
        //    }

        //}





    }
}
