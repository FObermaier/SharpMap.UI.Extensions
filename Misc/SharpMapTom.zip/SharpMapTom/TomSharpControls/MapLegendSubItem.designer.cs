﻿namespace TomSharpControls
{
    partial class MapLegendSubItem
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.checkBox = new System.Windows.Forms.CheckBox();
            this.panelText = new System.Windows.Forms.Panel();
            this.label = new System.Windows.Forms.Label();
            this.panelText.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.Transparent;
            this.panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel.Location = new System.Drawing.Point(17, 2);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(25, 20);
            this.panel.TabIndex = 1;
            this.panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.panel.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDoubleClick);
            this.panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // checkBox
            // 
            this.checkBox.AutoSize = true;
            this.checkBox.BackColor = System.Drawing.Color.Transparent;
            this.checkBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkBox.Location = new System.Drawing.Point(2, 2);
            this.checkBox.Name = "checkBox";
            this.checkBox.Size = new System.Drawing.Size(15, 20);
            this.checkBox.TabIndex = 2;
            this.checkBox.UseVisualStyleBackColor = false;
            this.checkBox.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            this.checkBox.Click += new System.EventHandler(this.checkBox_Click);
            // 
            // panelText
            // 
            this.panelText.Controls.Add(this.label);
            this.panelText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelText.Location = new System.Drawing.Point(42, 2);
            this.panelText.Name = "panelText";
            this.panelText.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.panelText.Size = new System.Drawing.Size(106, 20);
            this.panelText.TabIndex = 3;
            // 
            // label
            // 
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label.Location = new System.Drawing.Point(3, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(103, 20);
            this.label.TabIndex = 2;
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.label.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.label.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.label.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // MapLegendSubItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.panelText);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.checkBox);
            this.DoubleBuffered = true;
            this.Name = "MapLegendSubItem";
            this.Padding = new System.Windows.Forms.Padding(2);
            this.Size = new System.Drawing.Size(150, 24);
            this.panelText.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.CheckBox checkBox;
        private System.Windows.Forms.Panel panelText;
        private System.Windows.Forms.Label label;
    }
}
