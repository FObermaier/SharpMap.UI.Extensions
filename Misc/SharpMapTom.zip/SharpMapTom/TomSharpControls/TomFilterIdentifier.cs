﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace TomSharpControls
{
    public enum TomFilterType
    {
        File,
        Folder,
        DataBase,
        Protocol        
    }

    public class TomFilterIdentifier
    {
        public TomFilterType FilterType;
        public string Name;
        public string Description;
        public string FileExtensions;

        public TomFilterIdentifier()
        {

                    }

        public TomFilterIdentifier(TomFilterType filterType, string name, string description, string fileExtension)
        {
            FilterType = filterType;
            Name = name;
            Description = description;
            FileExtensions = fileExtension;
        }

        public string Filter
        {
            get
            {
                return Description + "|" + FileExtensions;
            }
        }

    }

    public class TomFilterList : List<TomFilterIdentifier>
    {
        public void InitializeRaster()
        {

            SharpMap.GdalConfiguration.ConfigureGdal();

            int NDriveGDal = OSGeo.GDAL.Gdal.GetDriverCount();

            //List<string> drvsGDal = new List<string>();

            for (int i = 0; i < NDriveGDal; i++)
            {
                OSGeo.GDAL.Driver d = OSGeo.GDAL.Gdal.GetDriver(i);

                string Description = d.GetDescription() + " " + d.LongName;
                string Name = "GDAL." + d.ShortName;
                string ext = d.GetMetadataItem("DMD_EXTENSION", "");

                if (ext != null & ext != "")
                {
                    Add(new TomFilterIdentifier(TomFilterType.File, Name, Description + " (*." + ext + ")", "*."+ext));
                }
                else
                {
                    Add(new TomFilterIdentifier(TomFilterType.Folder, Name, Description, ext));
                }

                //drvsGDal.Add(d.ShortName + " " + d.LongName + "\r\n\r\n\t" + d.GetMetadata("").Aggregate((a, b) => a + "\r\n\t" + b) + "\r\n\r\n");
            }

        }

        public void InitializeVector()
        {

            Add(new TomFilterIdentifier(TomFilterType.File, "SharpMap.shapefile", "Esri shapefile (*.shp)", "*.shp"));
            Add(new TomFilterIdentifier(TomFilterType.File, "OGR.MapInfo", "MapInfo File (*.tab)", "*.tab"));
            Add(new TomFilterIdentifier(TomFilterType.File, "OGR.KML", "Keyhole Markup Language (*.kml)", "*.kml"));
            Add(new TomFilterIdentifier(TomFilterType.File, "OGR.DXF", "AutoDESK Drawing Interchange Format (*.dxf)", "*.dxf"));
            Add(new TomFilterIdentifier(TomFilterType.File, "OGR.GPX", "GPS eXchange Format (*.gpx)", "*.gpx"));
            Add(new TomFilterIdentifier(TomFilterType.Folder, "OGR.AVCBin", "ArcInfo Vector coverage (foolder)", ""));


        }


    }
}
