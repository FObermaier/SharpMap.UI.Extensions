﻿namespace TomSharpControls
{
    partial class FormFillStyle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageLine = new System.Windows.Forms.TabPage();
            this.tomPenEditor1 = new TomControls.TomPenEditor();
            this.tabPageFill = new System.Windows.Forms.TabPage();
            this.tomHatchBrush1 = new TomControls.TomHatchBrush();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPageLine.SuspendLayout();
            this.tabPageFill.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPageFill);
            this.tabControl.Controls.Add(this.tabPageLine);
            this.tabControl.Location = new System.Drawing.Point(12, 9);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(477, 296);
            this.tabControl.TabIndex = 7;
            // 
            // tabPageLine
            // 
            this.tabPageLine.Controls.Add(this.tomPenEditor1);
            this.tabPageLine.Location = new System.Drawing.Point(4, 22);
            this.tabPageLine.Name = "tabPageLine";
            this.tabPageLine.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLine.Size = new System.Drawing.Size(469, 270);
            this.tabPageLine.TabIndex = 1;
            this.tabPageLine.Text = "Line";
            this.tabPageLine.UseVisualStyleBackColor = true;
            // 
            // tomPenEditor1
            // 
            this.tomPenEditor1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomPenEditor1.GraphicsUnit = System.Drawing.GraphicsUnit.Pixel;
            this.tomPenEditor1.Location = new System.Drawing.Point(3, 3);
            this.tomPenEditor1.Name = "tomPenEditor1";
            this.tomPenEditor1.Size = new System.Drawing.Size(463, 264);
            this.tomPenEditor1.TabIndex = 0;
            // 
            // tabPageFill
            // 
            this.tabPageFill.Controls.Add(this.label1);
            this.tabPageFill.Controls.Add(this.comboBox1);
            this.tabPageFill.Controls.Add(this.tomHatchBrush1);
            this.tabPageFill.Location = new System.Drawing.Point(4, 22);
            this.tabPageFill.Name = "tabPageFill";
            this.tabPageFill.Size = new System.Drawing.Size(469, 270);
            this.tabPageFill.TabIndex = 2;
            this.tabPageFill.Text = "Fill";
            this.tabPageFill.UseVisualStyleBackColor = true;
            // 
            // tomHatchBrush1
            // 
            this.tomHatchBrush1.Location = new System.Drawing.Point(6, 58);
            this.tomHatchBrush1.Name = "tomHatchBrush1";
            this.tomHatchBrush1.Size = new System.Drawing.Size(456, 209);
            this.tomHatchBrush1.TabIndex = 1;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Hatch",
            "Bitmap"});
            this.comboBox1.Location = new System.Drawing.Point(42, 12);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(205, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Style:";
            // 
            // FormFillStyle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 337);
            this.Controls.Add(this.tabControl);
            this.Name = "FormFillStyle";
            this.Text = "Form1";
            this.tabControl.ResumeLayout(false);
            this.tabPageLine.ResumeLayout(false);
            this.tabPageFill.ResumeLayout(false);
            this.tabPageFill.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageFill;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private TomControls.TomHatchBrush tomHatchBrush1;
        private System.Windows.Forms.TabPage tabPageLine;
        private TomControls.TomPenEditor tomPenEditor1;

    }
}