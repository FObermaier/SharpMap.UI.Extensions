﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace TomSharpControls
{
    public partial class FormVectorStyleEditor : Form
    {
        public FormVectorStyleEditor()
        {
            InitializeComponent();
        }

        private void tomFontComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        
    }
}
