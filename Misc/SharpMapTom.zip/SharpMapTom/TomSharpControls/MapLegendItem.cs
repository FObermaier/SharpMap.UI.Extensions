﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using SharpMap.Layers;
using SharpMap;
using TomSharpControls.Properties;
using GeoAPI.Geometries;
using SharpMap.Data;
using SharpMap.Data.Providers;
using System.Collections.ObjectModel;

namespace TomSharpControls
{
    public enum LegendType
    {
        None = 0,
        Point = 1,
        Line = 2,
        Polygon = 3,
        Raster = 4
    }

    public partial class MapLegendItem : UserControl
    {
        public List<LegendType> LegendTypes
        {
            get;
            set;
        }
     
        public bool ExpandedCollpaseVisible
        {
            get
            {
                return panelExpander.Visible;
            }
            set
            {
                panelExpander.Visible = value;
            }

        }

        private bool _expanded = true;
        public bool Expanded
        {
            get
            {
                return _expanded;
            }
            set
            {
                _expanded = value;

                if (_expanded)
                {
                    pictureBox.Image = Resources.minus;
                    panel.Visible = true;  
                }
                else
                {
                    pictureBox.Image = Resources.plus;
                    panel.Visible = false;
                }

                ComputeHeight();
            }


        }

        public bool CheckVisible
        {
            get
            {
                return panelCheck.Visible;
            }
            set
            {
                panelCheck.Visible = value;
            }
        }

        public bool IconVisible
        {
            get
            {
                return pictureBoxIcon.Visible;
            }
            set
            {
                pictureBoxIcon.Visible = value;
            }
        }

        public Image Icon
        {
            get
            {
                return pictureBoxIcon.Image;
            }
            set
            {
                pictureBoxIcon.Image = value;
            }
        }

        private bool _Selected = false;
        public bool Selected
        {
            get
            {
                return _Selected;
            }
            set
            {
                _Selected = value;

                if (_Selected)
                {
                    label.BackColor = SystemColors.Highlight;
                    label.ForeColor = SystemColors.HighlightText;
                }
                else
                {
                    label.BackColor = Color.Transparent;
                    label.ForeColor = SystemColors.ControlText;
                }

            }
        }

        public string PathName
        {
            get
            {
                if(ParentItem != null)
                {
                    return ParentItem.PathName + "/" + Text;
                }

                return Text;
            }
           
        }

        private MapLegendItem _parentitem = null;
        public MapLegendItem ParentItem
        {
            get
            {
                return _parentitem;
            }
            protected set
            {
                _parentitem = value;
            }
        }

        public Control.ControlCollection ChildItems
        {
            get
            {
                return panel.Controls;
            }
        }

        public MapLegendItem()
        {
            InitializeComponent();
            Initialize();

            ComputeHeight();
        }

        public MapLegendItem(Map map, MapLegendItem parent, string mapname)
        {
            InitializeComponent();
            Initialize();

            _parentitem = parent;

            label.Text = mapname;

            CheckVisible = false;

            Icon = Resources.map16;
            IconVisible = true;

            foreach (ILayer l in map.Layers)
            {
                AddControl(new MapLegendItem(l, this));
            }

            _object = map;

            ComputeHeight();
        }

        public MapLegendItem(ILayer layer, MapLegendItem parent)
        {
            _object = layer;

            InitializeComponent();
            Initialize();

            _parentitem = parent;

            label.Text = layer.LayerName;

            if (layer is LayerGroup)
            {
                LayerGroup lg = (LayerGroup)layer;

                Icon = Resources.folder;
                IconVisible = true;

                foreach (ILayer l in lg.Layers)
                {
                    AddControl(new MapLegendItem(l, this));
                }

                checkBox.Checked = lg.Enabled;

            }
            else
            {
                checkBox.Checked = layer.Enabled;

                CreateSubItems(layer);
            }

            ComputeHeight();

        }


        private void CreateSubItems(VectorLayer layer)
        {
            if (layer.DataSource is ShapeFile)
            {
                switch ((layer.DataSource as ShapeFile).ShapeType)
                {
                    case (ShapeType.Point):
                    case (ShapeType.PointM):
                    case (ShapeType.PointZ):
                    case (ShapeType.Multipoint): // Multipoint Not MultiPoint ?
                    case (ShapeType.MultiPointM):
                    case (ShapeType.MultiPointZ):
                        {
                            LegendTypes.Add(LegendType.Point);
                        }
                        break;
                    case (ShapeType.PolyLine):
                    case (ShapeType.PolyLineM):
                    case (ShapeType.PolyLineZ):
                        {
                            LegendTypes.Add(LegendType.Line);
                        }
                        break;
                    case (ShapeType.Polygon):
                    case (ShapeType.PolygonM):
                    case (ShapeType.PolygonZ):
                        {
                            LegendTypes.Add(LegendType.Polygon);
                        }
                        break;
                }
            }

            if (layer.DataSource is Ogr)
            {
                Ogr ogr = layer.DataSource as Ogr;

                int lays = ogr.NumberOfLayers;

                if(ogr.OgrGeometryTypeString.Contains("wkbPoint"))
                {
                    LegendTypes.Add(LegendType.Point);
                }
                
                if(ogr.OgrGeometryTypeString.Contains("wkbLineString"))
                {
                    LegendTypes.Add(LegendType.Line);
                }
                        
                if(ogr.OgrGeometryTypeString.Contains("wkbPolygon"))
                {
                    LegendTypes.Add(LegendType.Polygon);
                }
             
            }

            if (layer.Themes == null)
            {
                MapLegendSubItem SubItem = new MapLegendSubItem(this, LegendTypes, layer.Style, "");

                SubItem.SubItemChanged += new MapLegendSubItem.OnSubItemChanged(SubItem_StyleChanged);

                AddControl(SubItem);
            }

        }

        private void CreateSubItems(GdalRasterLayer layer)
        {
            LegendTypes.Add(LegendType.Raster);

            MapLegendSubItem SubItem = new MapLegendSubItem(this, LegendTypes, null, "");

            SubItem.SubItemChanged += new MapLegendSubItem.OnSubItemChanged(SubItem_StyleChanged);

            AddControl(SubItem);
        }

        private void CreateSubItems(ILayer layer)
        {
            if (layer is VectorLayer)
            {
                CreateSubItems(layer as VectorLayer);
            }

            if (layer is GdalRasterLayer)
            {
                CreateSubItems(layer as GdalRasterLayer);
            }
        }


        void SubItem_StyleChanged()
        {
            if (LayerChanged != null)
            {
                LayerChanged(this);
            }
        }

        private void Initialize()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);

            LegendTypes = new List<LegendType>();
        }
        
        private object _object = null;
        public object Object
        {
            get
            {
                return _object;
            }
        }

        public Layer asLayer
        {
            get
            {
                if (_object is Layer) 
                    return _object as Layer;

                throw new Exception("Object is not a Layer");
            }
        }

        public LayerGroup asLayergroup
        {
            get
            {
                if (_object is LayerGroup)
                    return _object as LayerGroup;

                throw new Exception("Object is not a LayerGroup");
            }
        }

        public Map asMap
        {
            get
            {
                if (_object is Map)
                    return _object as Map;

                throw new Exception("Object is not a Map");
            }
        }

        public new string Text
        {
            get
            {
                return label.Text;
            }
            set
            {
                label.Text = value;
            }
        }

        public void Highlight(bool highlight)
        {
            if (highlight)
            {
                if (panelLabel.BackColor != SystemColors.ButtonHighlight)
                {
                    panelLabel.BackColor = SystemColors.ButtonHighlight;
                }

                if (panelLabel.BorderStyle != BorderStyle.FixedSingle)
                {
                    panelLabel.BorderStyle = BorderStyle.FixedSingle;
                }
            }
            else
            {
                if (panelLabel.BackColor != Color.Transparent)
                {
                    panelLabel.BackColor = Color.Transparent;
                }

                if (panelLabel.BorderStyle != BorderStyle.None)
                {
                    panelLabel.BorderStyle = BorderStyle.None;
                }
            }
        }

        public delegate void OnLayerChanged(MapLegendItem item);
        public event OnLayerChanged LayerChanged;

        public List<MapLegendItem> GetAllItems()
        {
            List<MapLegendItem> lst = new List<MapLegendItem>();

            GetAllItems(ref lst);

            return lst;
        }

        private void GetAllItems(ref List<MapLegendItem> list)
        {

            list.Add(this);

            foreach (Control c in panel.Controls)
            {
                if (c is MapLegendItem)
                {
                    (c as MapLegendItem).GetAllItems(ref list);
                }
            }

        }

        public List<string> GetSelectedItems()
        {
            List<string> SelItems = new List<string>();
            
            if(Selected) 
            {
                SelItems.Add(PathName);
            }
            else
            {
                foreach(Control c in panel.Controls)
                {
                    if (c is MapLegendItem)
                    {
                        ((MapLegendItem)c).GetSelectedItems(PathName, ref SelItems);
                    }
                }
            }

            return SelItems;
        }
        private void GetSelectedItems(string path, ref List<string> SelItems)
        {
            if (Selected)
            {
                SelItems.Add(path + "/" + Text);
            }
            else
            {
               foreach(Control c in panel.Controls)
                {
                    if (c is MapLegendItem)
                    {
                        ((MapLegendItem)c).GetSelectedItems(PathName, ref SelItems);
                    }
                }
            }
        }

        public MapLegendItem GetItem(string path)
        {
                if (path == Text)
                {
                    return this;
                }
                
                if(path.Substring(0,Text.Length) == Text)
                {
                    int numchar = path.Length-Text.Length+1;
                    
                    string subPath = path.Substring(path.Length-numchar, numchar);

                    foreach (MapLegendItem itm in panel.Controls)
                    {
                       return itm.GetItem(subPath);
                    }

                }
                

            return null;
        }

        public MapLegendItem AddItem(ILayer layer)
        {
            MapLegendItem item = new MapLegendItem(layer, this);
            
            AddControl(item);

            return item;
        }

        public MapLegendItem AddItem(Map map, string mapname)
        {
            MapLegendItem item = new MapLegendItem(map, this, mapname);
            AddControl(item);

            return item;
        }
               
        public void AddControl(Control item)
        {
            
            if (item.Parent != null) item.Parent = null;
            

            item.Dock = DockStyle.Top;

            if (item is MapLegendItem)
            {
                MapLegendItem itm = item as MapLegendItem;

                itm.ParentItem = this;

                itm.ItemMouseDown += new OnItemMouseDown(control_MouseDown);
                itm.ItemMouseUp += new OnItemMouseUp(control_MouseUp);
                itm.ItemMouseClick += new OnItemMouseClick(control_MouseClick);
                itm.ItemMouseMove += new OnItemMouseMove(control_MouseMove);
                //itm.ItemMouseEnter += new OnItemMouseEnter(control_MouseEnter);
                //itm.ItemMouseLeave += new OnItemMouseLeave(control_MouseLeave);


            }

            if (item is MapLegendSubItem)
            {
                MapLegendSubItem StyleEditor = item as MapLegendSubItem;

                StyleEditor.LegendStyleItemMouseDown += new MapLegendSubItem.OnLegendStyleItemMouseDown(control_MouseDown);
                StyleEditor.LegendStyleItemMouseUp += new MapLegendSubItem.OnLegendStyleItemMouseUp(control_MouseUp);
                StyleEditor.LegendStyleItemMouseClick += new MapLegendSubItem.OnLegendStyleItemMouseClick(control_MouseClick);
                StyleEditor.LegendStyleItemMouseMove += new MapLegendSubItem.OnLegendStyleItemMouseMove(control_MouseMove);
                //StyleEditor.LegendStyleItemMouseEnter += new MapLegendSubItem.OnLegendStyleItemMouseEnter(control_MouseEnter);
                //StyleEditor.LegendStyleItemMouseLeave += new MapLegendSubItem.OnLegendStyleItemMouseLeave(control_MouseLeave);
            }

            panel.Controls.Add(item);

            ComputeHeight();

        }
     
        public void ComputeHeight()
        {
            int height = pictureBox.Height + Padding.Top + Padding.Bottom;

            if (_expanded)
            {
                if (panel.Controls.Count > 0)
                {
                    foreach (Control itm in panel.Controls)
                    {
                        height += itm.Height;
                    }
                }
            }

            Height = height;

            if (ParentItem != null) ParentItem.ComputeHeight();
        }

        public Rectangle GetDropRectangle()
        {
            if(_object is Map | _object is LayerGroup | _object is LayerCollection)
            {
                return new Rectangle(panelLabel.Left, panelLabel.Top, panelLabel.Width, panelLabel.Height);
            }

            //if (_object is Layer)
            //{
            //    return new Rectangle(ClientRectangle.Left, ClientRectangle.Top + ClientRectangle.Height - 3, ClientRectangle.Width, 3);
            //}

            //return new Rectangle(ClientRectangle.Left, ClientRectangle.Top + ClientRectangle.Height - 3, ClientRectangle.Width, 3);
            return ClientRectangle;
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {
            Expanded = !Expanded;
        }

        public delegate void OnItemMouseClick(MapLegendItem sender, MouseEventArgs e);
        public event OnItemMouseClick ItemMouseClick;
        private void control_MouseClick(object sender, MouseEventArgs e)
        {
            if (sender is MapLegendItem)
            {
                if (ItemMouseClick != null)
                {
                    ItemMouseClick(sender as MapLegendItem, e);
                }
            }
            else
            {
                Point ps = ((Control)sender).PointToScreen(new Point(e.X, e.Y));

                MouseEventArgs ea = new MouseEventArgs(e.Button, e.Clicks, ps.X, ps.Y, e.Delta);

                if (ItemMouseClick != null)
                {
                    ItemMouseClick(this, ea);
                }
            }
        }

        public delegate void OnItemMouseDown(MapLegendItem sender, MouseEventArgs e);
        public event OnItemMouseDown ItemMouseDown;
        private void control_MouseDown(object sender, MouseEventArgs e)
        {
            if (sender is MapLegendItem)
            {
                if (ItemMouseDown != null)
                {
                    ItemMouseDown(sender as MapLegendItem, e);
                }
            }
            else
            {
                Point ps = ((Control)sender).PointToScreen(new Point(e.X, e.Y));

                MouseEventArgs ea = new MouseEventArgs(e.Button, e.Clicks, ps.X, ps.Y, e.Delta);

                if (ItemMouseDown != null)
                {
                    ItemMouseDown(this, ea);
                }
            }
        }

        public delegate void OnItemMouseUp(MapLegendItem sender, MouseEventArgs e);
        public event OnItemMouseUp ItemMouseUp;
        private void control_MouseUp(object sender, MouseEventArgs e)
        {

            if (sender is MapLegendItem)
            {
                if (ItemMouseUp != null)
                {
                    ItemMouseUp(sender as MapLegendItem, e);
                }
            }
            else
            {
                Point ps = ((Control)sender).PointToScreen(new Point(e.X, e.Y));

                MouseEventArgs ea = new MouseEventArgs(e.Button, e.Clicks, ps.X, ps.Y, e.Delta);

                if (ItemMouseUp != null)
                {
                    ItemMouseUp(this, ea);
                }
            }
        }


        public delegate void OnItemMouseMove(MapLegendItem sender, MouseEventArgs e);
        public event OnItemMouseMove ItemMouseMove;
        private void control_MouseMove(object sender, MouseEventArgs e)
        {

            if (sender is MapLegendItem)
            {
                if (ItemMouseMove != null)
                {
                    ItemMouseMove(sender as MapLegendItem, e);
                }
            }
            else
            {
                Point ps = ((Control)sender).PointToScreen(new Point(e.X, e.Y));

                MouseEventArgs ea = new MouseEventArgs(e.Button, e.Clicks, ps.X, ps.Y, e.Delta);

                if (ItemMouseMove != null)
                {
                    ItemMouseMove(this, ea);
                }
            }
        }

       
        private void checkBox_Click(object sender, EventArgs e)
        {
            (_object as Layer).Enabled = checkBox.Checked;

            if (LayerChanged != null)
            {
                LayerChanged(this);
            }
        }


        #region unused now
        //public delegate void OnItemMouseEnter(MapLegendItem sender, EventArgs e);
        //public event OnItemMouseEnter ItemMouseEnter;
        //private void control_MouseEnter(object sender, EventArgs e)
        //{
        //    if (ItemMouseEnter != null)
        //    {
        //        if (sender is MapLegendItem)
        //        {
        //            ItemMouseEnter((MapLegendItem)sender, e);
        //        }
        //        else
        //        {
        //            ItemMouseEnter(this, e);
        //        }
        //    }
        //}

        //public delegate void OnItemMouseLeave(MapLegendItem sender, EventArgs e);
        //public event OnItemMouseLeave ItemMouseLeave;
        //private void control_MouseLeave(object sender, EventArgs e)
        //{
        //    if (ItemMouseLeave != null)
        //    {
        //        if (sender is MapLegendItem)
        //        {
        //            ItemMouseLeave((MapLegendItem)sender, e);
        //        }
        //        else
        //        {
        //            ItemMouseLeave(this, e);
        //        }
        //    }

        //}                

        #endregion

    }
}
