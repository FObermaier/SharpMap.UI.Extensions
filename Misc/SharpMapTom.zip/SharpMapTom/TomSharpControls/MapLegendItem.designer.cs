﻿namespace TomSharpControls
{
    partial class MapLegendItem
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.panelExpander = new System.Windows.Forms.Panel();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.panelLabel = new System.Windows.Forms.Panel();
            this.label = new System.Windows.Forms.Label();
            this.pictureBoxIcon = new System.Windows.Forms.PictureBox();
            this.panelCheck = new System.Windows.Forms.Panel();
            this.checkBox = new System.Windows.Forms.CheckBox();
            this.panelExpander.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.panelLabel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIcon)).BeginInit();
            this.panelCheck.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.AutoSize = true;
            this.panel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel.BackColor = System.Drawing.Color.Transparent;
            this.panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel.Location = new System.Drawing.Point(34, 20);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(204, 93);
            this.panel.TabIndex = 6;
            this.panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // panelExpander
            // 
            this.panelExpander.BackColor = System.Drawing.SystemColors.Control;
            this.panelExpander.Controls.Add(this.pictureBox);
            this.panelExpander.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelExpander.Location = new System.Drawing.Point(0, 0);
            this.panelExpander.Name = "panelExpander";
            this.panelExpander.Size = new System.Drawing.Size(15, 113);
            this.panelExpander.TabIndex = 7;
            this.panelExpander.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.panelExpander.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.panelExpander.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.panelExpander.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // pictureBox
            // 
            this.pictureBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox.Image = global::TomSharpControls.Properties.Resources.minus;
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(15, 20);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox.TabIndex = 4;
            this.pictureBox.TabStop = false;
            this.pictureBox.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // panelLabel
            // 
            this.panelLabel.BackColor = System.Drawing.Color.Transparent;
            this.panelLabel.Controls.Add(this.label);
            this.panelLabel.Controls.Add(this.pictureBoxIcon);
            this.panelLabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLabel.Location = new System.Drawing.Point(34, 0);
            this.panelLabel.Name = "panelLabel";
            this.panelLabel.Size = new System.Drawing.Size(204, 20);
            this.panelLabel.TabIndex = 8;
            this.panelLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.panelLabel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.panelLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.panelLabel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // label
            // 
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label.Location = new System.Drawing.Point(20, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(184, 20);
            this.label.TabIndex = 2;
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.label.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.label.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.label.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // pictureBoxIcon
            // 
            this.pictureBoxIcon.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBoxIcon.Image = global::TomSharpControls.Properties.Resources.folder;
            this.pictureBoxIcon.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxIcon.Name = "pictureBoxIcon";
            this.pictureBoxIcon.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxIcon.TabIndex = 3;
            this.pictureBoxIcon.TabStop = false;
            this.pictureBoxIcon.Visible = false;
            this.pictureBoxIcon.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.pictureBoxIcon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.pictureBoxIcon.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.pictureBoxIcon.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // panelCheck
            // 
            this.panelCheck.BackColor = System.Drawing.Color.Transparent;
            this.panelCheck.Controls.Add(this.checkBox);
            this.panelCheck.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelCheck.Location = new System.Drawing.Point(15, 0);
            this.panelCheck.Margin = new System.Windows.Forms.Padding(0);
            this.panelCheck.Name = "panelCheck";
            this.panelCheck.Size = new System.Drawing.Size(19, 113);
            this.panelCheck.TabIndex = 9;
            this.panelCheck.MouseClick += new System.Windows.Forms.MouseEventHandler(this.control_MouseClick);
            this.panelCheck.MouseDown += new System.Windows.Forms.MouseEventHandler(this.control_MouseDown);
            this.panelCheck.MouseMove += new System.Windows.Forms.MouseEventHandler(this.control_MouseMove);
            this.panelCheck.MouseUp += new System.Windows.Forms.MouseEventHandler(this.control_MouseUp);
            // 
            // checkBox
            // 
            this.checkBox.Location = new System.Drawing.Point(3, 3);
            this.checkBox.Name = "checkBox";
            this.checkBox.Size = new System.Drawing.Size(14, 14);
            this.checkBox.TabIndex = 1;
            this.checkBox.UseVisualStyleBackColor = true;
            this.checkBox.Click += new System.EventHandler(this.checkBox_Click);
            // 
            // MapLegendItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.panel);
            this.Controls.Add(this.panelLabel);
            this.Controls.Add(this.panelCheck);
            this.Controls.Add(this.panelExpander);
            this.Name = "MapLegendItem";
            this.Size = new System.Drawing.Size(238, 113);
            this.panelExpander.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.panelLabel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIcon)).EndInit();
            this.panelCheck.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Panel panelExpander;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Panel panelLabel;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Panel panelCheck;
        private System.Windows.Forms.CheckBox checkBox;
        private System.Windows.Forms.PictureBox pictureBoxIcon;

    }
}
