﻿namespace TomSharpControls
{
    partial class FormVectorStyleEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1Cancel = new System.Windows.Forms.Button();
            this.buttonOK = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageSymbol = new System.Windows.Forms.TabPage();
            this.tomCharSymbol1 = new TomControls.TomCharSymbol();
            this.tabPageLine = new System.Windows.Forms.TabPage();
            this.tomPenEditor1 = new TomControls.TomPenEditor();
            this.tabPageFill = new System.Windows.Forms.TabPage();
            this.tomHatchBrush1 = new TomControls.TomHatchBrush();
            this.tabControl.SuspendLayout();
            this.tabPageSymbol.SuspendLayout();
            this.tabPageLine.SuspendLayout();
            this.tabPageFill.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1Cancel
            // 
            this.button1Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1Cancel.Location = new System.Drawing.Point(315, 272);
            this.button1Cancel.Name = "button1Cancel";
            this.button1Cancel.Size = new System.Drawing.Size(75, 23);
            this.button1Cancel.TabIndex = 5;
            this.button1Cancel.Text = "Cancel";
            this.button1Cancel.UseVisualStyleBackColor = true;
            // 
            // buttonOK
            // 
            this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOK.Location = new System.Drawing.Point(396, 272);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(75, 23);
            this.buttonOK.TabIndex = 4;
            this.buttonOK.Text = "Ok";
            this.buttonOK.UseVisualStyleBackColor = true;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPageSymbol);
            this.tabControl.Controls.Add(this.tabPageLine);
            this.tabControl.Controls.Add(this.tabPageFill);
            this.tabControl.Location = new System.Drawing.Point(7, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(464, 254);
            this.tabControl.TabIndex = 6;
            // 
            // tabPageSymbol
            // 
            this.tabPageSymbol.Controls.Add(this.tomCharSymbol1);
            this.tabPageSymbol.Location = new System.Drawing.Point(4, 22);
            this.tabPageSymbol.Name = "tabPageSymbol";
            this.tabPageSymbol.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSymbol.Size = new System.Drawing.Size(456, 228);
            this.tabPageSymbol.TabIndex = 0;
            this.tabPageSymbol.Text = "Symbol";
            this.tabPageSymbol.UseVisualStyleBackColor = true;
            // 
            // tomCharSymbol1
            // 
            this.tomCharSymbol1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomCharSymbol1.FontName = "Arial";
            this.tomCharSymbol1.Location = new System.Drawing.Point(3, 3);
            this.tomCharSymbol1.Name = "tomCharSymbol1";
            this.tomCharSymbol1.SelectedGlyph = -1;
            this.tomCharSymbol1.Size = new System.Drawing.Size(450, 222);
            this.tomCharSymbol1.TabIndex = 0;
            // 
            // tabPageLine
            // 
            this.tabPageLine.Controls.Add(this.tomPenEditor1);
            this.tabPageLine.Location = new System.Drawing.Point(4, 22);
            this.tabPageLine.Name = "tabPageLine";
            this.tabPageLine.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLine.Size = new System.Drawing.Size(456, 228);
            this.tabPageLine.TabIndex = 1;
            this.tabPageLine.Text = "Line";
            this.tabPageLine.UseVisualStyleBackColor = true;
            // 
            // tomPenEditor1
            // 
            this.tomPenEditor1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomPenEditor1.GraphicsUnit = System.Drawing.GraphicsUnit.Pixel;
            this.tomPenEditor1.Location = new System.Drawing.Point(3, 3);
            this.tomPenEditor1.Name = "tomPenEditor1";
            this.tomPenEditor1.Size = new System.Drawing.Size(450, 222);
            this.tomPenEditor1.TabIndex = 0;
            // 
            // tabPageFill
            // 
            this.tabPageFill.Controls.Add(this.tomHatchBrush1);
            this.tabPageFill.Location = new System.Drawing.Point(4, 22);
            this.tabPageFill.Name = "tabPageFill";
            this.tabPageFill.Size = new System.Drawing.Size(456, 228);
            this.tabPageFill.TabIndex = 2;
            this.tabPageFill.Text = "Fill";
            this.tabPageFill.UseVisualStyleBackColor = true;
            // 
            // tomHatchBrush1
            // 
            this.tomHatchBrush1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomHatchBrush1.Location = new System.Drawing.Point(0, 0);
            this.tomHatchBrush1.Name = "tomHatchBrush1";
            this.tomHatchBrush1.Size = new System.Drawing.Size(456, 228);
            this.tomHatchBrush1.TabIndex = 1;
            // 
            // FormVectorStyleEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 305);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.button1Cancel);
            this.Controls.Add(this.buttonOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormVectorStyleEditor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Style Editor";
            this.tabControl.ResumeLayout(false);
            this.tabPageSymbol.ResumeLayout(false);
            this.tabPageLine.ResumeLayout(false);
            this.tabPageFill.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1Cancel;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageSymbol;
        private System.Windows.Forms.TabPage tabPageLine;
        private TomControls.TomPenEditor tomPenEditor1;
        private System.Windows.Forms.TabPage tabPageFill;
        private TomControls.TomHatchBrush tomHatchBrush1;
        private TomControls.TomCharSymbol tomCharSymbol1;
    }
}