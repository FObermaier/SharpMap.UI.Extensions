﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SharpMap.Layers;
using SharpMap.Data.Providers;
using System.IO;
using SharpMap.Styles;

namespace TomSharpControls
{
    public partial class FormMapProperites : Form
    {
        private int _SRID = 2000;
        public int SRID
        {
            get
            {
                return _SRID;
            }
            set
            {
                _SRID = value;
                SRIDChange();
            }
        }

        public FormMapProperites()
        {
            InitializeComponent();
        }

        private static string appPath = Path.GetDirectoryName(Application.ExecutablePath);

        private VectorLayer Countries = new VectorLayer("Countries");
        private ShapeFile sCountries = new ShapeFile(appPath + "\\Data\\10m_admin_0_countries.shp", true);
        private VectorLayer Projections = new VectorLayer("Projections");
        private ShapeFile sfProjection = new ShapeFile(appPath + "\\Data\\EPSG_2012-11-26.shp", true);

        private void FormMapProperites_Load(object sender, EventArgs e)
        {

            CsvParser parser = new CsvParser(appPath + "\\Data\\CRS.csv");

            DataTable dt = parser.ParseToDataTable();

            dataGridView1.DataSource = dt;

            var distinctRows = (from DataRow dRow in dt.Rows select dRow["Region"]).Distinct();

            mapBox1.ActiveTool = SharpMap.Forms.MapBox.Tools.Pan;


            Countries.DataSource = sCountries;
            Countries.Style.Fill = new SolidBrush(Color.Green);
            Countries.Style.Line = new Pen(Color.DarkGreen);


            Projections.DataSource = sfProjection;

            sfProjection.FilterDelegate = delegate(SharpMap.Data.FeatureDataRow row)
            {
                int areaCode = Convert.ToInt32(row["Area_Code"]);

                return areaCode == SRID;
            };



            Projections.Style.Fill = new SolidBrush(Color.Transparent);
            Projections.Style.Outline = new Pen(Color.Red, (float)2.0); ;
            Projections.Style.EnableOutline = true;

            mapBox1.Map.Layers.Add(Countries);
            mapBox1.Map.Layers.Add(Projections);


            mapBox1.Map.ZoomToExtents();
            mapBox1.Refresh();

            mapBox1.ActiveTool = SharpMap.Forms.MapBox.Tools.Pan;



            
        }

        private void SRIDChange()
        {
            mapBox1.Map.ZoomToExtents();
            mapBox1.Refresh();
        }

        private void numericUpDownSRID_ValueChanged(object sender, EventArgs e)
        {
            SRID = (int)numericUpDownSRID.Value;

        }

        
    }
}
