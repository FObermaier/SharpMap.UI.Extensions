﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SharpMap.Styles;
using SharpMap.Layers;
using SharpMap.Rendering;
using GeoAPI.Geometries;
using SharpMap;

namespace TomSharpControls
{
    public partial class MapLegendSubItem : UserControl
    {

        private static Size _samplesizebase = new Size(25, 20);

        public bool SampleVisible
        {
            get
            {
                return panel.Visible;
            }
            set
            {
                panel.Visible = value;
            }
        }

        public Size SampleSize
        {
            get
            {
                return panel.Size;
            }
            set
            {
                panel.Width = value.Width;

                Height = value.Height + Padding.Top + Padding.Bottom;
            }

        }

        public bool CheckVisible
        {
            get
            {
                return checkBox.Visible;
            }
            set
            {
                checkBox.Visible = value;
            }
        }

        public bool Checked
        {
            get
            {
                return checkBox.Checked;
            }
            set
            {
                checkBox.Checked = value;
            }
        }

        private MapLegendItem _parentitem = null;
        public MapLegendItem ParentItem
        {
            get
            {
                return _parentitem;
            }
            protected set
            {
                _parentitem = value;
            }
        }

        private Style _style = null;
        public Style Style
        {
            get
            {
                return _style;
            }
            set
            {
                _style = value;
                Invalidate();
                Refresh();
            }
        }

        public List<LegendType> LegendTypes
        {
            get;
            set;
        }

        [EditorBrowsable(EditorBrowsableState.Always)]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Bindable(true)]
        public override string Text 
        {
            get
            {
                return label.Text;
            }
            set
            {
                label.Text = value;
            }
        }

        //public MapLegendSubItem()
        //{
        //    InitializeComponent();
        //    Initialize();
        //}

        public MapLegendSubItem(MapLegendItem parent, List<LegendType> legendTypes, Style style, string text)
        {
            InitializeComponent();

            _parentitem = parent;
            _style = style;

            LegendTypes = legendTypes;
            Text = text;

            if(legendTypes.Contains(LegendType.Raster))
            {
                CheckVisible = false;

                PictureBox Picture = new PictureBox();

                Picture.Image = TomSharpControls.Properties.Resources.raster;
                Picture.Dock = DockStyle.Fill;

                panel.Controls.Add(Picture);
            }

            Initialize();

        }

        public void Initialize()
        {
            if (_style != null & CheckVisible)
            {
                checkBox.Checked = _style.Enabled;
            }


        }


        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);


            if (_style == null) return;

            checkBox.Checked = _style.Enabled;

            if (_style is VectorStyle)
            {
                VectorStyle vs = (VectorStyle)_style;

                Graphics g = panel.CreateGraphics();
                Rectangle rPanel = panel.ClientRectangle;

                rPanel.Inflate(-2, -2);

                foreach (LegendType t in LegendTypes)
                {

                    switch (t)
                    {
                        case LegendType.Point:
                            {
                                VectorStyle style = _style as VectorStyle;

                                Point Center = new Point(panel.ClientRectangle.Left + panel.ClientRectangle.Width / 2,
                                                         panel.ClientRectangle.Top + panel.ClientRectangle.Height / 2);

                                if (style.PointSymbolizer != null)
                                {
                                    //VectorRenderer.DrawPoint(style.PointSymbolizer, g, (IPoint)feature, map);

                                }
                                else
                                {
                                    if (style.Symbol != null || style.PointColor == null)
                                    {
                                        //VectorRenderer.DrawPoint(g, (IPoint)feature, style.Symbol, style.SymbolScale, style.SymbolOffset,
                                        //                         style.SymbolRotation, map);
                                    }
                                    else
                                    {
                                        DrawPoint(g, Center, style.PointColor, style.PointSize, style.SymbolOffset);
                                    }

                                }
                            }
                            break;
                        case LegendType.Line:
                            {
                                g.DrawLine(vs.Line, 0, panel.Height / 2, panel.Width, panel.Height / 2);
                            }
                            break;
                        case LegendType.Polygon:
                            {
                                g.FillRectangle(vs.Fill, panel.ClientRectangle);
                                if (vs.EnableOutline)
                                {
                                    Rectangle r = panel.ClientRectangle;

                                    r.Width -= 1;
                                    r.Height -= 1;

                                    g.DrawRectangle(vs.Outline, r);
                                }
                            }
                            break;
                    }

                 
                }

                g.Dispose();
            }

            
        }

        public static void DrawPoint(Graphics g, Point point, Brush b, float size, PointF offset)
        {
            if (point == null)
                return;

            var width = size;
            var height = size;

            g.FillEllipse(b, (int)point.X - width / 2 + offset.X,
                        (int)point.Y - height / 2 + offset.Y, width, height);
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            _style.Enabled = checkBox.Checked;
        }

        public delegate void OnSubItemChanged();
        public event OnSubItemChanged SubItemChanged;


        public delegate void OnLegendStyleItemMouseDown(MapLegendSubItem item, MouseEventArgs e);
        public event OnLegendStyleItemMouseDown LegendStyleItemMouseDown;
        private void control_MouseDown(object sender, MouseEventArgs e)
        {
            if(LegendStyleItemMouseDown!=null)
            {
                LegendStyleItemMouseDown(this,e);
            }
        }


        public delegate void OnLegendStyleItemMouseUp(MapLegendSubItem item, MouseEventArgs e);
        public event OnLegendStyleItemMouseUp LegendStyleItemMouseUp;
        private void control_MouseUp(object sender, MouseEventArgs e)
        {
            if (LegendStyleItemMouseUp != null)
            {
                LegendStyleItemMouseUp(this, e);
            }
        }


        public delegate void OnLegendStyleItemMouseClick(MapLegendSubItem item, MouseEventArgs e);
        public event OnLegendStyleItemMouseClick LegendStyleItemMouseClick;
        private void control_MouseClick(object sender, MouseEventArgs e)
        {
            if (LegendStyleItemMouseClick != null)
            {
                LegendStyleItemMouseClick(this, e);
            }
        }

        public delegate void OnLegendStyleItemMouseMove(MapLegendSubItem item, MouseEventArgs e);
        public event OnLegendStyleItemMouseMove LegendStyleItemMouseMove;
        private void control_MouseMove(object sender, MouseEventArgs e)
        {
            if (LegendStyleItemMouseMove != null)
            {
                LegendStyleItemMouseMove(this, e);
            }
        }

        private void panel_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FormVectorStyleEditor frm = new FormVectorStyleEditor();

            frm.ShowDialog();
        }

        private void checkBox_Click(object sender, EventArgs e)
        {
            if (SubItemChanged != null)
            {
                SubItemChanged();
            }
        }

        #region unused now
        //public delegate void OnLegendStyleItemMouseEnter(MapLegendSubItem item, EventArgs e);
        //public event OnLegendStyleItemMouseEnter LegendStyleItemMouseEnter;
        //private void control_MouseEnter(object sender, EventArgs e)
        //{
        //    if (LegendStyleItemMouseEnter != null)
        //    {
        //        LegendStyleItemMouseEnter(this, e);
        //    }
        //}

        //public delegate void OnLegendStyleItemMouseLeave(MapLegendSubItem item, EventArgs e);
        //public event OnLegendStyleItemMouseLeave LegendStyleItemMouseLeave;
        //private void control_MouseLeave(object sender, EventArgs e)
        //{
        //    if (LegendStyleItemMouseLeave != null)
        //    {
        //        LegendStyleItemMouseLeave(this, e);
        //    }
        //}
        #endregion
    }
}
