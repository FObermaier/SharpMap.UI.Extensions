﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TomControls;

namespace TomControls
{
    public partial class TomApplicationManager : UserControl
    {
        public TomApplicationManager()
        {
            InitializeComponent();
            splitContainer.Panel2Collapsed = true;

        }

        private void TomUserControlApp_Load(object sender, EventArgs e)
        {

            tomColorListBoxPalette.Items.AddRange(TomColorUtils.TomPaletteBase);
            tomCanvas.ActualTool = TomCanvas.ToolSelect;

        }


        private void tomCanvas_Paint(object sender, PaintEventArgs e)
        {
            RectangleF r = tomCanvas.GetViewRectangle();
            r = tomCanvas.Document.PageSize.ToPageSize(r);

            double d = Math.Max(r.Width, r.Height);
            double k = 1;
            double interval = 10;
            
            if (d < 2)
            {
                k = 0.01;
                interval = 10;
                labelRulerUnits.Text = "1/100 mm";

            }
            else
            if (d < 50)
            {
                k = 0.1;
                interval = 10;
                labelRulerUnits.Text = "1/10 mm";

            }
            else
            if (d <= 400)
            {
                labelRulerUnits.Text = "mm";
            }
            if (d > 400)
            {
                k = 10;
                labelRulerUnits.Text = "cm";
            }
            if (d > 700)
            {
                k = 10;
                interval = 10;
                labelRulerUnits.Text = "cm";
            }
            if (d > 5000)
            {
                k = 1000;
                interval = 1;
                labelRulerUnits.Text = "m";
            }
            tomRulerHorizontal.Min = r.X / k;
            tomRulerHorizontal.Max = (r.X + r.Width) / k;
            tomRulerHorizontal.MajorInterval = interval;

            tomRulerVertical.Min = r.Y / k; ;
            tomRulerVertical.Max = (r.Y + r.Height) / k;
            tomRulerVertical.MajorInterval = interval;
        }

        private void tomCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            tomRulerHorizontal.SetLinePosition(Color.Red, e.X, e.Y);
            tomRulerVertical.SetLinePosition(Color.Red, e.X, e.Y);

            PointF p = tomCanvas.PixelToPage(new PointF(e.X, e.Y));
            //p = tomCanvas.Document.PageSize.ToPageSize(p);

            labelX.Text = "X: " + p.X.ToString(".000");
            labelY.Text = "Y: " + p.Y.ToString(".000");
            labelX.Refresh();
            labelY.Refresh();
        }

        public void PageSetup()
        {
            tomCanvas.PageSetup();
        }

       
        private void tomColorListBoxPalette_SelectedIndexChanged(object sender, EventArgs e)
        {
    
            Color c = TomColorUtils.GetColorFromName((string)tomColorListBoxPalette.Items[tomColorListBoxPalette.SelectedIndex]);

            foreach (int index in tomCanvas.Document.EditList.SelectionList)
            {
                tomCanvas.Document.EditList[index].TomBrush.ForeColor = c;
            }

            tomCanvas.Document.PushEdit("Change color", false);

            tomCanvas.Redraw();
            tomCanvas.Refresh();

            tomCanvas.Focus();
        }

        private void tomColorListBoxPalette_MouseClick(object sender, MouseEventArgs e)
        {

        }

      
    }
}
