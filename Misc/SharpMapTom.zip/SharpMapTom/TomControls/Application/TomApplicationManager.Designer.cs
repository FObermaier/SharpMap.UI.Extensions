﻿namespace TomControls
{
    partial class TomApplicationManager
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.Drawing.Drawing2D.Matrix matrix1 = new System.Drawing.Drawing2D.Matrix();
            this.toolStripTop = new System.Windows.Forms.ToolStrip();
            this.toolStripLeft = new System.Windows.Forms.ToolStrip();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanelMain = new System.Windows.Forms.TableLayoutPanel();
            this.labelRulerUnits = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelY = new System.Windows.Forms.Label();
            this.labelX = new System.Windows.Forms.Label();
            this.tomColorListBoxPalette = new TomControls.TomColorListBox();
            this.tomRulerVertical = new TomControls.TomRuler();
            this.tomRulerHorizontal = new TomControls.TomRuler();
            this.tomCanvas = new TomControls.TomCanvas();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.tableLayoutPanelMain.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripTop
            // 
            this.toolStripTop.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripTop.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStripTop.Location = new System.Drawing.Point(0, 0);
            this.toolStripTop.Name = "toolStripTop";
            this.toolStripTop.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStripTop.Size = new System.Drawing.Size(632, 25);
            this.toolStripTop.Stretch = true;
            this.toolStripTop.TabIndex = 1;
            // 
            // toolStripLeft
            // 
            this.toolStripLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStripLeft.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripLeft.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStripLeft.Location = new System.Drawing.Point(0, 25);
            this.toolStripLeft.Name = "toolStripLeft";
            this.toolStripLeft.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStripLeft.Size = new System.Drawing.Size(37, 437);
            this.toolStripLeft.Stretch = true;
            this.toolStripLeft.TabIndex = 2;
            // 
            // splitContainer
            // 
            this.splitContainer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(37, 25);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.tableLayoutPanelMain);
            this.splitContainer.Size = new System.Drawing.Size(595, 437);
            this.splitContainer.SplitterDistance = 562;
            this.splitContainer.TabIndex = 5;
            // 
            // tableLayoutPanelMain
            // 
            this.tableLayoutPanelMain.ColumnCount = 3;
            this.tableLayoutPanelMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanelMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanelMain.Controls.Add(this.tomColorListBoxPalette, 0, 2);
            this.tableLayoutPanelMain.Controls.Add(this.tomRulerVertical, 0, 1);
            this.tableLayoutPanelMain.Controls.Add(this.tomRulerHorizontal, 1, 0);
            this.tableLayoutPanelMain.Controls.Add(this.tomCanvas, 1, 1);
            this.tableLayoutPanelMain.Controls.Add(this.labelRulerUnits, 0, 0);
            this.tableLayoutPanelMain.Controls.Add(this.panel1, 2, 2);
            this.tableLayoutPanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelMain.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelMain.Name = "tableLayoutPanelMain";
            this.tableLayoutPanelMain.RowCount = 3;
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanelMain.Size = new System.Drawing.Size(558, 433);
            this.tableLayoutPanelMain.TabIndex = 3;
            // 
            // labelRulerUnits
            // 
            this.labelRulerUnits.AutoSize = true;
            this.labelRulerUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelRulerUnits.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRulerUnits.Location = new System.Drawing.Point(3, 0);
            this.labelRulerUnits.Name = "labelRulerUnits";
            this.labelRulerUnits.Size = new System.Drawing.Size(24, 30);
            this.labelRulerUnits.TabIndex = 5;
            this.labelRulerUnits.Text = "1/100 mm";
            this.labelRulerUnits.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.labelY);
            this.panel1.Controls.Add(this.labelX);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(408, 394);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 39);
            this.panel1.TabIndex = 7;
            // 
            // labelY
            // 
            this.labelY.AutoSize = true;
            this.labelY.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelY.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.labelY.Location = new System.Drawing.Point(0, 21);
            this.labelY.Name = "labelY";
            this.labelY.Size = new System.Drawing.Size(21, 14);
            this.labelY.TabIndex = 1;
            this.labelY.Text = "Y:";
            // 
            // labelX
            // 
            this.labelX.AutoSize = true;
            this.labelX.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelX.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX.Location = new System.Drawing.Point(0, 0);
            this.labelX.Name = "labelX";
            this.labelX.Size = new System.Drawing.Size(21, 14);
            this.labelX.TabIndex = 0;
            this.labelX.Text = "X:";
            // 
            // tomColorListBoxPalette
            // 
            this.tableLayoutPanelMain.SetColumnSpan(this.tomColorListBoxPalette, 2);
            this.tomColorListBoxPalette.ColumnWidth = 25;
            this.tomColorListBoxPalette.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tomColorListBoxPalette.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.tomColorListBoxPalette.FormattingEnabled = true;
            this.tomColorListBoxPalette.HideColorLabel = true;
            this.tomColorListBoxPalette.ItemHeight = 35;
            this.tomColorListBoxPalette.Location = new System.Drawing.Point(0, 394);
            this.tomColorListBoxPalette.Margin = new System.Windows.Forms.Padding(0);
            this.tomColorListBoxPalette.MultiColumn = true;
            this.tomColorListBoxPalette.Name = "tomColorListBoxPalette";
            this.tomColorListBoxPalette.Size = new System.Drawing.Size(408, 39);
            this.tomColorListBoxPalette.TabIndex = 6;
            this.tomColorListBoxPalette.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tomColorListBoxPalette_MouseClick);
            this.tomColorListBoxPalette.SelectedIndexChanged += new System.EventHandler(this.tomColorListBoxPalette_SelectedIndexChanged);
            // 
            // tomRulerVertical
            // 
            this.tomRulerVertical.BackColor = System.Drawing.Color.White;
            this.tomRulerVertical.BorderStyle = System.Windows.Forms.Border3DStyle.Flat;
            this.tomRulerVertical.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomRulerVertical.Font = new System.Drawing.Font("Arial", 7.25F);
            this.tomRulerVertical.Location = new System.Drawing.Point(0, 30);
            this.tomRulerVertical.MajorInterval = 10D;
            this.tomRulerVertical.MajorIntervalDivisions = 10;
            this.tomRulerVertical.Margin = new System.Windows.Forms.Padding(0);
            this.tomRulerVertical.MarkFactorDivision = 5;
            this.tomRulerVertical.MarkFactorMiddle = 2;
            this.tomRulerVertical.Max = 100D;
            this.tomRulerVertical.Min = 0D;
            this.tomRulerVertical.Name = "tomRulerVertical";
            this.tomRulerVertical.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tomRulerVertical.RulerAlign = TomControls.TomRuler.RulerAligns.Top;
            this.tomRulerVertical.Size = new System.Drawing.Size(30, 364);
            this.tomRulerVertical.TabIndex = 3;
            // 
            // tomRulerHorizontal
            // 
            this.tomRulerHorizontal.BackColor = System.Drawing.Color.White;
            this.tomRulerHorizontal.BorderStyle = System.Windows.Forms.Border3DStyle.Flat;
            this.tableLayoutPanelMain.SetColumnSpan(this.tomRulerHorizontal, 2);
            this.tomRulerHorizontal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomRulerHorizontal.Font = new System.Drawing.Font("Arial", 7.25F);
            this.tomRulerHorizontal.Location = new System.Drawing.Point(30, 0);
            this.tomRulerHorizontal.MajorInterval = 10D;
            this.tomRulerHorizontal.MajorIntervalDivisions = 10;
            this.tomRulerHorizontal.Margin = new System.Windows.Forms.Padding(0);
            this.tomRulerHorizontal.MarkFactorDivision = 5;
            this.tomRulerHorizontal.MarkFactorMiddle = 2;
            this.tomRulerHorizontal.Max = 100D;
            this.tomRulerHorizontal.Min = 0D;
            this.tomRulerHorizontal.Name = "tomRulerHorizontal";
            this.tomRulerHorizontal.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.tomRulerHorizontal.RulerAlign = TomControls.TomRuler.RulerAligns.Top;
            this.tomRulerHorizontal.Size = new System.Drawing.Size(528, 30);
            this.tomRulerHorizontal.TabIndex = 4;
            // 
            // tomCanvas
            // 
            this.tomCanvas.ActualTool = 1;
            this.tableLayoutPanelMain.SetColumnSpan(this.tomCanvas, 2);
            this.tomCanvas.Cursor = System.Windows.Forms.Cursors.Default;
            this.tomCanvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomCanvas.DrawingMatrix = matrix1;
            this.tomCanvas.Location = new System.Drawing.Point(30, 30);
            this.tomCanvas.MainToolStrip = this.toolStripLeft;
            this.tomCanvas.Margin = new System.Windows.Forms.Padding(0);
            this.tomCanvas.Name = "tomCanvas";
            this.tomCanvas.SecondaryToolStrip = this.toolStripTop;
            this.tomCanvas.Size = new System.Drawing.Size(528, 364);
            this.tomCanvas.TabIndex = 0;
            this.tomCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.tomCanvas_Paint);
            this.tomCanvas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tomCanvas_MouseMove);
            // 
            // TomApplicationManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.toolStripLeft);
            this.Controls.Add(this.toolStripTop);
            this.Name = "TomApplicationManager";
            this.Size = new System.Drawing.Size(632, 462);
            this.Load += new System.EventHandler(this.TomUserControlApp_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.tableLayoutPanelMain.ResumeLayout(false);
            this.tableLayoutPanelMain.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ToolStrip toolStripTop;
        private System.Windows.Forms.ToolStrip toolStripLeft;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelMain;
        private TomRuler tomRulerVertical;
        private TomRuler tomRulerHorizontal;
        private TomCanvas tomCanvas;
        private System.Windows.Forms.Label labelRulerUnits;
        private TomColorListBox tomColorListBoxPalette;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelY;
        private System.Windows.Forms.Label labelX;


    }
}
