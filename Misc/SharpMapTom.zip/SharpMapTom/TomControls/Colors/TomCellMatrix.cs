﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomCellMatrix : UserControl
    {
        private Bitmap _bitmap = null;

        private TomCell _SelCell = null;
        public TomCell SelCell
        {
            get
            {
                return _SelCell;
            }
        }

        public TomCell [,] Cells;

        public Color Color
        {
            set
            {
                Color c = Color.FromArgb(value.A, value.R, value.G, value.B);

                _SelCell = null;

                for (int row = 0; row < _CellRows; row++)
                {
                    for (int col = 0; col < _CellColumns; col++)
                    {
                        if (c.A == 0 && Cells[row, col].FillColor.A == 0)
                        {
                            _SelCell = Cells[row, col];
                            break;
                        }

                        if (Cells[row, col].FillColor == c)
                        {
                            _SelCell = Cells[row, col];
                            break;
                        }

                    }
                }

                Invalidate();
            }
            get
            {
                if (_SelCell != null)
                {
                    return _SelCell.FillColor;
                }

                return Color.Empty;
            }
        }

        private TomCellStyle _CellStyle = TomCellStyle.Hexagon;
        public TomCellStyle CellStyle
        {
            get
            {
                return _CellStyle;
            }
            set
            {
                _CellStyle = value;
                Initialize();
                Invalidate();
            }
        }

        private int _CellRows = 2;
        public int CellRows
        {
            get
            {
                return _CellRows;
            }
            set
            {
                _CellRows = value;
                if (_CellRows < 1) _CellRows = 1;
                Initialize();
                Invalidate();
            }
        }

        private int _CellColumns = 8;
        public int CellColumns
        {
            get
            {
                return _CellColumns;
            }
            set
            {
                _CellColumns = value;
                if (_CellColumns < 1) _CellColumns = 1;

                Initialize();
                Invalidate();
            }
        }

        private int _CellRadius = 6;
        public int CellRadius
        {
            get
            {
                return _CellRadius;
            }
            set
            {
                _CellRadius = value;
                if (_CellRadius < 3) _CellRadius = 3;
                Initialize();
                Invalidate();
            }
        }

        private bool _ShowSelection = true;
        public bool ShowSelection
        {
            get
            {
                return _ShowSelection;
            }
            set
            {
                _ShowSelection = value;
                Initialize();
                Invalidate();
            }
        }

        public TomCellMatrix()
        {
            InitializeComponent();

            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);
        }

        private void Initialize()
        {
            if (_bitmap != null)
            {
                _bitmap.Dispose();
                _bitmap = null;
            }

            Cells = new TomCell[_CellRows, _CellColumns];

            int InterWidth = 2 * (int)(CellRadius * Math.Cos(Matematica.DegreesToRadians(30.0))) + 1;

            Point Start = new Point(0, 0);

            int diameter = 2 * _CellRadius;

            if (_CellStyle == TomCellStyle.Hexagon)
            {

                int MatrixWidth = 0;
                int MatrixHeight = 0;


                if (_CellRows == 1)
                {
                    MatrixWidth = _CellColumns * InterWidth;
                    MatrixHeight = diameter;

                    Start = new Point(
                        (int)((Width - MatrixWidth) / 2.0) + InterWidth / 2,
                        (int)((Height - MatrixHeight) / 2.0) + diameter / 2);

                }
                else
                {
                    MatrixWidth = (_CellColumns * 2 + 1) * (InterWidth / 2) + _CellColumns;
                    MatrixHeight = (int)(2 * CellRadius+(_CellRows - 1) * 1.5 * _CellRadius);

                    //Start = new Point(
                    //(int)((Width - MatrixWidth) / 2.0),
                    //(int)((Height - MatrixHeight) / 2.0)
                    //);
                    Start = new Point(
                       (int)((Width - MatrixWidth) / 2.0) + InterWidth / 2,
                       (int)((Height - MatrixHeight) / 2.0) + diameter / 2);
                }



            }
            else
            {
                Start = new Point((int)(Width / 2 - (_CellColumns * CellRadius) + CellRadius),
                                  (int)(Height / 2 - _CellRows * CellRadius) + CellRadius);

            }

            for (int row = 0; row < _CellRows; row++)
            {
                for (int col = 0; col < _CellColumns; col++)
                {
                    if (_CellStyle == TomCellStyle.Hexagon)
                    {
                        Point p = new Point(
                                            Start.X + InterWidth * col,
                                            (int)(Start.Y + (_CellRadius*1.5) * row)
                                            );

                        if (row % 2 != 0)
                        {
                            p.X += InterWidth / 2;
                        }

                        Cells[row, col] = new TomCell(p, _CellRadius, Color.Red, Color.Black);
                    }
                    else
                    {
                        Point p = new Point(Start.X + CellRadius * col * 2, Start.Y + CellRadius * row * 2);
                        Cells[row, col] = new TomCell(p, _CellRadius, Color.Red, Color.Black);
                    }
                }
            }

        }

        public void Repaint()
        {
            if (_bitmap != null)
            {
                _bitmap.Dispose();
                _bitmap = null;
            }

            Invalidate();
        }

        private void Draw(Graphics g)
        {

            if (_bitmap == null)
            {
                _bitmap = new Bitmap(Width, Height);
                Graphics bitmapGraphics = Graphics.FromImage(_bitmap);

                for (int row = 0; row < _CellRows; row++)
                {
                    for (int col = 0; col < _CellColumns; col++)
                    {
                        TomCell c = Cells[row, col];

                        if (c.FillColor.A != 255)
                        {

                            HatchBrush hb = new HatchBrush(HatchStyle.SmallCheckerBoard, Color.Black, Color.White);

                            switch (_CellStyle)
                            {
                                case TomCellStyle.Hexagon:
                                    {
                                        c.DrawHexagon(bitmapGraphics, new Pen(Color.Transparent), hb);
                                    }
                                    break;
                                case TomCellStyle.Circle:
                                    {
                                        c.DrawCircle(bitmapGraphics,new Pen(Color.Transparent), hb);
                                    }
                                    break;
                                case TomCellStyle.Square:
                                    {
                                        c.DrawSquare(bitmapGraphics,new Pen(Color.Transparent), hb);
                                    }
                                    break;
                            }

                            hb.Dispose();


                        }


                        switch (_CellStyle)
                        {
                            case TomCellStyle.Hexagon:
                                {
                                    c.DrawHexagon(bitmapGraphics);
                                }
                                break;
                            case TomCellStyle.Circle:
                                {
                                    c.DrawCircle(bitmapGraphics);
                                }
                                break;
                            case TomCellStyle.Square:
                                {
                                    c.DrawSquare(bitmapGraphics);
                                }
                                break;

                        }



                    }
                }

                bitmapGraphics.Dispose();

            }

            g.DrawImage(_bitmap, new Point(0, 0));

            if (_ShowSelection & _SelCell != null)
            {
                Pen psel;

                for (int x = 0; x < 2; x++)
                {
                    if(x==0)
                        psel = new Pen(Color.Black, 3);
                    else
                        psel = new Pen(Color.White, 1);

                    SolidBrush brushsel = new SolidBrush(Color.Transparent);


                    switch (_CellStyle)
                    {
                        case TomCellStyle.Hexagon:
                            {
                                _SelCell.DrawHexagon(g, psel, brushsel);
                            }
                            break;
                        case TomCellStyle.Circle:
                            {
                                _SelCell.DrawCircle(g, psel, brushsel);
                            }
                            break;
                        case TomCellStyle.Square:
                            {
                                _SelCell.DrawSquare(g, psel, brushsel);
                            }
                            break;

                    }

                    brushsel.Dispose();
                    psel.Dispose();
                }
            }

        }

        private void TomCellMatrix_Load(object sender, EventArgs e)
        {
            Initialize();
        }

        private void TomCellMatrix_Resize(object sender, EventArgs e)
        {
            Initialize();
            Invalidate();
        }

        private void TomCellMatrix_Paint(object sender, PaintEventArgs e)
        {
            Draw(e.Graphics);
        }

        public delegate void SelectionChangeEvent(int row, int col);

        public event SelectionChangeEvent SelectionChange;

        private void TomCellMatrix_MouseClick(object sender, MouseEventArgs e)
        {
            TomCell Cell = FindSelectCell(e.X, e.Y);

            if (Cell != null)
            {
                _SelCell = Cell;

                if (SelectionChange != null)
                {
                    SelectionChange(_SelRow, _SelCol);
                }

            }

            Invalidate();
        }

        private int _SelRow = -1, _SelCol = -1;

        private TomCell FindSelectCell(int X, int Y)
        {
            _SelRow = -1;
            _SelCol = -1;

            for (int row = 0; row < _CellRows; row++)
            {
                for (int col = 0; col < _CellColumns; col++)
                {
                    if (Cells[row, col] != null)
                    {

                        Rectangle r = Cells[row, col].Rectangle();

                        if (r.Contains(new Point(X, Y)))
                        {
                            switch (_CellStyle)
                            {
                                case TomCellStyle.Hexagon:
                                case TomCellStyle.Circle:
                                    {
                                        int dx = Math.Abs(Cells[row, col].Center.X - X);
                                        int dy = Math.Abs(Cells[row, col].Center.Y - Y);

                                        if (dx < Cells[row, col].Radius & dy < Cells[row, col].Radius)
                                        {
                                            _SelRow = row;
                                            _SelCol = col;
                                            return Cells[row, col];
                                        }
                                    }
                                    break;
                                case TomCellStyle.Square:
                                    {
                                        _SelRow = row;
                                        _SelCol = col;
                                        return Cells[row, col];
                                    }

                            }

                        }



                    }
                }
            }

            return null;
        }
    }
}
