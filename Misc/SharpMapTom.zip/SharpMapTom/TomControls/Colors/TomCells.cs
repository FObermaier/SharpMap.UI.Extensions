﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace TomControls
{
    public enum TomCellStyle
    {
        Square,
        Circle,
        Hexagon,
    }


    [Serializable()]
    public class TomCell
    {
        public Point Center;
        public int Radius;

        public Color FillColor;
        public Color BorderColor;

        public TomCell()
        {

        }

        public TomCell(Point center, int radius, Color fillColor, Color borderColor)
        {
            Center = center;
            Radius = radius;
            FillColor = fillColor;
            BorderColor = borderColor;
        }

        public void DrawCircle(Graphics g, Pen pen = null, Brush brush = null)
        {
            if (brush != null)
            {
                g.FillEllipse(brush, Rectangle());
            }
            else
            {
                SolidBrush b = new SolidBrush(FillColor);
                g.FillEllipse(b, Rectangle());
                b.Dispose();
            }

            if (pen != null)
            {
                g.DrawEllipse(pen, Rectangle());
            }
            else
            {
                Pen p = new Pen(BorderColor, 1);
                g.DrawEllipse(p, Rectangle());
                p.Dispose();
            }
        }

        public void DrawHexagon(Graphics g,Pen pen = null, Brush brush = null)
        {
            Point[] hex  = Hexagon();

            if (brush != null)
            {
                g.FillPolygon(brush, hex);
            }
            else
            {
                SolidBrush b = new SolidBrush(FillColor);
                g.FillPolygon(b, hex);
                b.Dispose();
            }

            if (pen != null)
            {
                g.DrawPolygon(pen, hex);
            }
            else
            {
                Pen p = new Pen(BorderColor, 1);
                g.DrawPolygon(p, hex);
                p.Dispose();
            }
        }

        public void DrawSquare(Graphics g, Pen pen = null, Brush brush = null)
        {

            if (brush != null)
            {
                g.FillRectangle(brush, Rectangle());
            }
            else
            {
                SolidBrush b = new SolidBrush(FillColor);
                g.FillRectangle(b, Rectangle());
                b.Dispose();
            }

            if (pen != null)
            {
                g.DrawRectangle(pen, Rectangle());
            }
            else
            {
                Pen p = new Pen(BorderColor, 1);
                g.DrawRectangle(p, Rectangle());
                p.Dispose();
            }
        }

        public Rectangle Rectangle()
        {
            return new Rectangle(Center.X - Radius, Center.Y - Radius, Radius * 2, Radius * 2);
        }

        public double HexSide()
        {
            return Matematica.DegreesToRadians(30.0) * Radius + 1;
        }

        public Point[] Hexagon90()
        {
            Point[] hex = new Point[7];

            for (int sd = 0; sd < 6; sd++)
            {
                double a1 = (sd * 60.0d + 30.0d - 90d);

                a1 = Matematica.DegreesToRadians(a1);

                hex[sd] = new Point(
                      Center.X + (int)Math.Round(((double)Radius) * Math.Cos(a1)),
                      Center.Y + (int)Math.Round(((double)Radius) * Math.Sin(a1))
                );

            }

            hex[6] = hex[0];

            return hex;
        }

        public Point[] Hexagon()
        {

            Point[] hex = new Point[7];

            for (int sd = 0; sd < 6; sd++)
            {
                double a1 = (sd * 60.0d + 30.0d);

                a1 = Matematica.DegreesToRadians(a1);

                hex[sd] = new Point(
                      Center.X + (int)Math.Round(((double)Radius) * Math.Cos(a1)),
                      Center.Y + (int)Math.Round(((double)Radius) * Math.Sin(a1))
                );

            }

            hex[6] = hex[0];

            return hex;
        }

    }
}
