﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomColorComboBox : TomEnComboBox
    {
        private TomColorSelector tomColorSelector = new TomColorSelector();

        private Color _Color;
        public Color Color
        {
            get
            {
                return _Color;
            }
            set
            {
                _Color = value;
                tomColorSelector.Color = value;
                Refresh();
            }
        }

        public TomColorComboBox()
        {
            InitializeComponent();
            _UserControl = tomColorSelector;

            tomColorSelector.ColorChange += new TomColorSelector.ColorChangeEvent(tomColorSelector_ColorChange);
        }


        public delegate void ColorChangeEvent(Color C);

        public event ColorChangeEvent ColorChange;

        void tomColorSelector_ColorChange(Color C)
        {
            _Color = C;
            HideDropDown();

            tomColorSelector.Color = C;

            if (ColorChange != null)
            {
                ColorChange(_Color);
            }

            Invalidate();
        }


        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            base.OnDrawItem(e);
            
            HatchBrush hb = new HatchBrush(HatchStyle.SmallCheckerBoard, Color.Black, Color.White);

            e.Graphics.FillRectangle(hb, e.Bounds);
            e.Graphics.FillRectangle(new SolidBrush(_Color), e.Bounds);

            hb.Dispose();
        }
    }
}
