﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomCellListViewer : UserControl
    {
        Bitmap bitmap = null;
        public TomCell SelCell = null;

        public List<TomCell> Cells = new List<TomCell>();
        
        private TomCellStyle _CellStyle = TomCellStyle.Hexagon;
        public TomCellStyle CellStyle
        {
            get
            {
                return _CellStyle;
            }
            set
            {
                _CellStyle = value;
                Invalidate();
            }
        }

        private int _CellsNumber = 15;
        public int CellsNumber
        {
            get
            {
                return _CellsNumber;
            }
            set
            {
                _CellsNumber = value;
                if (_CellsNumber < 1) _CellsNumber = 1;

                Initialize();
                Invalidate();
            }
        }

        private int _CellRadius = 6;
        public int CellRadius
        {
            get
            {
                return _CellRadius;
            }
            set
            {
                _CellRadius = value;
                if (_CellRadius < 3) _CellRadius = 3;

                Initialize();
                Invalidate();
            }
        }

        public TomCellListViewer()
        {
            InitializeComponent();

            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);

        }

        private Color _ColorFrom = Color.FromArgb(255 - 16, 255 - 16, 255 - 16);
        public Color ColorFrom
        {
            get
            {
                return _ColorFrom;
            }
            set
            {
                _ColorFrom = value;
            }
        }

        private Color _ColorTo = Color.FromArgb(0, 0, 0);
        public Color ColorTo
        {
            get
            {
                return _ColorTo;
            }
            set
            {
                _ColorTo = value;
            }
        }


        private void Initialize()
        {
            if (bitmap != null)
            {
                bitmap.Dispose();
                bitmap = null;
            }

            Cells.Clear();

            double CellsWidth = (double)_CellsNumber * (double)(_CellRadius * 2.0);
            double left = (double)(Width / 2.0) - CellsWidth / 2.0;

            Point Start = new Point((int)left, Height / 2);

            for (int i = 0; i < _CellsNumber; i++)
            {
                Color c = Matematica.InterpolateColor((double)0, _ColorFrom, (double)(_CellsNumber - 1), _ColorTo, (double)i);

                Point p = new Point((int)left + i * _CellRadius * 2 + _CellRadius, Height / 2);
                Cells.Add(new TomCell(p, _CellRadius, c, c));
            }


        }

        private void Draw(Graphics g)
        {

            if (bitmap == null)
            {
                bitmap = new Bitmap(Width, Height);
                Graphics bitmapGraphics = Graphics.FromImage(bitmap);

                for (int i = 0; i < Cells.Count; i++)
                {

                    TomCell c = Cells.ElementAt(i);
                    if (_CellStyle == TomCellStyle.Hexagon)
                    {
                        c.DrawHexagon(bitmapGraphics);
                    }
                    else
                    {
                        c.DrawCircle(bitmapGraphics);
                    }
                }

                bitmapGraphics.Dispose();

            }

            g.DrawImage(bitmap, new Point(0, 0));

            if (SelCell != null)
            {
                Pen psel = new Pen(Color.Black, 3);
                SolidBrush brushsel = new SolidBrush(Color.Transparent);

                if (_CellStyle == TomCellStyle.Hexagon)
                {
                    SelCell.DrawHexagon(g, psel, brushsel);
                }
                else
                {
                    SelCell.DrawCircle(g, psel, brushsel);
                }

                brushsel.Dispose();
                psel.Dispose();
            }

        }

        private void TomCellsListViewer_Paint(object sender, PaintEventArgs e)
        {
            Draw(e.Graphics);
        }

        private void TomCellsListViewer_Load(object sender, EventArgs e)
        {
            Initialize();
        }

        private void TomCellsListViewer_Resize(object sender, EventArgs e)
        {
            Initialize();
            Invalidate();
        }

        public delegate void SelColorChangeEvent(Color C);

        public event SelColorChangeEvent SelColorChange;

        private void TomCellsListViewer_MouseClick(object sender, MouseEventArgs e)
        {
            TomCell Cell = FindSelectCell(e.X, e.Y);

            if (Cell != null)
            {
                SelCell = Cell;

                if (SelColorChange != null)
                {
                    SelColorChange(SelCell.FillColor);
                }

            }

            Invalidate();
        }

        private TomCell FindSelectCell(int X, int Y)
        {
            for (int i = 0; i < Cells.Count; i++)
            {
                int dx = Math.Abs(Cells[i].Center.X - X);
                int dy = Math.Abs(Cells[i].Center.Y - Y);

                if (dx < Cells[i].Radius & dy < Cells[i].Radius)
                {
                    return Cells[i];
                }
            }

            return null;
        }

        public void SelectColor(Color c)
        {
            Color c1 = Color.FromArgb(c.R, c.G, c.B);
            SelCell = null;

            for (int i = 0; i < Cells.Count; i++)
            {
                if (Cells[i].FillColor == c1)
                {
                    SelCell =  Cells[i];
                    break;
                }

            }

            Invalidate();
        }

    }
}
