﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomCellWheelViewer : UserControl
    {
       
        Bitmap bitmap = null;
        public TomCell SelCell = null;

        public TomCell[,] Cells = null;

        private Point[] bigcellPoly;

        public TomCellWheelViewer()
        {
            InitializeComponent();

            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);

        }

        public Color Color
        {
            set
            {
                Color c = Color.FromArgb(value.A,value.R, value.G, value.B);

                SelCell = null;

                for (int row = 0; row < _CellNumber; row++)
                {
                    for (int col = 0; col < _CellNumber; col++)
                    {
                        if (Cells[row, col] != null)
                        {

                            if (Cells[row, col].FillColor == c)
                            {
                                SelCell = Cells[row, col];
                                break;
                            }
                        }
                    }
                }

                Invalidate();
            }
            get
            {
                if (SelCell != null)
                {
                    return SelCell.FillColor;
                }

                return Color.Empty;
            }
        }
       
        private int _CellNumber = 17;
        public int CellNumber
        {
            get
            {
                return _CellNumber;
            }
            set
            {
                _CellNumber = value;
                if (_CellNumber < 3) _CellNumber = 3;

                if (_CellNumber % 2 == 0)
                {
                    _CellNumber += 1;
                }

                Initialize();
                Invalidate();
            }           
        }

        private int _CellRadius = 8;
        public int CellRadius
        {
            get
            {
                return _CellRadius;
            }
            set
            {
                _CellRadius = value;
                if (_CellRadius < 3) _CellRadius = 3;

                Initialize();
                Invalidate();
            }
        }

        private Color _CellBorderColor = Color.Empty;
        public Color CellBorderColor
        {
            get
            {
                return _CellBorderColor;
            }
            set
            {
                _CellBorderColor = value;
                Initialize();
                Invalidate();
            }
        }

        private void TomCellWheelViewer_Load(object sender, EventArgs e)
        {
            if (DesignMode) Initialize();
        }

        private void TomCellWheelViewer_Paint(object sender, PaintEventArgs e)
        {
            Draw(e.Graphics);
        }

        private void Initialize()
        {
            if (bitmap != null)
            {
                bitmap.Dispose();
                bitmap = null;
            }

            Cells = new TomCell[_CellNumber, _CellNumber];


            int InterWidth = 2 * (int)(CellRadius * Math.Cos(Matematica.DegreesToRadians(30.0)));

            Point Start = new Point(0, 0);

            int diameter = 2 * _CellRadius;
            
            int MatrixWidth = (int)(_CellNumber  * InterWidth);
            int MatrixHeight = (int)(2 * _CellRadius + (_CellNumber - 1) * 1.5 * _CellRadius);

            Start = new Point(
                (int)((Width - MatrixWidth) / 2.0) ,
                (int)((Height - MatrixHeight) / 2.0) + diameter / 2);

            int chk = (_CellNumber - 1) / 2;

            if (chk % 2 == 0)
            {
                Start.X += InterWidth/2;
            }
          

            for (int row = 0; row < _CellNumber; row++)
            {
                for (int col = 0; col < _CellNumber; col++)
                {
                    Point p = new Point(
                                        Start.X + InterWidth * col,
                                        (int)(Start.Y + (_CellRadius * 1.5) * row)
                                        );

                    if (row % 2 != 0)
                    {
                        p.X += InterWidth / 2;
                    }

                    Cells[row, col] = new TomCell(p, _CellRadius, Color.Empty, Color.Empty);
                }
            }


            int cnt = (int)(_CellNumber / 2);

            Point Center = Cells[cnt, cnt].Center;

            int bigcellHeight =MatrixWidth/2+(int)(_CellRadius/2);

            TomCell bigcell = new TomCell(Center, bigcellHeight, Color.Red, Color.Black);
            bigcellPoly= bigcell.Hexagon90();

            TomCell cell = FindSelectCell(Center.X, Center.Y);

            if (cell != null)
            {
                cell.FillColor = Color.White;
                cell.BorderColor = Color.Black;
            }

            int colnumb = cnt;
            
            for (int row = 0; row < _CellNumber; row++)
            {
                for (int col = 0; col < _CellNumber; col++)
                {
                    Point ActPnt = Cells[row, col].Center;

                    if (Matematica.InsidePolygon(bigcellPoly, ActPnt))
                    {
                        double dist = Math.Sqrt(Math.Pow(Center.X - ActPnt.X, 2) + Math.Pow(Center.Y - ActPnt.Y, 2));

                        int x = ActPnt.X - Center.X;
                        int y = ActPnt.Y - Center.Y;

                        int H = (int)(Matematica.AngleFromPoint(new Point(x, y)));

                        double r = dist/ ((_CellNumber * InterWidth)/2);
                        int L = (int)(255 * (1.0 - r));

                        Cells[row, col].FillColor = TomColorUtils.FromHLS(H, L, 255);
                        Cells[row, col].BorderColor = _CellBorderColor;
                    }
                }
            }

        }
       
        private void Draw(Graphics g)
        {
            if (bitmap == null)
            {
                bitmap = new Bitmap(Width, Height);
                Graphics bitmapGraphics = Graphics.FromImage(bitmap);

                for (int row = 0; row < _CellNumber; row++)
                {
                    for (int col = 0; col < _CellNumber; col++)
                    {

                        if (Cells != null)
                        {
                            TomCell c = Cells[row, col];

                            if (c != null)
                            {
                                if (c.FillColor != Color.Empty)
                                {
                                    c.DrawHexagon(bitmapGraphics);
                                }
                            }
                        }
                    }
                }

                //if (DesignMode)
                //{
                //    if (bigcellPoly != null) bitmapGraphics.DrawPolygon(new Pen(Color.Green), bigcellPoly);

                //    bitmapGraphics.DrawLine(new Pen(Color.Black), 0, Height / 2, Width, Height / 2);
                //    bitmapGraphics.DrawLine(new Pen(Color.Black), Width / 2, 0, Width / 2, Height);

                //    bitmapGraphics.DrawRectangle(new Pen(Color.Black), 0, 0, Width - 1, Height - 1);
                //}

                bitmapGraphics.Dispose();

            }

            g.DrawImage(bitmap, new Point(0, 0));

            if (SelCell != null)
            {
                Pen psel;

                for (int x = 0; x < 2; x++)
                {
                    if (x == 0)
                        psel = new Pen(Color.Black, 3);
                    else
                        psel = new Pen(Color.White, 1);

                    SolidBrush brushsel = new SolidBrush(Color.Transparent);

                    SelCell.DrawHexagon(g, psel, brushsel);

                    brushsel.Dispose();
                    psel.Dispose();
                }
            }

        }

        private void TomCellWheelViewer_Resize(object sender, EventArgs e)
        {
            Initialize();
        }

        public delegate void ColorChangeEvent(Color C);

        public event ColorChangeEvent ColorChange;

        private void TomCellWheelViewer_MouseClick(object sender, MouseEventArgs e)
        {

            TomCell Cell = FindSelectCell(e.X, e.Y);

            if (Cell != null)
            {
                SelCell = Cell;

                if (ColorChange != null)
                {
                    ColorChange(SelCell.FillColor);
                }

            }

            Invalidate();

        }

        private TomCell FindSelectCell(int X, int Y)
        {
            for (int row = 0; row < _CellNumber; row++)
            {
                for (int col = 0; col < _CellNumber; col++)
                {
                    if (Cells[row, col] != null)
                    {
                        if (Cells[row, col].FillColor != Color.Empty)
                        {
                            int dx = Math.Abs(Cells[row, col].Center.X - X);
                            int dy = Math.Abs(Cells[row, col].Center.Y - Y);

                            if (dx < Cells[row, col].Radius & dy < Cells[row, col].Radius)
                            {
                                return Cells[row, col];
                            }
                        }
                    }
                }
            }

            return null;
        }

    }
}
