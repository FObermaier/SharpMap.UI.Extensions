﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomColorSelectorByModel : UserControl
    {
        public TomColorSelectorByModel()
        {
            InitializeComponent();
            Structure();
        }

        public enum ColorModel
        {
            RGB,
            CMYK,
            HSL
        }

        private ColorModel _Colormodel = ColorModel.RGB;
        public ColorModel Colormodel
        {
            get
            {
                return _Colormodel;
            }
            set
            {
                _Colormodel = value;
                Structure();
            }
        }

        private void Structure()
        {
            SuspendLayout();

            switch (_Colormodel)
            {
                case ColorModel.RGB:
                    {
                        tomChannel1.Colorchanneltype = TomColorChannel.ColorChannelType.Red;
                        tomChannel2.Colorchanneltype = TomColorChannel.ColorChannelType.Green;
                        tomChannel3.Colorchanneltype = TomColorChannel.ColorChannelType.Blue;
                        tomChannel4.Colorchanneltype = TomColorChannel.ColorChannelType.Alpha;
                        tomChannel5.Colorchanneltype = TomColorChannel.ColorChannelType.None;
                        tomChannel5.Visible = false;
                    }
                    break;
                case ColorModel.CMYK:
                    {
                        tomChannel1.Colorchanneltype = TomColorChannel.ColorChannelType.Cyan;
                        tomChannel2.Colorchanneltype = TomColorChannel.ColorChannelType.Magenta;
                        tomChannel3.Colorchanneltype = TomColorChannel.ColorChannelType.Yellow;
                        tomChannel4.Colorchanneltype = TomColorChannel.ColorChannelType.Color;
                        tomChannel5.Colorchanneltype = TomColorChannel.ColorChannelType.Alpha;
                        tomChannel5.Visible = true;
                    }
                    break;
                case ColorModel.HSL:
                    {
                        tomChannel1.Colorchanneltype = TomColorChannel.ColorChannelType.Hue;
                        tomChannel2.Colorchanneltype = TomColorChannel.ColorChannelType.Light;
                        tomChannel3.Colorchanneltype = TomColorChannel.ColorChannelType.Saturation;
                        tomChannel4.Colorchanneltype = TomColorChannel.ColorChannelType.Alpha;
                        tomChannel5.Colorchanneltype = TomColorChannel.ColorChannelType.None;
                        tomChannel5.Visible = false;
                    }
                    break;
            }

            SetColor();

            ResumeLayout();
        }

        private Color _Color = Color.Red;
        public Color Color
        {
            get
            {
                return _Color;
            }
            set
            {
                _Color = value;
                SetColor();
            }
        }

        private void SetColor()
        {
            switch (_Colormodel)
            {
                case ColorModel.RGB:
                    {
                        tomChannel1.Value = _Color.R;
                        tomChannel2.Value = _Color.G;
                        tomChannel3.Value = _Color.B;
                        tomChannel4.Value = _Color.A;
                    }
                    break;
                case ColorModel.CMYK:
                    {
                        TomCMYK CMYK = TomColorUtils.ToCMYK(_Color);

                        tomChannel1.Value = CMYK.C;
                        tomChannel2.Value = CMYK.M;
                        tomChannel3.Value = CMYK.Y;
                        tomChannel4.Value = CMYK.K;
                        tomChannel5.Value = _Color.A;

                    }
                    break;
                case ColorModel.HSL:
                    {
                        int H = (int)_Color.GetHue();
                        tomChannel1.Value = H;
                        tomChannel2.Value = (int)(_Color.GetBrightness() * 255.0);
                        tomChannel3.Value = (int)(_Color.GetSaturation() * 255.0);

                        Color C = TomColorUtils.FromHLS(H, 128, 255);
                        tomChannel2.Color1 = C;
                        tomChannel3.Color1 = C;

                        tomChannel4.Value = _Color.A;
                    }
                    break;
            }
        }

        private void TomColorSelectorByModel_Load(object sender, EventArgs e)
        {
            Structure();
        }

        public delegate void ColorChangedEvent(Color C);

        public event ColorChangedEvent ColorChanged;

        private void tomChannel_ValueChange(int V)
        {
            Color NewColor = Color.Empty;

            switch (_Colormodel)
            {
                case ColorModel.RGB:
                    {
                        NewColor = Color.FromArgb(
                            tomChannel4.Value,
                            tomChannel1.Value,
                            tomChannel2.Value,
                            tomChannel3.Value);
                    }
                    break;
                case ColorModel.CMYK:
                    {
                        Color C = TomColorUtils.FromCMYK(
                            (byte)tomChannel1.Value,
                            (byte)tomChannel2.Value,
                            (byte)tomChannel3.Value,
                            (byte)tomChannel4.Value);

                        NewColor = Color.FromArgb(tomChannel5.Value, C);


                    }
                    break;
                case ColorModel.HSL:
                    {
                        int H = tomChannel1.Value;

                        Color C = TomColorUtils.FromHLS(
                            H,
                            (double)tomChannel2.Value,
                            (double)tomChannel3.Value);

                        Color C1 = TomColorUtils.FromHLS(H, 128, 255);

                        tomChannel2.Color1 = C1;
                        tomChannel3.Color1 = C1;

                        NewColor = Color.FromArgb(tomChannel4.Value, C);


                    }
                    break;
            }



            if (_Color.Equals(NewColor) == false)
            {
                _Color = NewColor;

                if (ColorChanged != null)
                {
                    ColorChanged(_Color);
                }
            }
        }
    }
}
