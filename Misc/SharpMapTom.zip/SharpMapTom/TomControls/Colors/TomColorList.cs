﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomColorList : UserControl
    {

      

        private string[] Named;

        private string[] GetColors()
        {
            //create a generic list of strings
            List<string> colors = new List<string>();
            //get the color names from the Known color enum
            string[] colorNames = Enum.GetNames(typeof(KnownColor));
            //iterate thru each string in the colorNames array
            foreach (string colorName in colorNames)
            {
                //cast the colorName into a KnownColor
                KnownColor knownColor = (KnownColor)Enum.Parse(typeof(KnownColor), colorName);
                //check if the knownColor variable is a System color
                if (knownColor > KnownColor.Transparent && knownColor < KnownColor.ButtonFace)
                {
                    //add it to our list
                    colors.Add(colorName);
                }
            }
            //return the color list
            return colors.ToArray();
        }
 
        public TomColorList()
        {
            InitializeComponent();

            Named = GetColors();

            comboBoxList.Items.Add("Named Colors");
            comboBoxList.Items.Add("Web Safe Colors");

        }

        private void comboBoxList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Structure();
            FindColor();
        }

        private void Structure()
        {
            if (comboBoxList.SelectedIndex == 0)
            {
                tomColorListBox.Items.Clear();
                tomColorListBox.Items.AddRange(Named);
            }
            else
            {
                tomColorListBox.Items.Clear();
                tomColorListBox.Items.AddRange(TomColorUtils.WebSafe);
            }
        }
        private Color _Color = Color.Empty;
        
        public Color Color
        {
            get
            {
                return _Color;
            }
            set
            {
                _Color = value;
                FindColor();
            }

        }

        private void FindColor()
        {
            _ValueChanging = true;
            string name = "";
            tomColorListBox.SelectedIndex = -1;
            _ValueChanging = false;

            if (comboBoxList.SelectedIndex < 0)
            {
                return;
            }

            if (comboBoxList.SelectedIndex == 0)
            {
                foreach (string s in tomColorListBox.Items)
                {
                    Color c = Color.FromName(s);

                    c = Color.FromArgb(c.A, c.R, c.G, c.B);

                    if (c.Equals(_Color) | (c.R==_Color.R && c.G==_Color.G && c.B==_Color.B && c.A==_Color.A))
                    {
                        name = s;
                        break;
                    }
                }
            }
            else
            {
                name = string.Format("#{0:X2}{1:X2}{2:X2}", _Color.R, _Color.G, _Color.B);
            }

            int i = tomColorListBox.FindString(name);

            _ValueChanging = true;
            if (i >= 0 & name !="")
            {
                tomColorListBox.SelectedIndex = i;
            }
            else
            {
                tomColorListBox.SelectedIndex = -1;
            }
            _ValueChanging = false;
        }

        private void TomColorList_Load(object sender, EventArgs e)
        {
            comboBoxList.SelectedIndex = 0;

            Structure();

            FindColor();
        }


        public delegate void ColorChangedEvent(Color C);

        public event ColorChangedEvent ColorChanged;

        bool _ValueChanging = false;

        private void tomColorListBox_SelectedIndexChanged(object sender, EventArgs e)
        {


            _Color = tomColorListBox.GetSelectedColor();

            if (!_ValueChanging)
            {
                if (ColorChanged != null)
                {
                    ColorChanged(_Color);
                }
            }



        }
    }
}
