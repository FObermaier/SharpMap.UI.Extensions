﻿namespace TomControls
{
    partial class TomColorSelector
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tomCellMatrix = new TomControls.TomCellMatrix();
            this.tomCellWheelViewer = new TomControls.TomCellWheelViewer();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tomColorList = new TomControls.TomColorList();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tomColorSelectorByModelRGB = new TomControls.TomColorSelectorByModel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tomColorSelectorByModelCMYK = new TomControls.TomColorSelectorByModel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tomColorSelectorByModelHSL = new TomControls.TomColorSelectorByModel();
            this.buttonOK = new System.Windows.Forms.Button();
            this.panelActColor = new System.Windows.Forms.Panel();
            this.panelNewColor = new System.Windows.Forms.Panel();
            this.textBoxARGB = new System.Windows.Forms.TextBox();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage5);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(290, 226);
            this.tabControl.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.tomCellMatrix);
            this.tabPage1.Controls.Add(this.tomCellWheelViewer);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(282, 200);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Hex";
            // 
            // tomCellMatrix
            // 
            this.tomCellMatrix.CellColumns = 1;
            this.tomCellMatrix.CellRadius = 6;
            this.tomCellMatrix.CellRows = 16;
            this.tomCellMatrix.CellStyle = TomControls.TomCellStyle.Hexagon;
            this.tomCellMatrix.Color = System.Drawing.Color.Empty;
            this.tomCellMatrix.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomCellMatrix.Location = new System.Drawing.Point(217, 3);
            this.tomCellMatrix.Name = "tomCellMatrix";
            this.tomCellMatrix.ShowSelection = true;
            this.tomCellMatrix.Size = new System.Drawing.Size(60, 192);
            this.tomCellMatrix.TabIndex = 8;
            this.tomCellMatrix.SelectionChange += new TomControls.TomCellMatrix.SelectionChangeEvent(this.tomCellMatrix_SelectionChange);
            this.tomCellMatrix.Load += new System.EventHandler(this.tomCellMatrix_Load);
            // 
            // tomCellWheelViewer
            // 
            this.tomCellWheelViewer.CellBorderColor = System.Drawing.Color.Black;
            this.tomCellWheelViewer.CellNumber = 17;
            this.tomCellWheelViewer.CellRadius = 6;
            this.tomCellWheelViewer.Color = System.Drawing.Color.Empty;
            this.tomCellWheelViewer.Dock = System.Windows.Forms.DockStyle.Left;
            this.tomCellWheelViewer.Location = new System.Drawing.Point(3, 3);
            this.tomCellWheelViewer.Name = "tomCellWheelViewer";
            this.tomCellWheelViewer.Size = new System.Drawing.Size(214, 192);
            this.tomCellWheelViewer.TabIndex = 7;
            this.tomCellWheelViewer.ColorChange += new TomControls.TomCellWheelViewer.ColorChangeEvent(this.ColorChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.White;
            this.tabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage5.Controls.Add(this.tomColorList);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(282, 200);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Palette";
            // 
            // tomColorList
            // 
            this.tomColorList.Color = System.Drawing.Color.Empty;
            this.tomColorList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomColorList.Location = new System.Drawing.Point(3, 3);
            this.tomColorList.Name = "tomColorList";
            this.tomColorList.Size = new System.Drawing.Size(274, 192);
            this.tomColorList.TabIndex = 0;
            this.tomColorList.ColorChanged += new TomControls.TomColorList.ColorChangedEvent(this.ColorChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage2.Controls.Add(this.tomColorSelectorByModelRGB);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(282, 200);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "RGB";
            // 
            // tomColorSelectorByModelRGB
            // 
            this.tomColorSelectorByModelRGB.Color = System.Drawing.Color.Red;
            this.tomColorSelectorByModelRGB.Colormodel = TomControls.TomColorSelectorByModel.ColorModel.RGB;
            this.tomColorSelectorByModelRGB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomColorSelectorByModelRGB.Location = new System.Drawing.Point(3, 3);
            this.tomColorSelectorByModelRGB.Name = "tomColorSelectorByModelRGB";
            this.tomColorSelectorByModelRGB.Size = new System.Drawing.Size(274, 192);
            this.tomColorSelectorByModelRGB.TabIndex = 2;
            this.tomColorSelectorByModelRGB.ColorChanged += new TomControls.TomColorSelectorByModel.ColorChangedEvent(this.ColorChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.tomColorSelectorByModelCMYK);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(282, 200);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "CMYK";
            // 
            // tomColorSelectorByModelCMYK
            // 
            this.tomColorSelectorByModelCMYK.Color = System.Drawing.Color.Red;
            this.tomColorSelectorByModelCMYK.Colormodel = TomControls.TomColorSelectorByModel.ColorModel.CMYK;
            this.tomColorSelectorByModelCMYK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomColorSelectorByModelCMYK.Location = new System.Drawing.Point(3, 3);
            this.tomColorSelectorByModelCMYK.Name = "tomColorSelectorByModelCMYK";
            this.tomColorSelectorByModelCMYK.Size = new System.Drawing.Size(274, 192);
            this.tomColorSelectorByModelCMYK.TabIndex = 2;
            this.tomColorSelectorByModelCMYK.ColorChanged += new TomControls.TomColorSelectorByModel.ColorChangedEvent(this.ColorChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage4.Controls.Add(this.tomColorSelectorByModelHSL);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(282, 200);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "HSL";
            // 
            // tomColorSelectorByModelHSL
            // 
            this.tomColorSelectorByModelHSL.Color = System.Drawing.Color.Red;
            this.tomColorSelectorByModelHSL.Colormodel = TomControls.TomColorSelectorByModel.ColorModel.HSL;
            this.tomColorSelectorByModelHSL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomColorSelectorByModelHSL.Location = new System.Drawing.Point(3, 3);
            this.tomColorSelectorByModelHSL.Name = "tomColorSelectorByModelHSL";
            this.tomColorSelectorByModelHSL.Size = new System.Drawing.Size(274, 192);
            this.tomColorSelectorByModelHSL.TabIndex = 2;
            this.tomColorSelectorByModelHSL.ColorChanged += new TomControls.TomColorSelectorByModel.ColorChangedEvent(this.ColorChanged);
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(236, 231);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(51, 23);
            this.buttonOK.TabIndex = 1;
            this.buttonOK.Text = "Ok";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // panelActColor
            // 
            this.panelActColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelActColor.Location = new System.Drawing.Point(7, 233);
            this.panelActColor.Name = "panelActColor";
            this.panelActColor.Size = new System.Drawing.Size(33, 22);
            this.panelActColor.TabIndex = 3;
            // 
            // panelNewColor
            // 
            this.panelNewColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelNewColor.Location = new System.Drawing.Point(39, 233);
            this.panelNewColor.Name = "panelNewColor";
            this.panelNewColor.Size = new System.Drawing.Size(33, 22);
            this.panelNewColor.TabIndex = 4;
            // 
            // textBoxARGB
            // 
            this.textBoxARGB.Location = new System.Drawing.Point(79, 234);
            this.textBoxARGB.Name = "textBoxARGB";
            this.textBoxARGB.Size = new System.Drawing.Size(73, 20);
            this.textBoxARGB.TabIndex = 5;
            // 
            // TomColorSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.textBoxARGB);
            this.Controls.Add(this.panelNewColor);
            this.Controls.Add(this.panelActColor);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.tabControl);
            this.Name = "TomColorSelector";
            this.Size = new System.Drawing.Size(290, 260);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private TomCellMatrix tomCellMatrix;
        private TomCellWheelViewer tomCellWheelViewer;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Panel panelActColor;
        private System.Windows.Forms.Panel panelNewColor;
        private System.Windows.Forms.TabPage tabPage5;
        private TomColorList tomColorList;
        private TomColorSelectorByModel tomColorSelectorByModelRGB;
        private TomColorSelectorByModel tomColorSelectorByModelCMYK;
        private TomColorSelectorByModel tomColorSelectorByModelHSL;
        private System.Windows.Forms.TextBox textBoxARGB;





    }
}
