﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomColorChannel : UserControl
    {
        public TomColorChannel()
        {
            InitializeComponent();
        }
        
        public enum ColorChannelType
        {
            None,
            Red,
            Green,
            Blue,
            Cyan,
            Magenta,
            Yellow,
            Color,
            Hue,
            Light,
            Saturation,
            Alpha
        }

        private ColorChannelType _Colorchanneltype = ColorChannelType.None;
        public ColorChannelType Colorchanneltype
        {
            get
            {
                return _Colorchanneltype;
            }
            set
            {
                _Colorchanneltype = value;
                Structure();
            }
        }

        public void Structure()
        {
            Minimum = 0;
            Maximum = 255;

            if (tomPaletteSlider.Items.Count() != 2)
            {
                tomPaletteSlider.Items.CreateStandardItems();
            }

            Color0 = Color.White;
            switch (_Colorchanneltype)
            {
                case ColorChannelType.None:
                    Color1 = Color.Black;
                    break;
                case ColorChannelType.Red:
                    Color0 = Color.Black;
                    Color1 = Color.Red;
                    ChannelName = "R:";
                    break;
                case ColorChannelType.Green:
                    Color0 = Color.Black;
                    Color1 = Color.Green;
                    ChannelName = "G:";
                    break;
                case ColorChannelType.Blue:
                    Color0 = Color.Black;
                    Color1 = Color.Blue;
                    ChannelName = "B:";
                    break;
                case ColorChannelType.Cyan:
                    Color0 = Color.White;
                    Color1 = Color.Cyan;
                    ChannelName = "C:";
                    break;
                case ColorChannelType.Magenta:
                    Color0 = Color.White;
                    Color1 = Color.Magenta;
                    ChannelName = "M:";
                    break;
                case ColorChannelType.Yellow:
                    Color0 = Color.White;
                    Color1 = Color.Yellow;
                    ChannelName = "Y:";
                    break;
                case ColorChannelType.Color:
                    Color0 = Color.White;
                    Color1=Color.Black;
                    ChannelName = "K:";
                    break;
                case ColorChannelType.Alpha:
                    Color0 = Color.Transparent;
                    Color1 = Color.Black;
                    ChannelName = "A:";
                    break;
                case ColorChannelType.Hue:
                    tomPaletteSlider.Items.CreateHue();
                    Maximum = 360;
                    ChannelName = "H:";
                    break;
                case ColorChannelType.Light:
                    ChannelName = "L:";
                    tomPaletteSlider.Items[0].Color = Color.Black;
                    tomPaletteSlider.Items[1].Value = 128;
                    tomPaletteSlider.Items.Add(new TomPaletteItem(255,Color.White));
                    break;
                case ColorChannelType.Saturation:
                    Color0 = Color.Gray;
                    ChannelName = "S:";
                    break;
            }

        }
        public string ChannelName
        {
            get
            {
                return labelChannelName.Text;
            }
            set
            {
                labelChannelName.Text = value;
            }
        }

        public int Value
        {
            get
            {
                return (int)numericUpDown.Value;
            }
            set
            {
                _ValueChanging = true;
                numericUpDown.Value = (int)value;
                _ValueChanging = false;
            }
        }

        public int Maximum
        {
            get
            {
                return (int)numericUpDown.Maximum;
            }
            set
            {
                numericUpDown.Maximum = (int)value;
            }
        }

        public int Minimum
        {
            get
            {
                return (int)numericUpDown.Minimum;
            }
            set
            {
                numericUpDown.Minimum = (int)value;
            }
        }

        public Color Color0
        {
            get
            {
                return tomPaletteSlider.MinColor;
            }
            set
            {
                tomPaletteSlider.MinColor = value;
                Invalidate();
            }
        }

        public Color Color1
        {
            
            get
            {
                if (Colorchanneltype == ColorChannelType.Light)
                {
                    return tomPaletteSlider.Items[1].Color;
                }
                else
                {
                    return tomPaletteSlider.MaxColor;
                }
            }
            set
            {
                if (Colorchanneltype == ColorChannelType.Light)
                {
                    tomPaletteSlider.Items[1].Color = value;
                }
                else
                {
                    tomPaletteSlider.MaxColor = value;
                }

                Invalidate();
            }
        }

      

        bool _ValueChanging = false;

        public delegate void ValueChangeEvent(int V);

        public event ValueChangeEvent ValueChange;


        private void numericUpDown_ValueChanged(object sender, EventArgs e)
        {
            if ((int)tomPaletteSlider.Value != numericUpDown.Value)
            {
                tomPaletteSlider.Value = (double)numericUpDown.Value;
            }

            if (!_ValueChanging)
            {
                if (ValueChange != null)
                {
                    ValueChange((int)numericUpDown.Value);
                }
            }


        }

        private void tomPaletteSlider_ValueChanged(object sender)
        {
            
            Value = (int)tomPaletteSlider.Value;

            if (!_ValueChanging)
            {
                if (ValueChange != null)
                {
                    ValueChange((int)numericUpDown.Value);
                }
            }
        }

        
    }
}
