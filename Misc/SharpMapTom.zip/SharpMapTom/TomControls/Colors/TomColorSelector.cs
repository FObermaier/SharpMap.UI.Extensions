﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomColorSelector : UserControl
    {
        public TomColorSelector()
        {
            InitializeComponent();
        }

        private void tomCellMatrix_Load(object sender, EventArgs e)
        {
            int b = 256 - 32;

            tomCellMatrix.Cells[0, 0].FillColor = Color.FromArgb(0, 0, 0, 0);

            for (int i = 0; i < 15; i++)
            {
                tomCellMatrix.Cells[i + 1, 0].FillColor = Color.FromArgb(b, b, b);

                b -= 16;
            }
        }

        private Color _Color=Color.Empty;
        public Color Color
        {
            get
            {
                return _Color;
            }
            set
            {
                _Color = value;
                _NewColor = _Color;

                Structure();
            }
        }

        private Color _NewColor = Color.Empty;

        private void Structure()
        {
            HatchBrush hb = new HatchBrush(HatchStyle.SmallCheckerBoard, Color.Black, Color.White);

            Graphics g1 = panelActColor.CreateGraphics();

            g1.FillRectangle(hb, panelActColor.ClientRectangle);
            g1.FillRectangle(new SolidBrush(_Color), panelActColor.ClientRectangle);

            g1.Dispose();

            Graphics g2 = panelNewColor.CreateGraphics();

            g2.FillRectangle(hb, panelNewColor.ClientRectangle);
            g2.FillRectangle(new SolidBrush(_NewColor), panelNewColor.ClientRectangle);

            g2.Dispose();

            hb.Dispose();


            tomCellWheelViewer.Color = _Color;
            tomCellMatrix.Color = _Color;

            tomColorList.Color = _Color;

            tomColorSelectorByModelRGB.Color = _Color;
            tomColorSelectorByModelCMYK.Color = _Color;
            tomColorSelectorByModelHSL.Color = _Color;

        }

        private void tomCellMatrix_SelectionChange(int row, int col)
        {
            Color c = tomCellMatrix.SelCell.FillColor;
            tomCellWheelViewer.Color = c;

            ColorChanged(c);
        }

        private void ColorChanged(Color C)
        {

            _NewColor = C;

            HatchBrush hb = new HatchBrush(HatchStyle.SmallCheckerBoard, Color.Black, Color.White);

            Graphics g2 = panelNewColor.CreateGraphics();

            g2.FillRectangle(hb, panelNewColor.ClientRectangle);
            g2.FillRectangle(new SolidBrush(_NewColor), panelNewColor.ClientRectangle);

            g2.Dispose();
            hb.Dispose();
            
            
            textBoxARGB.Text = string.Format(string.Format("#{0:X2}{1:X2}{2:X2}{3:X2}", _NewColor.R, _NewColor.G, _NewColor.B, _NewColor.A));

            tomCellMatrix.Color = _NewColor;
            tomCellWheelViewer.Color = _NewColor;

            if (tabControl.SelectedIndex != 1)
            {
                tomColorList.Color = _NewColor;
            }

            if (tabControl.SelectedIndex != 2)
            {
                tomColorSelectorByModelRGB.Color = _NewColor;
            }

            if (tabControl.SelectedIndex != 3)
            {
                tomColorSelectorByModelCMYK.Color = _NewColor;
            }

            if (tabControl.SelectedIndex != 4)
            {
                tomColorSelectorByModelHSL.Color = _NewColor;
            }

        }


        public delegate void ColorChangeEvent(Color C);

        public event ColorChangeEvent ColorChange;

        private void buttonOK_Click(object sender, EventArgs e)
        {
            _Color = _NewColor;

            if (ColorChange != null)
            {
                ColorChange(_Color);
            }
        }


    }
}
