﻿namespace TomControls
{
    partial class TomColorSelectorByModel
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.tomChannel1 = new TomControls.TomColorChannel();
            this.tomChannel2 = new TomControls.TomColorChannel();
            this.tomChannel3 = new TomControls.TomColorChannel();
            this.tomChannel4 = new TomControls.TomColorChannel();
            this.tomChannel5 = new TomControls.TomColorChannel();
            this.tableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.ColumnCount = 1;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel.Controls.Add(this.tomChannel1, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.tomChannel2, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.tomChannel3, 0, 2);
            this.tableLayoutPanel.Controls.Add(this.tomChannel4, 0, 3);
            this.tableLayoutPanel.Controls.Add(this.tomChannel5, 0, 4);
            this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 5;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(245, 170);
            this.tableLayoutPanel.TabIndex = 6;
            // 
            // tomChannel1
            // 
            this.tomChannel1.BackColor = System.Drawing.Color.Transparent;
            this.tomChannel1.ChannelName = "R:";
            this.tomChannel1.Color0 = System.Drawing.Color.White;
            this.tomChannel1.Color1 = System.Drawing.Color.Black;
            this.tomChannel1.Colorchanneltype = TomControls.TomColorChannel.ColorChannelType.None;
            this.tomChannel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tomChannel1.Location = new System.Drawing.Point(3, 3);
            this.tomChannel1.Maximum = 255;
            this.tomChannel1.Minimum = 0;
            this.tomChannel1.Name = "tomChannel1";
            this.tomChannel1.Size = new System.Drawing.Size(239, 25);
            this.tomChannel1.TabIndex = 0;
            this.tomChannel1.Value = 128;
            this.tomChannel1.ValueChange += new TomControls.TomColorChannel.ValueChangeEvent(this.tomChannel_ValueChange);
            // 
            // tomChannel2
            // 
            this.tomChannel2.BackColor = System.Drawing.Color.Transparent;
            this.tomChannel2.ChannelName = "R:";
            this.tomChannel2.Color0 = System.Drawing.Color.White;
            this.tomChannel2.Color1 = System.Drawing.Color.Black;
            this.tomChannel2.Colorchanneltype = TomControls.TomColorChannel.ColorChannelType.None;
            this.tomChannel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tomChannel2.Location = new System.Drawing.Point(3, 37);
            this.tomChannel2.Maximum = 255;
            this.tomChannel2.Minimum = 0;
            this.tomChannel2.Name = "tomChannel2";
            this.tomChannel2.Size = new System.Drawing.Size(239, 25);
            this.tomChannel2.TabIndex = 1;
            this.tomChannel2.Value = 128;
            this.tomChannel2.ValueChange += new TomControls.TomColorChannel.ValueChangeEvent(this.tomChannel_ValueChange);
            // 
            // tomChannel3
            // 
            this.tomChannel3.BackColor = System.Drawing.Color.Transparent;
            this.tomChannel3.ChannelName = "R:";
            this.tomChannel3.Color0 = System.Drawing.Color.White;
            this.tomChannel3.Color1 = System.Drawing.Color.Black;
            this.tomChannel3.Colorchanneltype = TomControls.TomColorChannel.ColorChannelType.None;
            this.tomChannel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tomChannel3.Location = new System.Drawing.Point(3, 71);
            this.tomChannel3.Maximum = 255;
            this.tomChannel3.Minimum = 0;
            this.tomChannel3.Name = "tomChannel3";
            this.tomChannel3.Size = new System.Drawing.Size(239, 25);
            this.tomChannel3.TabIndex = 2;
            this.tomChannel3.Value = 128;
            this.tomChannel3.ValueChange += new TomControls.TomColorChannel.ValueChangeEvent(this.tomChannel_ValueChange);
            // 
            // tomChannel4
            // 
            this.tomChannel4.BackColor = System.Drawing.Color.Transparent;
            this.tomChannel4.ChannelName = "R:";
            this.tomChannel4.Color0 = System.Drawing.Color.White;
            this.tomChannel4.Color1 = System.Drawing.Color.Black;
            this.tomChannel4.Colorchanneltype = TomControls.TomColorChannel.ColorChannelType.None;
            this.tomChannel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tomChannel4.Location = new System.Drawing.Point(3, 105);
            this.tomChannel4.Maximum = 255;
            this.tomChannel4.Minimum = 0;
            this.tomChannel4.Name = "tomChannel4";
            this.tomChannel4.Size = new System.Drawing.Size(239, 25);
            this.tomChannel4.TabIndex = 3;
            this.tomChannel4.Value = 128;
            this.tomChannel4.ValueChange += new TomControls.TomColorChannel.ValueChangeEvent(this.tomChannel_ValueChange);
            // 
            // tomChannel5
            // 
            this.tomChannel5.BackColor = System.Drawing.Color.Transparent;
            this.tomChannel5.ChannelName = "R:";
            this.tomChannel5.Color0 = System.Drawing.Color.White;
            this.tomChannel5.Color1 = System.Drawing.Color.Black;
            this.tomChannel5.Colorchanneltype = TomControls.TomColorChannel.ColorChannelType.None;
            this.tomChannel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.tomChannel5.Location = new System.Drawing.Point(3, 139);
            this.tomChannel5.Maximum = 255;
            this.tomChannel5.Minimum = 0;
            this.tomChannel5.Name = "tomChannel5";
            this.tomChannel5.Size = new System.Drawing.Size(239, 25);
            this.tomChannel5.TabIndex = 4;
            this.tomChannel5.Value = 128;
            this.tomChannel5.ValueChange += new TomControls.TomColorChannel.ValueChangeEvent(this.tomChannel_ValueChange);
            // 
            // TomColorSelectorByModel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel);
            this.Name = "TomColorSelectorByModel";
            this.Size = new System.Drawing.Size(245, 170);
            this.Load += new System.EventHandler(this.TomColorSelectorByModel_Load);
            this.tableLayoutPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private TomColorChannel tomChannel1;
        private TomColorChannel tomChannel2;
        private TomColorChannel tomChannel3;
        private TomColorChannel tomChannel4;
        private TomColorChannel tomChannel5;

    }
}
