﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace TomControls
{
    public static class TomColorUtils
    {

        public static string[] WebSafe = {
        "#FFFFFF", 	"#FFFFCC", 	"#FFFF99", 	"#FFFF66", 	"#FFFF33", 	"#FFFF00",
        "#FFCCFF", 	"#FFCCCC", 	"#FFCC99", 	"#FFCC66", 	"#FFCC33", 	"#FFCC00",
        "#FF99FF", 	"#FF99CC", 	"#FF9999", 	"#FF9966", 	"#FF9933", 	"#FF9900",
        "#FF66FF", 	"#FF66CC", 	"#FF6699", 	"#FF6666", 	"#FF6633", 	"#FF6600",
        "#FF33FF", 	"#FF33CC", 	"#FF3399", 	"#FF3366", 	"#FF3333", 	"#FF3300",
        "#FF00FF", 	"#FF00CC", 	"#FF0099", 	"#FF0066", 	"#FF0033", 	"#FF0000",
                                                                           
        "#CCFFFF", 	"#CCFFCC", 	"#CCFF99", 	"#CCFF66", 	"#CCFF33", 	"#CCFF00",
        "#CCCCFF", 	"#CCCCCC", 	"#CCCC99", 	"#CCCC66", 	"#CCCC33", 	"#CCCC00",
        "#CC99FF", 	"#CC99CC", 	"#CC9999", 	"#CC9966", 	"#CC9933", 	"#CC9900",
        "#CC66FF", 	"#CC66CC", 	"#CC6699", 	"#CC6666", 	"#CC6633", 	"#CC6600",
        "#CC33FF", 	"#CC33CC", 	"#CC3399", 	"#CC3366", 	"#CC3333", 	"#CC3300",
        "#CC00FF", 	"#CC00CC", 	"#CC0099", 	"#CC0066", 	"#CC0033", 	"#CC0000",
                                                                           
        "#99FFFF", 	"#99FFCC", 	"#99FF99", 	"#99FF66", 	"#99FF33", 	"#99FF00",
        "#99CCFF", 	"#99CCCC", 	"#99CC99", 	"#99CC66", 	"#99CC33", 	"#99CC00",
        "#9999FF", 	"#9999CC", 	"#999999", 	"#999966", 	"#999933", 	"#999900",
        "#9966FF", 	"#9966CC", 	"#996699", 	"#996666", 	"#996633", 	"#996600",
        "#9933FF", 	"#9933CC", 	"#993399", 	"#993366", 	"#993333", 	"#993300",
        "#9900FF", 	"#9900CC", 	"#990099", 	"#990066", 	"#990033", 	"#990000",
                                                                           
        "#66FFFF", 	"#66FFCC", 	"#66FF99", 	"#66FF66", 	"#66FF33", 	"#66FF00",
        "#66CCFF", 	"#66CCCC", 	"#66CC99", 	"#66CC66", 	"#66CC33", 	"#66CC00",
        "#6699FF", 	"#6699CC", 	"#669999", 	"#669966", 	"#669933", 	"#669900",
        "#6666FF", 	"#6666CC", 	"#666699", 	"#666666", 	"#666633", 	"#666600",
        "#6633FF", 	"#6633CC", 	"#663399", 	"#663366", 	"#663333", 	"#663300",
        "#6600FF", 	"#6600CC", 	"#660099", 	"#660066", 	"#660033", 	"#660000",
                                                                           
        "#33FFFF", 	"#33FFCC", 	"#33FF99", 	"#33FF66", 	"#33FF33", 	"#33FF00",
        "#33CCFF", 	"#33CCCC", 	"#33CC99", 	"#33CC66", 	"#33CC33", 	"#33CC00",
        "#3399FF", 	"#3399CC", 	"#339999", 	"#339966", 	"#339933", 	"#339900",
        "#3366FF", 	"#3366CC", 	"#336699", 	"#336666", 	"#336633", 	"#336600",
        "#3333FF", 	"#3333CC", 	"#333399", 	"#333366", 	"#333333", 	"#333300",
        "#3300FF", 	"#3300CC", 	"#330099", 	"#330066", 	"#330033", 	"#330000",
                                                                           
        "#00FFFF", 	"#00FFCC", 	"#00FF99", 	"#00FF66", 	"#00FF33", 	"#00FF00",
        "#00CCFF", 	"#00CCCC", 	"#00CC99", 	"#00CC66", 	"#00CC33", 	"#00CC00",
        "#0099FF", 	"#0099CC", 	"#009999", 	"#009966", 	"#009933", 	"#009900",
        "#0066FF", 	"#0066CC", 	"#006699", 	"#006666", 	"#006633", 	"#006600",
        "#0033FF", 	"#0033CC", 	"#003399", 	"#003366", 	"#003333", 	"#003300",
        "#0000FF", 	"#0000CC", 	"#000099", 	"#000066", 	"#000033", 	"#000000"
        };

        public static string[] TomPaletteBase;

        static TomColorUtils()
        {
            List<string> p = new List<string>();
 
            for (int i = 0; i <= 255; i+=15)
            {
                string sc = "#" + string.Format("{0:X2}{1:X2}{2:X2}", i, i, i);
                p.Add(sc);
            }

  	        p.Add("#FF0000");
  	        p.Add("#00FF00");
  	        p.Add("#0000FF");
  	        p.Add("#FFFF00");
  	        p.Add("#00FFFF");
  	        p.Add("#FF00FF");
  	        p.Add("#C0C0C0");

            int s = 255;

            for (int h = 0; h < 360; h += 10)
                for (int l = 64; l <= 192; l += 16)
                {
                    Color c = TomColorUtils.FromHLS(h, l, s);

                    string sc = "#" + string.Format("{0:X2}{1:X2}{2:X2}", c.R, c.G, c.B);
                    p.Add(sc);
                }

            TomPaletteBase = p.ToArray();

        }

        public static Color GetColorFromName(string name)
        {
            Color color = Color.Empty;

            if (name.Substring(0, 1) == "#")
            {
                if (name.Length == 7)
                {
                    int R = Convert.ToInt32(name.Substring(1, 2), 16);
                    int G = Convert.ToInt32(name.Substring(3, 2), 16);
                    int B = Convert.ToInt32(name.Substring(5, 2), 16);

                    color = Color.FromArgb(R, G, B);
                }

            }
            else
            {
                color = Color.FromName(name);
            }

            return color;

        }
      

        public static Color FromCMYK(byte c, byte m, byte y, byte k)
        {
            double AR, AG, AB;
            double C, M, Y, K;

            C = (double)c;
            M = (double)m;
            Y = (double)y;
            K = (double)k;

            C = C / 255.0;
            M = M / 255.0;
            Y = Y / 255.0;
            K = K / 255.0;

            AR = C * (1.0 - K) + K;
            AG = M * (1.0 - K) + K;
            AB = Y * (1.0 - K) + K;

            AR = (1.0 - AR) * 255.0 + 0.5;
            AG = (1.0 - AG) * 255.0 + 0.5;
            AB = (1.0 - AB) * 255.0 + 0.5;

            return Color.FromArgb((byte)AR, (byte)AG, (byte)AB);

        }

        private static byte GetRGBFromHue(float rm1, float rm2, float rh)
        {
            if (rh > 360.0f)
                rh -= 360.0f;
            else if (rh < 0.0f)
                rh += 360.0f;

            if (rh < 60.0f)
                rm1 = rm1 + (rm2 - rm1) * rh / 60.0f;
            else if (rh < 180.0f)
                rm1 = rm2;
            else if (rh < 240.0f)
                rm1 = rm1 + (rm2 - rm1) * (240.0f - rh) / 60.0f;

            return (byte)(rm1 * 255);
        }

        public static Color FromHLS(int h, double l, double s)
        {

            double H = h;
            double L = l / 255.0;
            double S = s / 255.0;

            byte R, G, B; // RGB component values

            if (S == 0.0)
            {
                R = G = B = (byte)(L * 255.0);
            }
            else
            {
                float rm1, rm2;

                if (L <= 0.5f)
                    rm2 = (float)(L + L * S);
                else
                    rm2 = (float)(L + S - L * S);

                rm1 = (float)(2.0f * L - rm2);

                R = GetRGBFromHue(rm1, rm2, (float)(H + 120.0f));
                G = GetRGBFromHue(rm1, rm2, (float)(H));
                B = GetRGBFromHue(rm1, rm2, (float)(H - 120.0f));
            }

            Color c = Color.FromArgb(R, G, B);

            return c;


        }

        public static TomHSL ToHLS(Color color)
        {
            TomHSL HLS;

            HLS.H = (byte)(255 * color.GetHue());
            HLS.L = (byte)(255 * color.GetBrightness());
            HLS.S = (byte)(255 * color.GetSaturation());

            return HLS;
        }

        public static TomCMYK ToCMYK(Color color)
        {
            TomCMYK CMYK;

            double R, G, B;
            R = (double)color.R;
            G = (double)color.G;
            B = (double)color.B;

            R = 1.0 - (R / 255.0);
            G = 1.0 - (G / 255.0);
            B = 1.0 - (B / 255.0);

            double C, M, Y, K;
            if (R < G)
                K = R;
            else
                K = G;
            if (B < K)
                K = B;

            C = (R - K) / (1.0 - K);
            M = (G - K) / (1.0 - K);
            Y = (B - K) / (1.0 - K);

            C = (C * 255) + 0.5;
            M = (M * 255) + 0.5;
            Y = (Y * 255) + 0.5;
            K = (K * 255) + 0.5;

            CMYK.C = (byte)C;
            CMYK.M = (byte)M;
            CMYK.Y = (byte)Y;
            CMYK.K = (byte)K;

            return CMYK;
        }

    }

    public struct TomCMYK
    {
        public byte C;
        public byte M;
        public byte Y;
        public byte K;
    }

    public struct TomHSL
    {
        public int H;
        public byte L;
        public byte S;
    }
}