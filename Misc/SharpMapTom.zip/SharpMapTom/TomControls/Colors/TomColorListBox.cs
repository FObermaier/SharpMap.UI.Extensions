﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomColorListBox : ListBox
    {
        public TomColorListBox()
        {
            //InitializeComponent();
            DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
        }

        private bool _HideColorLabel = false;
        public bool HideColorLabel
        {
            get
            {
                return _HideColorLabel;
            }
            set
            {
                _HideColorLabel = value;
            }
        }

        public Color GetSelectedColor()
        {
            if (SelectedIndex < 0) return Color.Empty;

            return TomColorUtils.GetColorFromName(Items[SelectedIndex].ToString());
        }



        protected override void OnDrawItem(DrawItemEventArgs e)
        {

            base.OnDrawItem(e);

            if (DesignMode && Items.Count == 0)
            {
                if (e.Index == 0)
                {
                    e.Graphics.FillRectangle(SystemBrushes.Window, e.Bounds);
                    e.Graphics.DrawString(this.Name, e.Font, SystemBrushes.WindowText, e.Bounds);
                }
                return;
            }

            string name = Items[e.Index].ToString();
            Color color = TomColorUtils.GetColorFromName(name);

            if (!_HideColorLabel)
            {
                if (e.Index != ListBox.NoMatches)
                {

                    Rectangle ColorRect = new Rectangle(e.Bounds.Left, e.Bounds.Top, e.Bounds.Height, e.Bounds.Height);
                    ColorRect.Inflate(new Size(-2, -2));

                    Rectangle TextRect = new Rectangle(e.Bounds.Left + e.Bounds.Height, e.Bounds.Top, e.Bounds.Width - e.Bounds.Height, e.Bounds.Height);
                    TextRect.Inflate(new Size(-2, -2));


                    SolidBrush solidBrush = new SolidBrush(color);

                    e.DrawBackground();
                    e.Graphics.FillRectangle(solidBrush, ColorRect);
                    solidBrush.Dispose();


                    Brush brush;

                    if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                        brush = SystemBrushes.HighlightText;
                    else
                        brush = SystemBrushes.WindowText;

                    e.Graphics.DrawString(name, Font, brush, TextRect);

                    e.DrawFocusRectangle();


                }

            }
            else
            {

                Rectangle ColorRect = e.Bounds;

                SolidBrush solidBrush = new SolidBrush(color);

                if (!MultiColumn)
                {
                    ColorRect.Inflate(new Size(-2, -2));

                    e.DrawBackground();
                    e.Graphics.FillRectangle(solidBrush, ColorRect);
                    solidBrush.Dispose();

                    Brush brush;

                    if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                        brush = SystemBrushes.HighlightText;
                    else
                        brush = SystemBrushes.WindowText;

                    e.DrawFocusRectangle();

                    brush.Dispose();
                }
                else
                {
                    e.Graphics.FillRectangle(solidBrush, ColorRect);
                }

            }

        
        }



    }
}
