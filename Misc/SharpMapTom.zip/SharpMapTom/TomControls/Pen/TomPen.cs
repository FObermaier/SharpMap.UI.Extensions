﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace TomControls
{
    public class TomPen
    {
        public GraphicsUnit GraphicsUnit = GraphicsUnit.Pixel;

        public Pen Pen = new Pen(Color.Black,0.0f);

        public TomPen Clone()
        {
            TomPen newPen = new TomPen();

            newPen.Pen = (Pen)Pen.Clone();
            newPen.GraphicsUnit = GraphicsUnit;

            return newPen;
        }
    }
}
