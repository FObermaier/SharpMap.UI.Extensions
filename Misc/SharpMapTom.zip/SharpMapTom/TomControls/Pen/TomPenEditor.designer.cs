﻿namespace TomControls
{
    partial class TomPenEditor
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDownThick = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxUnit = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxStartCap = new System.Windows.Forms.ComboBox();
            this.comboBoxEndCap = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxLineJoin = new System.Windows.Forms.ComboBox();
            this.comboBoxDashStyle = new System.Windows.Forms.ComboBox();
            this.comboBoxDashCap = new System.Windows.Forms.ComboBox();
            this.numericUpDownDashOffset = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownMiterLimit = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.tomColorComboBox = new TomControls.TomColorComboBox();
            this.tomPenDashEditor = new TomControls.TomPenDashEditor();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownThick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDashOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMiterLimit)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Spessore:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericUpDownThick
            // 
            this.numericUpDownThick.DecimalPlaces = 3;
            this.numericUpDownThick.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownThick.Location = new System.Drawing.Point(67, 39);
            this.numericUpDownThick.Name = "numericUpDownThick";
            this.numericUpDownThick.Size = new System.Drawing.Size(54, 20);
            this.numericUpDownThick.TabIndex = 1;
            this.numericUpDownThick.ValueChanged += new System.EventHandler(this.numericUpDownThick_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 13);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Colore:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 158);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tratteggio:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxUnit
            // 
            this.comboBoxUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUnit.FormattingEnabled = true;
            this.comboBoxUnit.Location = new System.Drawing.Point(127, 39);
            this.comboBoxUnit.Name = "comboBoxUnit";
            this.comboBoxUnit.Size = new System.Drawing.Size(85, 21);
            this.comboBoxUnit.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 126);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Estremi:";
            // 
            // comboBoxStartCap
            // 
            this.comboBoxStartCap.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxStartCap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStartCap.FormattingEnabled = true;
            this.comboBoxStartCap.ItemHeight = 20;
            this.comboBoxStartCap.Location = new System.Drawing.Point(66, 123);
            this.comboBoxStartCap.Name = "comboBoxStartCap";
            this.comboBoxStartCap.Size = new System.Drawing.Size(70, 26);
            this.comboBoxStartCap.TabIndex = 12;
            this.comboBoxStartCap.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.comboBoxStartCap_DrawItem);
            this.comboBoxStartCap.SelectedIndexChanged += new System.EventHandler(this.comboBoxStartCap_SelectedIndexChanged);
            // 
            // comboBoxEndCap
            // 
            this.comboBoxEndCap.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEndCap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEndCap.FormattingEnabled = true;
            this.comboBoxEndCap.ItemHeight = 20;
            this.comboBoxEndCap.Location = new System.Drawing.Point(142, 123);
            this.comboBoxEndCap.Name = "comboBoxEndCap";
            this.comboBoxEndCap.Size = new System.Drawing.Size(70, 26);
            this.comboBoxEndCap.TabIndex = 13;
            this.comboBoxEndCap.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.comboBoxEndCap_DrawItem);
            this.comboBoxEndCap.SelectedIndexChanged += new System.EventHandler(this.comboBoxEndCap_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 68);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Spigoli:";
            // 
            // comboBoxLineJoin
            // 
            this.comboBoxLineJoin.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxLineJoin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxLineJoin.FormattingEnabled = true;
            this.comboBoxLineJoin.ItemHeight = 20;
            this.comboBoxLineJoin.Location = new System.Drawing.Point(66, 65);
            this.comboBoxLineJoin.Name = "comboBoxLineJoin";
            this.comboBoxLineJoin.Size = new System.Drawing.Size(146, 26);
            this.comboBoxLineJoin.TabIndex = 15;
            this.comboBoxLineJoin.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.comboBoxLineJoin_DrawItem);
            this.comboBoxLineJoin.SelectedIndexChanged += new System.EventHandler(this.comboBoxLineJoin_SelectedIndexChanged);
            // 
            // comboBoxDashStyle
            // 
            this.comboBoxDashStyle.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxDashStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDashStyle.FormattingEnabled = true;
            this.comboBoxDashStyle.ItemHeight = 15;
            this.comboBoxDashStyle.Location = new System.Drawing.Point(67, 155);
            this.comboBoxDashStyle.Name = "comboBoxDashStyle";
            this.comboBoxDashStyle.Size = new System.Drawing.Size(153, 21);
            this.comboBoxDashStyle.TabIndex = 21;
            this.comboBoxDashStyle.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.comboBoxDashStyle_DrawItem);
            this.comboBoxDashStyle.SelectedIndexChanged += new System.EventHandler(this.comboBoxDashStyle_SelectedIndexChanged);
            // 
            // comboBoxDashCap
            // 
            this.comboBoxDashCap.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxDashCap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDashCap.FormattingEnabled = true;
            this.comboBoxDashCap.Location = new System.Drawing.Point(227, 155);
            this.comboBoxDashCap.Name = "comboBoxDashCap";
            this.comboBoxDashCap.Size = new System.Drawing.Size(80, 21);
            this.comboBoxDashCap.TabIndex = 24;
            this.comboBoxDashCap.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.comboBoxDashCap_DrawItem);
            this.comboBoxDashCap.SelectedIndexChanged += new System.EventHandler(this.comboBoxDashCap_SelectedValueChanged);
            this.comboBoxDashCap.SelectedValueChanged += new System.EventHandler(this.comboBoxDashCap_SelectedValueChanged);
            // 
            // numericUpDownDashOffset
            // 
            this.numericUpDownDashOffset.DecimalPlaces = 2;
            this.numericUpDownDashOffset.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownDashOffset.Location = new System.Drawing.Point(314, 155);
            this.numericUpDownDashOffset.Name = "numericUpDownDashOffset";
            this.numericUpDownDashOffset.Size = new System.Drawing.Size(50, 20);
            this.numericUpDownDashOffset.TabIndex = 25;
            this.numericUpDownDashOffset.ValueChanged += new System.EventHandler(this.numericUpDownDashOffset_ValueChanged);
            // 
            // numericUpDownMiterLimit
            // 
            this.numericUpDownMiterLimit.DecimalPlaces = 2;
            this.numericUpDownMiterLimit.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownMiterLimit.Location = new System.Drawing.Point(66, 97);
            this.numericUpDownMiterLimit.Name = "numericUpDownMiterLimit";
            this.numericUpDownMiterLimit.Size = new System.Drawing.Size(55, 20);
            this.numericUpDownMiterLimit.TabIndex = 26;
            this.numericUpDownMiterLimit.ValueChanged += new System.EventHandler(this.numericUpDownMiterLimit_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(2, 100);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "Spigolosità:";
            // 
            // tomColorComboBox
            // 
            this.tomColorComboBox.Color = System.Drawing.Color.Empty;
            this.tomColorComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.tomColorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tomColorComboBox.FormattingEnabled = true;
            this.tomColorComboBox.Location = new System.Drawing.Point(67, 10);
            this.tomColorComboBox.Name = "tomColorComboBox";
            this.tomColorComboBox.Size = new System.Drawing.Size(54, 21);
            this.tomColorComboBox.TabIndex = 23;
            this.tomColorComboBox.ColorChange += new TomControls.TomColorComboBox.ColorChangeEvent(this.tomColorComboBox_ColorChange);
            // 
            // tomPenDashEditor
            // 
            this.tomPenDashEditor.DashPattern = new float[] {
        1F};
            this.tomPenDashEditor.Location = new System.Drawing.Point(65, 182);
            this.tomPenDashEditor.Name = "tomPenDashEditor";
            this.tomPenDashEditor.Size = new System.Drawing.Size(306, 30);
            this.tomPenDashEditor.TabIndex = 28;
            this.tomPenDashEditor.DashChange += new TomControls.TomPenDashEditor.DashChangeEvent(this.tomPenDashEditor_DashChange);
            // 
            // TomPenEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tomPenDashEditor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDownDashOffset);
            this.Controls.Add(this.comboBoxDashCap);
            this.Controls.Add(this.comboBoxDashStyle);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxEndCap);
            this.Controls.Add(this.comboBoxStartCap);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numericUpDownThick);
            this.Controls.Add(this.comboBoxUnit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxLineJoin);
            this.Controls.Add(this.tomColorComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.numericUpDownMiterLimit);
            this.Name = "TomPenEditor";
            this.Size = new System.Drawing.Size(385, 219);
            this.Load += new System.EventHandler(this.PenSelector_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownThick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDashOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMiterLimit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDownThick;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxStartCap;
        private System.Windows.Forms.ComboBox comboBoxEndCap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxLineJoin;
        private System.Windows.Forms.ComboBox comboBoxUnit;
        private System.Windows.Forms.ComboBox comboBoxDashStyle;
        private TomColorComboBox tomColorComboBox;
        private System.Windows.Forms.ComboBox comboBoxDashCap;
        private System.Windows.Forms.NumericUpDown numericUpDownDashOffset;
        private System.Windows.Forms.NumericUpDown numericUpDownMiterLimit;
        private System.Windows.Forms.Label label6;
        private TomPenDashEditor tomPenDashEditor;
    }
}
