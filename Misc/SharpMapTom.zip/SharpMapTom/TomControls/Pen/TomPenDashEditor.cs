﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomPenDashEditor : UserControl
    {

        public delegate void DashChangeEvent();

        public event DashChangeEvent DashChange;

        private float [] _DashPattern = new float[] { 1.0f };

        public float[] DashPattern
        {
            get
            {
                return _DashPattern;
            }
            set
            {
                _DashPattern = value;
                if (_DashPattern.Count() == 0) _DashPattern = new float[] { 1.0f };
                Structure();
            }
        }

        public TomPenDashEditor()
        {
            InitializeComponent();
        }

        private void Structure()
        {
            int n = _DashPattern.Count();

            if (n > 0)
            {
                float ps = ComputeDahsPixelSize(_DashPattern);
                
                numericUpDownPixelSizeChange = true;
                numericUpDownPixelSize.Value = (decimal)ps;
                numericUpDownPixelSizeChange = false;

                int start = 0;
                Color c = Color.Black;

                for (int i = 0; i < n; i++)
                {
                    int p = (int)(_DashPattern[i] / ps);

                    for (int j = start; j < start + p; j++)
                    {
                        tomCellMatrix.Cells[0, j].FillColor = c;
                    }

                    start += p;

                    if (c == Color.Black)
                        c = Color.White;
                    else
                        c = Color.Black;
                }

                tomSlider.Value = start;
                tomCellMatrix.Invalidate();
            }
            else
            {
                tomSlider.Value = 1;
            }
        }

        private float ComputeDahsPixelSize(float[] inDash)
        {
            float[] dash = new float[inDash.Count()]; ;

            Array.Copy(inDash, dash, inDash.Count());

            int n = dash.Count();

            if (n == 0) return float.NaN;
            if (n == 1) return dash[0];

            int mcd = (int)(dash[0] * 100.0f);

            for (int i = 1; i < n; i++)
            {
                int f2 = (int)(dash[i] * 100);
                mcd = MCD(mcd, f2);
            }

            return (float)mcd / 100.0f;
        }

        private bool CheckEqualsColor(Color c1, Color c2)
        {
            if (c1.R != c2.R) return false;
            if (c1.G != c2.G) return false;
            if (c1.B != c2.B) return false;

            return true;
        }

        private void ComputeDashPattern()
        {
            List<float> dash = new List<float>();

            int dashlen = 1;

            Color c = tomCellMatrix.Cells[0, 0].FillColor; // always black;           

            for (int i = 1; i < tomCellMatrix.CellColumns; i++)
            {
                if (!CheckEqualsColor(tomCellMatrix.Cells[0, i].FillColor, c))
                {
                    dash.Add((float)dashlen * (float)numericUpDownPixelSize.Value);
                    c = tomCellMatrix.Cells[0, i].FillColor;
                    dashlen = 1;
                }
                else
                {
                    dashlen++;
                }
            }

            _DashPattern = dash.ToArray();
        }

        static int MCD(int n1, int n2)
        {

            int a = Math.Max(Math.Abs(n1), Math.Abs(n2));
            int b = Math.Min(Math.Abs(n1), Math.Abs(n2));

            if (a == 0 && b == 0) return 0;
	 
	        if(a==0)
	            return b;
	        if(b==0)
	            return a;
	 
    	    //if (a < b) swap(a,b);

            int c = a % b;

            return MCD(b, c);
	    }

        private void tomCellMatrix_SelectionChange(int row, int col)
        {
            if (col == 0) return;

            if (tomCellMatrix.Cells[row, col].FillColor != Color.Gray)
            {
                if (tomCellMatrix.Cells[row, col].FillColor == Color.White)
                {
                    tomCellMatrix.Cells[row, col].FillColor = Color.Black;
                }
                else
                {
                    tomCellMatrix.Cells[row, col].FillColor = Color.White;
                }

                ComputeDashPattern();
                tomCellMatrix.Repaint();

                if (DashChange != null)
                {
                    DashChange();
                }
            }
        }

        private void tomSlider_ValueChange(double V)
        {
            int n = (int)V;

            tomCellMatrix.Cells[0, 0].FillColor = Color.Black;

            for (int i = 1; i < tomCellMatrix.CellColumns; i++)
            {
                if (i < n)
                {
                    if (tomCellMatrix.Cells[0, i].FillColor == Color.Gray)
                    {
                        tomCellMatrix.Cells[0, i].FillColor = Color.Black;
                    }
                }
                else
                {
                    tomCellMatrix.Cells[0, i].FillColor = Color.Gray;
                }
            }

            ComputeDashPattern();
            tomCellMatrix.Repaint();

            if (DashChange != null)
            {
                DashChange();
            }

        }

        private void tomCellMatrix_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < tomCellMatrix.CellColumns; i++)
            {
                tomCellMatrix.Cells[0, i].FillColor = Color.Gray;
                tomCellMatrix.Cells[0, i].BorderColor = Color.Silver;
            }
        }

        private bool numericUpDownPixelSizeChange = false;
        private void numericUpDownPixelSize_ValueChanged(object sender, EventArgs e)
        {

            if (numericUpDownPixelSizeChange == true) return;

            ComputeDashPattern();

            if (DashChange != null)
            {
                DashChange();
            }

        }

      
    }
}
