﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomPenEditor : UserControl
    {

        private Pen _Pen = new Pen(Color.Red);
        public Pen Pen
        {
            get
            {
                return _Pen;
            }
            set
            {
                _Pen = value;
                Structure();
            }
        }

        GraphicsUnit _GraphicsUnit = GraphicsUnit.Pixel;
        public GraphicsUnit GraphicsUnit
        {
            get
            {
                return _GraphicsUnit;
            }
            set
            {
                _GraphicsUnit = value;
                Structure();
            }
        }

        public TomPenEditor()
        {
            InitializeComponent();
        }

        private void PenSelector_Load(object sender, EventArgs e)
        {

            comboBoxUnit.Items.Add(GraphicsUnit.Pixel);
            comboBoxUnit.Items.Add(GraphicsUnit.Millimeter);
            comboBoxUnit.Items.Add(GraphicsUnit.Inch);
            comboBoxUnit.Items.Add(GraphicsUnit.Point);
            comboBoxUnit.Items.Add(GraphicsUnit.Display);
            comboBoxUnit.Items.Add(GraphicsUnit.Document);
            comboBoxUnit.Items.Add(GraphicsUnit.World);

            comboBoxDashStyle.Items.Add(DashStyle.Solid);
            comboBoxDashStyle.Items.Add(DashStyle.Dash);
            comboBoxDashStyle.Items.Add(DashStyle.Dot);
            comboBoxDashStyle.Items.Add(DashStyle.DashDot);
            comboBoxDashStyle.Items.Add(DashStyle.DashDotDot);
            comboBoxDashStyle.Items.Add(DashStyle.Custom);

            comboBoxStartCap.Items.Add(LineCap.Flat);
            comboBoxStartCap.Items.Add(LineCap.Square);
            comboBoxStartCap.Items.Add(LineCap.Round);
            comboBoxStartCap.Items.Add(LineCap.Triangle);
            comboBoxStartCap.Items.Add(LineCap.NoAnchor);
            comboBoxStartCap.Items.Add(LineCap.SquareAnchor);
            comboBoxStartCap.Items.Add(LineCap.RoundAnchor);
            comboBoxStartCap.Items.Add(LineCap.DiamondAnchor);
            comboBoxStartCap.Items.Add(LineCap.ArrowAnchor);

            comboBoxEndCap.Items.Add(LineCap.Flat);
            comboBoxEndCap.Items.Add(LineCap.Square);
            comboBoxEndCap.Items.Add(LineCap.Round);
            comboBoxEndCap.Items.Add(LineCap.Triangle);
            comboBoxEndCap.Items.Add(LineCap.NoAnchor);
            comboBoxEndCap.Items.Add(LineCap.SquareAnchor);
            comboBoxEndCap.Items.Add(LineCap.RoundAnchor);
            comboBoxEndCap.Items.Add(LineCap.DiamondAnchor);
            comboBoxEndCap.Items.Add(LineCap.ArrowAnchor);

            comboBoxDashCap.Items.Add(DashCap.Flat);
            comboBoxDashCap.Items.Add(DashCap.Round);
            comboBoxDashCap.Items.Add(DashCap.Triangle);

            comboBoxLineJoin.Items.Add(LineJoin.Miter);
            comboBoxLineJoin.Items.Add(LineJoin.Bevel);
            comboBoxLineJoin.Items.Add(LineJoin.Round);
            //comboBoxLineJoin.Items.Add(LineJoin.MiterClipped);


            Structure();
        }


        public delegate void PenChangeEvent(Pen pen);

        public event PenChangeEvent PenChange;

        private bool Initializing = false;
        private void Structure()
        {
            Initializing = true;

            tomColorComboBox.Color = _Pen.Color;
            numericUpDownThick.Value = (decimal)_Pen.Width;

            comboBoxUnit.SelectedIndex = comboBoxUnit.Items.IndexOf(GraphicsUnit);
            numericUpDownDashOffset.Value = (decimal)_Pen.DashOffset;

            comboBoxDashStyle.SelectedIndex = comboBoxDashStyle.Items.IndexOf(_Pen.DashStyle);

            if (_Pen.DashStyle == DashStyle.Custom)
            {
                tomPenDashEditor.Visible = true;
                tomPenDashEditor.DashPattern = _Pen.DashPattern;
            }
            else
            {
                tomPenDashEditor.Visible = false;
            }
            comboBoxDashCap.SelectedIndex = comboBoxDashCap.Items.IndexOf(_Pen.DashCap);


            comboBoxStartCap.SelectedIndex = comboBoxStartCap.Items.IndexOf(_Pen.StartCap);
            comboBoxEndCap.SelectedIndex = comboBoxEndCap.Items.IndexOf(_Pen.EndCap);
            comboBoxLineJoin.SelectedIndex = comboBoxLineJoin.Items.IndexOf(_Pen.LineJoin);
            
            numericUpDownMiterLimit.Value = (decimal)Pen.MiterLimit;

            Initializing = false;

        }

        private enum comboLineStyle
        {
            Full,
            ToHalf,
            FromHalf,
            Angle
        }

        private void drawComboLine(DrawItemEventArgs e, Pen p, comboLineStyle lineStyle, bool DrawBackground )
        {
            if (e.Index < 0) return;

            Rectangle r = e.Bounds;
            r.Inflate(-2, -2);


            if(DrawBackground)e.DrawBackground();

            switch(lineStyle)
            {
                case comboLineStyle.Full:
                    {
                        e.Graphics.DrawLine(p, r.Left, r.Top + r.Height / 2, r.Right, r.Top + r.Height / 2);
                    }
                    break;
                case comboLineStyle.ToHalf:
                    {
                        e.Graphics.DrawLine(p, r.Left, r.Top + r.Height / 2, r.Right - r.Width / 3, r.Top + r.Height / 2);
                    }
                    break;
                case comboLineStyle.FromHalf:
                    {
                        e.Graphics.DrawLine(p, r.Left + r.Width / 3, r.Top + r.Height / 2, r.Right, r.Top + r.Height / 2);
                    }
                    break;
                case comboLineStyle.Angle:
                    {

                        Point[] pt = new Point[] {
                                                    new Point(r.Left,             r.Top + 5),
                                                    new Point(r.Left + r.Height,  r.Top + 5),
                                                    new Point(r.Left + r.Height,  r.Top + r.Height -1),                        
                                                  };

                        e.Graphics.DrawLines(p, pt);
                    }
                    break;
            }

        }
        
        private void comboBoxStartCap_DrawItem(object sender, DrawItemEventArgs e)
        {
            Brush brush;

            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                brush = SystemBrushes.HighlightText;
            else
                brush = SystemBrushes.WindowText;

            Pen p = new Pen(brush, 9);
            p.StartCap = (LineCap)comboBoxStartCap.Items[e.Index]; 

            drawComboLine(e, p, comboLineStyle.FromHalf, true);
            p.Dispose();

            p = new Pen(new SolidBrush(Color.Red), 1);
            drawComboLine(e, p, comboLineStyle.FromHalf, false);
            p.Dispose();
        }
        private void comboBoxStartCap_SelectedIndexChanged(object sender, EventArgs e)
        {
            Pen.StartCap = (LineCap)comboBoxStartCap.Items[comboBoxStartCap.SelectedIndex];

            if (PenChange != null)
            {
                PenChange(_Pen);
            }

        }

        private void comboBoxEndCap_DrawItem(object sender, DrawItemEventArgs e)
        {
            Brush brush;

            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                brush = SystemBrushes.HighlightText;
            else
                brush = SystemBrushes.WindowText;

            Pen p = new Pen(brush, 9);
            p.EndCap = (LineCap)comboBoxEndCap.Items[e.Index];

            drawComboLine(e, p, comboLineStyle.ToHalf, true);
            p.Dispose();

            p = new Pen(new SolidBrush(Color.Red), 1);
            drawComboLine(e, p, comboLineStyle.ToHalf, false);
            p.Dispose();
        }
        private void comboBoxEndCap_SelectedIndexChanged(object sender, EventArgs e)
        {
            Pen.EndCap = (LineCap)comboBoxEndCap.Items[comboBoxEndCap.SelectedIndex];

            if (PenChange != null)
            {
                PenChange(_Pen);
            }
        }

        private void comboBoxDashCap_DrawItem(object sender, DrawItemEventArgs e)
        {
            Brush brush;

            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                brush = SystemBrushes.HighlightText;
            else
                brush = SystemBrushes.WindowText;

            Pen p = new Pen(brush, 5);
            p.DashStyle = DashStyle.DashDotDot;
            p.DashCap = (DashCap)comboBoxDashCap.Items[e.Index];

            drawComboLine(e, p, comboLineStyle.Full, true);
            p.Dispose();

        }
        private void comboBoxDashCap_SelectedValueChanged(object sender, EventArgs e)
        {
            Pen.DashCap = (DashCap)comboBoxDashCap.Items[comboBoxDashCap.SelectedIndex];

            if (PenChange != null)
            {
                PenChange(_Pen);
            }
        }

        private void comboBoxDashStyle_DrawItem(object sender, DrawItemEventArgs e)
        {

            if (e.Index < 0) return;

            Brush brush;

            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                brush = SystemBrushes.HighlightText;
            else
                brush = SystemBrushes.WindowText;

            if (e.Index < 5)
            {

                Pen p = new Pen(brush,3);

                p.DashStyle = (DashStyle)comboBoxDashStyle.Items[e.Index];

                drawComboLine(e, p, comboLineStyle.Full, true);

                p.Dispose();
            }
            else
            {
                e.DrawBackground();
                e.Graphics.DrawString("Custom", e.Font, brush, new Point(e.Bounds.Left + 1, e.Bounds.Top + 1));
            }

            e.DrawFocusRectangle();

        }
        private void comboBoxDashStyle_SelectedIndexChanged(object sender, EventArgs e)
        {

            _Pen.DashStyle = (DashStyle)comboBoxDashStyle.Items[comboBoxDashStyle.SelectedIndex];

            if ((DashStyle)comboBoxDashStyle.Items[comboBoxDashStyle.SelectedIndex] == DashStyle.Custom)
            {
                tomPenDashEditor.Visible = true;
                tomPenDashEditor.DashPattern = Pen.DashPattern;
            
            }
            else
            {                
                tomPenDashEditor.Visible = false;
            }


            if (PenChange != null)
            {
                PenChange(_Pen);
            }
        }

        private void comboBoxLineJoin_DrawItem(object sender, DrawItemEventArgs e)
        {

            if (e.Index < 0) return;

            Brush brush;

            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                brush = SystemBrushes.HighlightText;
            else
                brush = SystemBrushes.WindowText;

            Pen p = new Pen(brush, 9);
            p.LineJoin = (LineJoin)comboBoxLineJoin.Items[e.Index];

            drawComboLine(e, p, comboLineStyle.Angle, true);

            e.Graphics.DrawString(p.LineJoin.ToString(), comboBoxLineJoin.Font, brush, new PointF(e.Bounds.Left + e.Bounds.Height + 3, e.Bounds.Top + 1));
            p.Dispose();
        }
        private void comboBoxLineJoin_SelectedIndexChanged(object sender, EventArgs e)
        {
            Pen.LineJoin = (LineJoin)comboBoxLineJoin.Items[comboBoxLineJoin.SelectedIndex];

            if (Pen.LineJoin != LineJoin.Miter) 
                numericUpDownMiterLimit.Enabled = false;
            else
                numericUpDownMiterLimit.Enabled = true;


            if (PenChange != null)
            {
                PenChange(_Pen);
            }
        }
        
        private void tomColorComboBox_ColorChange(Color C)
        {

            _Pen.Color = C;

            if (PenChange != null)
            {
                PenChange(_Pen);
            }
        }

        private void numericUpDownThick_ValueChanged(object sender, EventArgs e)
        {
            Pen.Width = (float)numericUpDownThick.Value;

            if (PenChange != null)
            {
                PenChange(_Pen);
            }
        }

        private void tomPenDashEditor_DashChange()
        {
            float [] dash = tomPenDashEditor.DashPattern;

            if (dash.Count() > 0)
            {
                Pen.DashPattern = dash;

                if (PenChange != null)
                {
                    PenChange(_Pen);
                }
            }
        }

        private void numericUpDownDashOffset_ValueChanged(object sender, EventArgs e)
        {
            if (Initializing) return;

            Pen.DashOffset = (float)numericUpDownDashOffset.Value;

            if (PenChange != null)
            {
                PenChange(_Pen);
            }

        }

        private void numericUpDownMiterLimit_ValueChanged(object sender, EventArgs e)
        {
            if (Initializing) return;

            Pen.MiterLimit = (float)numericUpDownMiterLimit.Value;

            if (PenChange != null)
            {
                PenChange(_Pen);
            }
        }


 
 



 
     
    }
}
