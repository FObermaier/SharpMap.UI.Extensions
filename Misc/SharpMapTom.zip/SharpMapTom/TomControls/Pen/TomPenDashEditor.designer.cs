﻿namespace TomControls
{
    partial class TomPenDashEditor
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDownPixelSize = new System.Windows.Forms.NumericUpDown();
            this.tomSlider = new TomControls.TomSlider();
            this.tomCellMatrix = new TomControls.TomCellMatrix();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPixelSize)).BeginInit();
            this.SuspendLayout();
            // 
            // numericUpDownPixelSize
            // 
            this.numericUpDownPixelSize.DecimalPlaces = 2;
            this.numericUpDownPixelSize.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownPixelSize.Location = new System.Drawing.Point(252, 4);
            this.numericUpDownPixelSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownPixelSize.Name = "numericUpDownPixelSize";
            this.numericUpDownPixelSize.Size = new System.Drawing.Size(51, 20);
            this.numericUpDownPixelSize.TabIndex = 4;
            this.numericUpDownPixelSize.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownPixelSize.ValueChanged += new System.EventHandler(this.numericUpDownPixelSize_ValueChanged);
            // 
            // tomSlider
            // 
            this.tomSlider.BackColor = System.Drawing.Color.Transparent;
            this.tomSlider.IntegerValues = true;
            this.tomSlider.Location = new System.Drawing.Point(1, 13);
            this.tomSlider.MarkerAlignement = TomControls.TomSlider.MarkerAlignementTypes.LeftTop;
            this.tomSlider.MarkerSize = 9;
            this.tomSlider.Max = 30D;
            this.tomSlider.Min = 1D;
            this.tomSlider.Name = "tomSlider";
            this.tomSlider.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.tomSlider.ShowLine = false;
            this.tomSlider.Size = new System.Drawing.Size(250, 14);
            this.tomSlider.TabIndex = 5;
            this.tomSlider.Value = 30D;
            this.tomSlider.ValueChange += new TomControls.TomSlider.ValueChangeEvent(this.tomSlider_ValueChange);
            // 
            // tomCellMatrix
            // 
            this.tomCellMatrix.BackColor = System.Drawing.Color.Transparent;
            this.tomCellMatrix.CellColumns = 30;
            this.tomCellMatrix.CellRadius = 4;
            this.tomCellMatrix.CellRows = 1;
            this.tomCellMatrix.CellStyle = TomControls.TomCellStyle.Square;
            this.tomCellMatrix.Color = System.Drawing.Color.Empty;
            this.tomCellMatrix.Location = new System.Drawing.Point(-1, 3);
            this.tomCellMatrix.Name = "tomCellMatrix";
            this.tomCellMatrix.ShowSelection = false;
            this.tomCellMatrix.Size = new System.Drawing.Size(248, 10);
            this.tomCellMatrix.TabIndex = 3;
            this.tomCellMatrix.SelectionChange += new TomControls.TomCellMatrix.SelectionChangeEvent(this.tomCellMatrix_SelectionChange);
            this.tomCellMatrix.Load += new System.EventHandler(this.tomCellMatrix_Load);
            // 
            // TomPenDashEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.numericUpDownPixelSize);
            this.Controls.Add(this.tomSlider);
            this.Controls.Add(this.tomCellMatrix);
            this.Name = "TomPenDashEditor";
            this.Size = new System.Drawing.Size(306, 30);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPixelSize)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDownPixelSize;
        private TomCellMatrix tomCellMatrix;
        private TomSlider tomSlider;
    }
}
