﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomEnComboBox : ComboBox
    {

        private ToolStripDropDown _PopupDropDown = new ToolStripDropDown();
        private ToolStripControlHost _ControlHost = null;

        protected Control _UserControl = null;

        public TomEnComboBox()
        {
            InitializeComponent();

            DrawMode = DrawMode.OwnerDrawFixed;
            DropDownStyle = ComboBoxStyle.DropDownList;
        }

        public const uint WM_COMMAND = 0x0111;
        public const uint WM_USER = 0x0400;
        public const uint WM_REFLECT = WM_USER + 0x1C00;
        public const uint WM_LBUTTONDOWN = 0x0201;

        public const uint CBN_DROPDOWN = 7;
        public const uint CBN_CLOSEUP = 8;

        public static uint HIWORD(int n)
        {
            return (uint)(n >> 16) & 0xffff;
        }

        public override bool PreProcessMessage(ref Message m)
        {
            if (m.Msg == (WM_REFLECT + WM_COMMAND))
            {
                if (HIWORD((int)m.WParam) == CBN_DROPDOWN)
                    return false;
            }
            return base.PreProcessMessage(ref m);
        }


        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_LBUTTONDOWN)
            {
                ShowDropDown();
                return;
            }

            if (m.Msg == (WM_REFLECT + WM_COMMAND))
            {
                switch (HIWORD((int)m.WParam))
                {
                    case CBN_DROPDOWN:
                        ShowDropDown();
                        return;

                    case CBN_CLOSEUP:
                        //if ((DateTime.Now - m_sShowTime).Seconds > 1)
                            HideDropDown();
                        return;
                }
            }

            base.WndProc(ref m);
        }

        protected void HideDropDown()
        {
            _PopupDropDown.Visible = false;
        }

        protected void ShowDropDown()
        {
            

            if (_ControlHost == null)
            {
                if (_UserControl == null)
                {
                    Label lb = new Label();
                    lb.Text = "No control";
                   _ControlHost = new ToolStripControlHost(lb);
                }
                else
                {
                    _ControlHost = new ToolStripControlHost(_UserControl);
                }
            }

            _ControlHost.Padding = new Padding(1);
            _ControlHost.Margin = new Padding(0);
            _PopupDropDown.Padding = new Padding(0);
            _PopupDropDown.Margin = new Padding(0);

             if(_PopupDropDown.Items.Count==0)
            {
                _PopupDropDown.Items.Add(_ControlHost);

            }
            
            Point loc = this.Parent.PointToScreen(this.Location);

            Screen currentScreen = Screen.FromPoint(loc);
            Rectangle screenRect = currentScreen.WorkingArea;

            if (loc.X < screenRect.X)
                loc.X = screenRect.X;
            else if ((loc.X + _PopupDropDown.Width) > screenRect.Right)
                loc.X = screenRect.Right - _PopupDropDown.Width;

            if ((loc.Y + this.Height + _PopupDropDown.Height) > screenRect.Bottom)
                loc.Offset(0, -_PopupDropDown.Height);
            else
                loc.Offset(0, this.Height);

            _PopupDropDown.Show(loc.X, loc.Y);
            //_PopupDropDown.Show();
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            base.OnDrawItem(e);
        }


        
    }

 
}
