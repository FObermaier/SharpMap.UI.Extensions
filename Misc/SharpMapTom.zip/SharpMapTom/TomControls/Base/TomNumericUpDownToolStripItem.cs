﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace TomControls
{
        [Serializable]
        [ToolStripItemDesignerAvailability(ToolStripItemDesignerAvailability.ToolStrip)]
        public class TomNumericUpDownToolStripItem : ToolStripControlHost
        {
            public TomNumericUpDownToolStripItem()
                : base(new NumericUpDown())
            {
                NumericUpDownControl.Minimum = -1000000;
                NumericUpDownControl.Maximum = +1000000;

                NumericUpDownControl.DecimalPlaces = 2;
                NumericUpDownControl.Increment = 1;
            }

            public NumericUpDown NumericUpDownControl
            {
                get 
                { 
                    return Control as NumericUpDown; 
                }
               
            }

            private bool settingvalue = false;

            public decimal Value
            {
                get
                {
                    return NumericUpDownControl.Value;
                }
                set
                {
                    settingvalue = true;
                    NumericUpDownControl.Value = value;
                    settingvalue = false;
                }
            }

            public decimal Minimum
            {
                get
                {
                    return NumericUpDownControl.Minimum;
                }
                set
                {
                    NumericUpDownControl.Minimum = value;
                }
            }

            public decimal Maximum
            {
                get
                {
                    return NumericUpDownControl.Maximum;
                }
                set
                {
                    NumericUpDownControl.Maximum = value;
                }
            }

            public int DecimalPlaces
            {
                get
                {
                    return NumericUpDownControl.DecimalPlaces;
                }
                set
                {
                    NumericUpDownControl.DecimalPlaces = value;
                }
            }


            public event EventHandler ValueChanged;

            public void OnValueChanged(object sender, EventArgs e)
            {
                if (!settingvalue)
                {
                    if (ValueChanged != null)
                    {
                        ValueChanged(this, e);
                    }
                }
            }

            protected override void OnSubscribeControlEvents(Control control)
            {
                base.OnSubscribeControlEvents(control);
                (control as NumericUpDown).ValueChanged += OnValueChanged;
            }

            protected override void OnUnsubscribeControlEvents(Control control)
            {
                base.OnUnsubscribeControlEvents(control);
                (control as NumericUpDown).ValueChanged -= OnValueChanged;
            }

         
        }
    
}