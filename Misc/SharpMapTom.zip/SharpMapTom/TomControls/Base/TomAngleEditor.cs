﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomAngleEditor : UserControl
    {
        private void SetControStyle()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            //SetStyle(ControlStyles.UserMouse, true);
            //BackColor = Color.Transparent;
        }

        public TomAngleEditor()
        {
            InitializeComponent();

            SetControStyle();
        }

        private double _Angle = 0;
        public double Angle
        {
            get
            {
                return _Angle;
            }
            set
            {
                _Angle = value;
                Invalidate();
            }
        }

        private void Draw(Graphics g)
        {

            int radius = Math.Min(ClientRectangle.Width, ClientRectangle.Height) / 2 - 2;

            Point Center = new Point(ClientRectangle.Width / 2, ClientRectangle.Height / 2);

            Rectangle CircleRect = new Rectangle(Center.X - radius, Center.Y - radius, 2 * radius, 2 * radius);

            g.DrawEllipse(new Pen(Color.Black), CircleRect);

            g.DrawArc(new Pen(Color.Red, 3), CircleRect, 0f, (float)-_Angle);

            PointF c = Matematica.Rotate(new PointF(radius, 0), (float)Matematica.DegreesToRadians(_Angle));

            g.DrawLine(new Pen(Color.Red, 3), Center, new Point((int)c.X + Center.X, (int)c.Y + Center.Y));
            g.DrawLine(new Pen(Color.Red, 3), Center, new Point(Center.X + radius, Center.Y));

        }

        private void TomAngleEditor_Paint(object sender, PaintEventArgs e)
        {
            Draw(e.Graphics);
        }

        public delegate void AngleChangedEvent(double angle);

        public event AngleChangedEvent AngleChanged;


        private void TomAngleEditor_MouseMove(object sender, MouseEventArgs e)
        {

            if (e.Button != MouseButtons.Left) return;

            Point Center = new Point(ClientRectangle.Width / 2, ClientRectangle.Height / 2);

            _Angle = 360 - 180 - Matematica.AngleFromPoint(new PointF(Center.X - e.X, Center.Y - e.Y));

            if (AngleChanged != null)
            {
                AngleChanged(_Angle);
            }

            Invalidate();

        }
    }
}
