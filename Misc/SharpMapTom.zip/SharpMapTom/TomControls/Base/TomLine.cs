﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace TomControls
{
    public class TomLineSegment
    {
        private PointF _P0 = PointF.Empty;
        public PointF P0
        {
            get
            {
                return _P0;
            }
            set
            {
                _P0 = value;
            }
        }

        private PointF _P1 = PointF.Empty;
        public PointF P1
        {
            get
            {
                return _P1;
            }
            set
            {
                _P1 = value;
            }
        }

        public RectangleF Rectangle
        {
            get
            {
                return Matematica.GetNormalizedRectangle(_P0, _P1);
            }
        }

        public TomLineSegment()
        {
        }

        public TomLineSegment(PointF p0, PointF p1)
        {
            _P0 = p0;
            _P1 = p1;

        }

        public float InfiniteDistance(PointF point)
        {
          
            return (float)(Math.Abs((_P1.X - _P0.X) * (_P0.Y - point.Y) - (_P0.X - point.X) * (_P1.Y - _P0.Y)) /
                            Math.Sqrt(Math.Pow(_P1.X - _P0.X, 2) + Math.Pow(_P1.Y - _P0.Y, 2)));
        }


        public float Distance(PointF point)
        {
            if (_P0.IsEmpty | _P1.IsEmpty) return float.NaN;

            float distance = InfiniteDistance(point);
            if (Rectangle.Contains(point)) return distance;

            return float.NaN;
        }

        public bool HitTestSegment(PointF point, float eps = -1)
        {
            if (eps == -1) eps = Matematica.Distance(_P1, _P1) / 100;

            float d = Distance(point);

            if (float.IsNaN(d)) return false;

            if (d < eps) return true;

            return false;
        }

        public bool HitTestLine(PointF point, float eps = -1)
        {
            if (eps == -1) eps = Matematica.Distance(_P1, _P1) / 100;

            float d = InfiniteDistance(point);

            if (d < eps) return true;

            return false;
        }


        public float Length
        {
            get
            {
                return Matematica.Distance(_P0, _P1);
            }
            set
            {
                float d = Length;

                float k = value / d;
                _P1.X *= k;
                _P1.Y *= k;
            }
        }


    }


}
