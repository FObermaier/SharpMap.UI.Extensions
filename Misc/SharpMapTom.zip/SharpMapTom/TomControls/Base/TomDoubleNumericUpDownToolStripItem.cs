﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms.Design;
using System.Windows.Forms;

namespace TomControls
{
    
        [Serializable]
        [ToolStripItemDesignerAvailability(ToolStripItemDesignerAvailability.ToolStrip)]
        public class TomDoubleNumericUpDownToolStripItem : ToolStripControlHost
        {
            public TomDoubleNumericUpDownToolStripItem()
                : base(new TomDoubleUpDown())
            {
               
            }

            public TomDoubleUpDown DoubleNumericUpDownControl
            {
                get 
                {
                    return Control as TomDoubleUpDown; 
                }
               
            }


            public Label Label1
            {
                get
                {
                    return DoubleNumericUpDownControl.label1;
                }
            }

            public Label Label2
            {
                get
                {
                    return DoubleNumericUpDownControl.label2;
                }
            }

            public decimal Value1
            {
                get
                {
                    return DoubleNumericUpDownControl.Value1;
                }
                set
                {
                    DoubleNumericUpDownControl.Value1 = value;
                }
            }
            public decimal Value2
            {
                get
                {
                    return DoubleNumericUpDownControl.Value2;
                }
                set
                {
                    DoubleNumericUpDownControl.Value2 = value;
                }
            }

            public decimal Minimum1
            {
                get
                {
                    return DoubleNumericUpDownControl.numericUpDown1.Minimum;
                }
                set
                {
                    DoubleNumericUpDownControl.numericUpDown1.Minimum = value;
                }
            }
            public decimal Minimum2
            {
                get
                {
                    return DoubleNumericUpDownControl.numericUpDown2.Minimum;
                }
                set
                {
                    DoubleNumericUpDownControl.numericUpDown2.Minimum = value;
                }
            }

            public decimal Maximum1
            {
                get
                {
                    return DoubleNumericUpDownControl.numericUpDown1.Maximum;
                }
                set
                {
                    DoubleNumericUpDownControl.numericUpDown1.Maximum = value;
                }
            }
            public decimal Maximum2
            {
                get
                {
                    return DoubleNumericUpDownControl.numericUpDown2.Maximum;
                }
                set
                {
                    DoubleNumericUpDownControl.numericUpDown2.Maximum = value;
                }
            }

            public int DecimalPlaces1
            {
                get
                {
                    return DoubleNumericUpDownControl.numericUpDown1.DecimalPlaces;
                }
                set
                {
                    DoubleNumericUpDownControl.numericUpDown1.DecimalPlaces = value;
                }
            }

            public int DecimalPlaces2
            {
                get
                {
                    return DoubleNumericUpDownControl.numericUpDown2.DecimalPlaces;
                }
                set
                {
                    DoubleNumericUpDownControl.numericUpDown2.DecimalPlaces = value;
                }
            }



            public event EventHandler ValueChanged;

            public void OnValueChanged(object sender, EventArgs e)
            {
               
                    if (ValueChanged != null)
                    {
                        ValueChanged(this, e);
                    }
            }

            protected override void OnSubscribeControlEvents(Control control)
            {
                base.OnSubscribeControlEvents(control);
                (control as TomDoubleUpDown).ValueChanged += OnValueChanged;
            }

            protected override void OnUnsubscribeControlEvents(Control control)
            {
                base.OnUnsubscribeControlEvents(control);
                (control as TomDoubleUpDown).ValueChanged -= OnValueChanged;
            }

         
        }
    
    
    }
