﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomSlider : UserControl
    {
        public TomSlider()
        {
            InitializeComponent();
        }

        private double _Min = 0;
        public double Min
        {
            get
            {
                return _Min;
            }
            set
            {
                _Min = value;
                Invalidate();
            }
        }

        private double _Max = 100;
        public double Max
        {
            get
            {
                return _Max;
            }
            set
            {
                _Max = value;
                Invalidate();
            }
        }

        private double _Value = 50;
        public double Value
        {
            get
            {
                return _Value;
            }
            set
            {
                _Value = value;
                Invalidate();
            }
        }

        private int _MarkerSize = 7;
        public int MarkerSize
        {
            get
            {
                return _MarkerSize;
            }
            set
            {
                _MarkerSize = value;
                Invalidate();
            }
        }

        public enum MarkerAlignementTypes
        {
            Center,
            LeftTop,
            rightBottom
        }

        private MarkerAlignementTypes _MarkerAlignement = MarkerAlignementTypes.Center;
        public MarkerAlignementTypes MarkerAlignement
        {
            get
            {
                return _MarkerAlignement;
            }
            set
            {
                _MarkerAlignement = value;
                Invalidate();
            }
        }
       
        private Orientation _Orientation = Orientation.Horizontal;
        public Orientation Orientation
        {
            get
            {
                return _Orientation;
            }
            set
            {
                _Orientation = value;
                Invalidate();
            }
        }

        private bool _IntegerValues = false;
        public bool IntegerValues
        {
            get
            {
                return _IntegerValues;
            }
            set
            {
                _IntegerValues = value;
                Invalidate();
            }
        }


        private bool _ShowLine = true;
        public bool ShowLine
        {
            get
            {
                return _ShowLine;
            }
            set
            {
                _ShowLine = value;
                Invalidate();
            }
        }



        private void Draw(Graphics g)
        {
                if (Max == Min) Max = Max + 1;

                double v = (_Value - Min) / (Max - Min);

                Point p1= new Point();
                Point p2= new Point();

                Point pm = new Point();
                Arrow.Orientation ArrowOrientation = Arrow.Orientation.East;

                if (Orientation == Orientation.Horizontal)
                {
                    int wdt = ClientRectangle.Width - 2 * _MarkerSize;
                    int x = (int)Math.Round(wdt * v) + _MarkerSize;

                    switch (_MarkerAlignement)
                    {
                        case MarkerAlignementTypes.Center:
                            {
                                p1 = new Point(_MarkerSize + 1, Height / 2);
                                p2 = new Point(Width - _MarkerSize - 1, Height / 2);
                                pm = new Point(x, Height / 2);
                                ArrowOrientation = Arrow.Orientation.North;
                            }
                            break;
                        case MarkerAlignementTypes.LeftTop:
                            {
                                p1 = new Point(_MarkerSize + 1, 1);
                                p2 = new Point(Width - _MarkerSize - 1, 1);
                                pm = new Point(x, 1);
                                ArrowOrientation = Arrow.Orientation.North;
                            }
                            break;
                        case MarkerAlignementTypes.rightBottom:
                            {
                                p1 = new Point(_MarkerSize + 1, Height - 1);
                                p2 = new Point(Width - _MarkerSize - 1, Height - 1);
                                pm = new Point(x, Height - 1);
                                ArrowOrientation = Arrow.Orientation.South;
                            }
                            break;
                    }

                }
                else
                {
                    int hgt = ClientRectangle.Height - 2 * _MarkerSize;
                    int y = (int)Math.Round(hgt - (hgt * v))+_MarkerSize;

                    switch (_MarkerAlignement)
                    {
                        case MarkerAlignementTypes.Center:
                            {
                                p1 = new Point(Width / 2, _MarkerSize + 1);
                                p2 = new Point(Width / 2, Height - _MarkerSize - 1);
                                pm = new Point(Width / 2, y);
                                ArrowOrientation = Arrow.Orientation.West;

                            }
                            break;
                        case MarkerAlignementTypes.LeftTop:
                            {
                                p1 = new Point(1, _MarkerSize + 1);
                                p2 = new Point(1, Height - _MarkerSize - 1);
                                pm = new Point(1, y);
                                ArrowOrientation = Arrow.Orientation.West;
                            }
                            break;
                        case MarkerAlignementTypes.rightBottom:
                            {
                                p1 = new Point(Width - 1, _MarkerSize + 1);
                                p2 = new Point(Width - 1, Height - _MarkerSize - 1);
                                pm = new Point(Width - 1, y);
                                ArrowOrientation = Arrow.Orientation.East;
                            }
                            break;
                    }

                }

                if (_ShowLine)
                {
                    Pen p = new Pen(Color.Black, (float)1.0);
                    p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;

                    g.DrawLine(p, p1, p2);
                    p.Dispose();
                }

                Arrow.DrawArrow(g, ArrowOrientation, pm, _MarkerSize);

        }
 
        private void TomSlider_Paint(object sender, PaintEventArgs e)
        {
            Draw(e.Graphics);
        }

        public delegate void ValueChangeEvent(double V);

        public event ValueChangeEvent ValueChange;

        private void ComputeValue(int X,int Y)
        {
            double sz =0;

            double v = 0;

            if( Orientation== Orientation.Horizontal)
            {
                sz = Width - MarkerSize * 2 - 2;
                v=X;
            }
            else
            {
                sz = Height - MarkerSize * 2 - 2;
                v = Y;
            }

            //if (v < MarkerSize | v > MarkerSize + sz) return;

            double vv = ((v - MarkerSize) / sz) * (_Max - _Min) + _Min;

            if (Orientation == Orientation.Vertical)
            {
                vv = _Max - vv;
            }
            
            _Value = vv;

            if (_IntegerValues) _Value = Math.Round(_Value);

            if (_Value < _Min) _Value = _Min;
            if (_Value > _Max) _Value = _Max;

            if (ValueChange != null)
            {
                ValueChange(_Value);
            }
        }

        private void TomSlider_MouseUp(object sender, MouseEventArgs e)
        {
            ComputeValue(e.X, e.Y);

            Invalidate();
        }

        private void TomSlider_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != System.Windows.Forms.MouseButtons.None)
            {
                ComputeValue(e.X, e.Y);

                Invalidate();
            }
        }


    }
}
