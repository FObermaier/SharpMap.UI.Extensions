﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace TomControls
{
    //        using GeoAPI.Geometries;
    //using GisSharpBlog.NetTopologySuite.Geometries;

    //namespace GisSharpBlog.NetTopologySuite.Simplify
    //{
    /// <summary>
    /// Simplifies a line (sequence of points) using
    /// the standard Douglas-Peucker algorithm.
    /// </summary>
    public class DouglasPeuckerLineSimplifier
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pts"></param>
        /// <param name="Tolerance"></param>
        /// <returns></returns>
        public static PointF[] Simplify(PointF[] pts, float Tolerance)
        {
            DouglasPeuckerLineSimplifier simp = new DouglasPeuckerLineSimplifier(pts);
            simp.DistanceTolerance = Tolerance;
            return simp.Simplify();
        }

        public static PointF[] Simplify(PointF[] pts)
        {
            float k = 100;

            float Xmin = pts[0].X;
            float Xmax = pts[0].X;
            float Ymin = pts[0].Y;
            float Ymax = pts[0].Y;

            for (int i = 0; i < pts.Count(); i++)
            {
                if (pts[i].X < Xmin) Xmin = pts[i].X;
                if (pts[i].Y < Ymin) Ymin = pts[i].Y;
                if (pts[i].X > Xmax) Xmax = pts[i].X;
                if (pts[i].Y > Ymax) Ymax = pts[i].Y;
            }


            DouglasPeuckerLineSimplifier simp = new DouglasPeuckerLineSimplifier(pts);
            simp.DistanceTolerance = Math.Min((Xmax - Xmin) / k, (Ymax - Ymin) / k);

            return simp.Simplify();
        }

        private PointF[] pts;
        private bool[] usePt;
        private float distanceTolerance;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pts"></param>
        public DouglasPeuckerLineSimplifier(PointF[] pts)
        {
            this.pts = pts;
        }

        /// <summary>
        /// 
        /// </summary>
        public float DistanceTolerance
        {
            get
            {
                return distanceTolerance;
            }
            set
            {
                distanceTolerance = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public PointF[] Simplify()
        {
            usePt = new bool[pts.Length];
            for (int i = 0; i < pts.Length; i++)
                usePt[i] = true;

            SimplifySection(0, pts.Length - 1);
            
            List<PointF> coordList = new List<PointF>();
            
            for (int i = 0; i < pts.Length; i++)
                if (usePt[i])
                    coordList.Add(pts[i]);

            return coordList.ToArray();
        }

        private TomLineSegment seg = new TomLineSegment();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        private void SimplifySection(int i, int j)
        {
            //TomLineSegment seg = new TomLineSegment(pts[i], pts[j]);

            if ((i + 1) == j)
                return;
            seg.P0 = pts[i];
            seg.P1 = pts[j];
            double maxDistance = -1.0;
            int maxIndex = i;
            for (int k = i + 1; k < j; k++)
            {
                double distance = seg.InfiniteDistance(pts[k]);

                if (distance > maxDistance)
                {
                    maxDistance = distance;
                    maxIndex = k;
                }
            }
            if (maxDistance <= DistanceTolerance)
                for (int k = i + 1; k < j; k++)
                    usePt[k] = false;
            else
            {
                SimplifySection(i, maxIndex);
                SimplifySection(maxIndex, j);
            }
        }
    }

}
