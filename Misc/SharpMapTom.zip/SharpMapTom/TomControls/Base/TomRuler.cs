﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomRuler : UserControl
    {
        public enum RulerAligns
        {
            Top,
            Center,
            Bottom
        }

        public TomRuler()
        {
            InitializeComponent();
            
            //this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            //this.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            
            
            this.Font = new Font("Arial", 7.25f);

        }

        private RulerAligns _RulerAlign;
        [Category("RulerOptions")]
        public RulerAligns RulerAlign
        {
            get
            {
                return _RulerAlign;
            }
            set
            {
                _RulerAlign = value;
                Invalidate();
            }
        }
        
        private Orientation _Orientation = Orientation.Horizontal;
        [Category("RulerOptions")]
        public Orientation Orientation
        {
            get
            {
                return _Orientation;
            }
            set
            {
                _Orientation = value;
                Invalidate();
            }
        }

        private double _Min = 0;
        [Category("RulerOptions")]
        public double Min
        {
            get
            {
                return _Min;
            }
            set
            {
                _Min = value;
                Invalidate();
            }
        }

        private double _Max = 10;
        [Category("RulerOptions")]
        public double Max
        {
            get
            {
                return _Max;
            }
            set
            {
                _Max = value;
                Invalidate();
            }
        }

        private double _MajorInterval;
        [Category("RulerOptions")]
        public double MajorInterval
        {
            get
            {
                if (_MajorInterval == 0) _MajorInterval = 1; 
                return _MajorInterval;
            }
            set
            {
                _MajorInterval = value;
                Invalidate();
            }
        }

        private int _MajorIntervalDivisions;
        [Category("RulerOptions")]
        public int MajorIntervalDivisions
        {
            get
            {
                return _MajorIntervalDivisions;
            }
            set
            {
                _MajorIntervalDivisions = value;
                Invalidate();
            }
        }

        private int _MarkFactorDivision;
        [Category("RulerOptions")]
        public int MarkFactorDivision
        {
            get
            {
                if (_MarkFactorDivision == 0) _MarkFactorDivision = 5;
                return _MarkFactorDivision;
            }
            set
            {
                _MarkFactorDivision = value;
                Invalidate();
            }
        }

        private int _MarkFactorMiddle;
        [Category("RulerOptions")]
        public int MarkFactorMiddle
        {
            get
            {
                if (_MarkFactorMiddle == 0) _MarkFactorMiddle = 2;
                return _MarkFactorMiddle;
            }
            set
            {
                _MarkFactorMiddle = value;
                Invalidate();
            }
        }

        private Border3DStyle _i3DBorderStyle = Border3DStyle.Etched;
        public new Border3DStyle BorderStyle
        {
            get
            {
                return _i3DBorderStyle;
            }
            set
            {
                _i3DBorderStyle = value;
                Invalidate();
            }
        }


        protected Bitmap _Bitmap = null;

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            //base.OnPaint(e);
            if (_Bitmap == null)
            {
                _Bitmap = new Bitmap(Width, Height);
            }

            Graphics g = Graphics.FromImage(_Bitmap);

            DrawBackGround(g);
            Draw(g);

            g.Dispose();

            e.Graphics.DrawImage(_Bitmap, 0, 0);
        }

        protected void DrawBackGround(Graphics g)
        {
            g.FillRectangle(new SolidBrush(BackColor), 0, 0, Width, Height);
        }

        protected void Draw(Graphics g)
        {

			if (!this.Visible) return;

			if (this.Width < 1 || this.Height < 1) 
			{
				return;
			}

            double min, max; 
            if (_MajorIntervalDivisions > 0)
            {
                min = Math.Floor(_Min / _MajorIntervalDivisions) * _MajorIntervalDivisions;
                max = Math.Ceiling(_Max / _MajorIntervalDivisions) * _MajorIntervalDivisions;
            }

            else
            {
                min = Math.Floor(_Min );
                max = Math.Ceiling(_Max);
            }

            if (max == min) max = max + 1;

            double delta = max - min;

            double interval = _MajorInterval;

            int k = 0;
            for (double v = min; v < max; v += _MajorInterval)
            {
                DrawValue(g, v);
                k++;

                if (k > 10000) break;
                
                if (_MajorIntervalDivisions > 1)
                {
                    for (int d = 1; d < _MajorIntervalDivisions; d++)
                    {
                        double value = v + (double)d * (_MajorInterval / _MajorIntervalDivisions);

                        if (d == _MajorIntervalDivisions / 2)
                        {
                            DrawMark(g, value, MarkFactorMiddle);
                        }
                        else
                        {
                            DrawMark(g, value, MarkFactorDivision);
                        }
                    }
                }

                if (_RulerAlign != RulerAligns.Center)
                    DrawMark(g, v, 1);
            }

            if (BorderStyle == Border3DStyle.Flat)
            {
                g.DrawRectangle(Pens.Black, 0, 0, ClientRectangle.Width - 1, ClientRectangle.Height - 1);
            }
            else
            {
                ControlPaint.DrawBorder3D(g, ClientRectangle, _i3DBorderStyle);
            }
       
            
        }


        protected int ValueToPixel(double value)
        {
            if (Orientation == Orientation.Horizontal)
            {
                return (int)Math.Round(((value - Min) / (Max - Min)) * Width);
            }

            return (int)Math.Round(((value - Min) / (Max - Min)) * Height);

        }


        protected double PixelToValue(int pixel)
        {
            if (Orientation == Orientation.Horizontal)
            {
                return ((double)pixel / (double)Width) * (_Max - _Min) + _Min;
            }

            return ((double)pixel / (double)Height) * (_Max - _Min) + _Min;
        }

        private void DrawValue(Graphics g, double value)
        {
            StringFormat format = new StringFormat(StringFormatFlags.MeasureTrailingSpaces);

            if (Orientation == Orientation.Vertical)
                format.FormatFlags |= StringFormatFlags.DirectionVertical;


            SizeF size = g.MeasureString((value).ToString(), this.Font);//, 0, format);

            Point drawingPoint;
            int iX = 0;
            int iY = 0;

            int position;

            if (Orientation == Orientation.Horizontal)
            {
                position = ValueToPixel(value);

                switch (_RulerAlign)
                {
                    case RulerAligns.Bottom:
                        {
                            iX = position - (int)size.Width - 2;
                            iY = 2;
                            break;
                        }
                    case RulerAligns.Center:
                        {
                            iX = position - (int)size.Width / 2;
                            iY = (Height - (int)size.Height) / 2 - 2;
                            break;
                        }
                    case RulerAligns.Top:
                        {
                            iX = position - (int)size.Width - 2;
                            iY = Height - 2 - (int)size.Height;
                            break;
                        }
                }

                drawingPoint = new Point(iX, iY);
            }
            else
            {
                position = ValueToPixel(value);

                switch (_RulerAlign)
                {
                    case RulerAligns.Top:
                        {
                            iX = 0;
                            iY = position - (int)size.Height - 2;
                            break;
                        }
                    case RulerAligns.Center:
                        {
                            iX = (Width - (int)size.Width) / 2 - 1;
                            iY = position - (int)size.Height / 2;
                            break;
                        }
                    case RulerAligns.Bottom:
                        {
                            iX = Width - 4 - (int)size.Width;
                            iY = position - (int)size.Height - 2;
                            break;
                        }
                }

                drawingPoint = new Point(iX, iY);
            }

            g.DrawString(value.ToString(), this.Font, new SolidBrush(this.ForeColor), drawingPoint, format);
        }

        private void DrawMark(Graphics g, double value, int Proportion)
        {
            int position;

            int iMarkStart = 0, iMarkEnd = 0;

            if (Orientation == Orientation.Horizontal)
            {
                position = ValueToPixel(value);

                switch (_RulerAlign)
                {
                    case RulerAligns.Bottom:
                        {
                            iMarkStart = Height - Height / Proportion;
                            iMarkEnd = Height;
                            break;
                        }
                    case RulerAligns.Center:
                        {
                            iMarkStart = (Height - Height / Proportion) / 2 - 1;
                            iMarkEnd = iMarkStart + Height / Proportion;
                            break;
                        }
                    case RulerAligns.Top:
                        {
                            iMarkStart = 0;
                            iMarkEnd = Height / Proportion;
                            break;
                        }
                }

                Line(g, position, iMarkStart, position, iMarkEnd);
            }
            else
            {
                position = ValueToPixel(value);

                switch (_RulerAlign)
                {
                    case RulerAligns.Top:
                        {
                            iMarkStart = Width - Width / Proportion;
                            iMarkEnd = Width;
                            break;
                        }
                    case RulerAligns.Center:
                        {
                            iMarkStart = (Width - Width / Proportion) / 2 - 1;
                            iMarkEnd = iMarkStart + Width / Proportion;
                            break;
                        }
                    case RulerAligns.Bottom:
                        {
                            iMarkStart = 0;
                            iMarkEnd = Width / Proportion;
                            break;
                        }
                }

                Line(g, iMarkStart, position, iMarkEnd, position);
            }
        }

        private void Line(Graphics g, int x1, int y1, int x2, int y2)
        {
            
            Pen pen = new Pen(this.ForeColor);

            g.DrawLine(pen, x1, y1, x2, y2);

            pen.Dispose();

        }

        public void SetLinePosition(Color color, int X, int Y)
        {
            if (_Bitmap == null) return;

            Graphics g = CreateGraphics();

            g.DrawImage(_Bitmap, new Point(0,0));
            
            Pen p = new Pen(color);

            if (Orientation == Orientation.Horizontal)
            {
                g.DrawLine(p,X,1,X,ClientRectangle.Height-2);
            }
            else
            {
                g.DrawLine(p, 1, Y, ClientRectangle.Width-2, Y);
            }

            p.Dispose();

            g.Dispose();
        }
    }
}
