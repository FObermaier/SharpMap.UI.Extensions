﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomImageComboBox : ComboBox
    {
        public TomImageComboBox()
        {
            InitializeComponent();
            DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
        }

        public enum ItemStyle
        {
            Image,
            ImageAndText
        }

        private ItemStyle _Style;
        public ItemStyle Style
        {
            get
            {
                return _Style;
            }
            set
            {
                _Style = value;
            }
        }

        public ImageList ImageList
        {
            get;
            set;
        }


        //ObjectCollection _collection;
        //[MergableProperty(false)]
        //[Editor("System.Windows.Forms.Design.ListControlStringCollectionEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(TomImageComboBoxItem))]
        //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        //[Localizable(true)]
        //public new ComboBox.ObjectCollection Items 
        //{
        //    get
        //    {
        //        return _collection;
        //    }
        //}


        protected override void OnMeasureItem(MeasureItemEventArgs e)
        {
            TomImageComboBoxItem Itm = (TomImageComboBoxItem)Items[e.Index];

            e.ItemHeight = ImageList.Images[Itm.ImageIndex].Height;
            e.ItemWidth = this.DropDownWidth;

            base.OnMeasureItem(e);
        }


        protected override void OnDrawItem(DrawItemEventArgs e)
        {

            base.OnDrawItem(e);

            if (e.Index == -1) return;

            if (DesignMode && Items.Count == 0)
            {
                if (e.Index == 0)
                {
                    e.Graphics.FillRectangle(SystemBrushes.Window, e.Bounds);
                    e.Graphics.DrawString(this.Name, e.Font, SystemBrushes.WindowText, e.Bounds);
                }
                return;
            }

            if (ImageList == null) return;
            if (ImageList.Images.Count == 0) return;


            if (e.Index != ListBox.NoMatches)
            {
                TomImageComboBoxItem Itm = (TomImageComboBoxItem)Items[e.Index];

                Rectangle rect = e.Bounds;
                Rectangle ImageRect = new Rectangle(e.Bounds.Left, e.Bounds.Top, e.Bounds.Height, e.Bounds.Height);
                ImageRect.Inflate(new Size(-2, -2));

                Rectangle TextRect = new Rectangle(e.Bounds.Left + e.Bounds.Height, e.Bounds.Top, e.Bounds.Width - e.Bounds.Height, e.Bounds.Height);
                TextRect.Inflate(new Size(-2, -2));

                Image Img = ImageList.Images[Itm.ImageIndex];

                e.DrawBackground();

                e.Graphics.DrawImage(Img, ImageRect);


                Brush brush;

                if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                    brush = SystemBrushes.HighlightText;
                else
                    brush = SystemBrushes.WindowText;

                if (Style == ItemStyle.ImageAndText)
                {
                    e.Graphics.DrawString(Itm.Text, Font, brush, TextRect);
                }

                e.DrawFocusRectangle();


            }



        }

       

    }

    [Serializable()]
    public class TomImageComboBoxItem
    {
        public int ImageIndex
        {
            get;
            set;
        }
        public string Text
        {
            get;
            set;
        }

        public TomImageComboBoxItem()
        {
            ImageIndex = -1;
            Text = "new item";
        }
        public TomImageComboBoxItem(int imageIndex, string text)
        {
            ImageIndex = imageIndex;
            Text = text;
        }

        public override string ToString()
        {
            return this.Text;
        }
    }


}
