﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomTextRuler : TomRuler
    {
        List<Rectangle> items = new List<Rectangle>();

        
        List<Rectangle> tabs = new List<Rectangle>();

        private const int iLeftTopMargin = 0;
        private const int iRightBottomMargin = 1;
        private const int iLeftUpperIndent = 2;
        private const int iLeftDownIndent = 3;
        private const int iRightIndent = 4;

        //private const int iLeftIndentMarkSelfMoving = 5;
        //private const int iLeftIndentMarkAllMoving = 6;

        public TomTextRuler()
        {
            InitializeComponent();

            tabs.Clear();

            //margins and indents
            items.Add(new Rectangle());
            items.Add(new Rectangle());
            items.Add(new Rectangle());
            items.Add(new Rectangle());
            items.Add(new Rectangle());
            //items.Add(new Rectangle());
            //items.Add(new Rectangle());

            /*
                * items[0] - left margin
                * items[1] - right margin
                * items[2] - left indent upper mark
                * items[3] - left indent lower mark (picture region)
                * items[4] - right indent mark
                * items[5] - left indent mark (self-moving region)
                * items[6] - left indent mark (all-moving region)
            */

        }


        private double[] values = new double[5];

        private double _DocSize;
        [Category("RulerOptions")]
        public double DocSize
        {
            get
            {
                if (_DocSize <= 0) _DocSize = 21;
                return _DocSize;
            }
            set
            {
                _DocSize = value;
                Invalidate();
            }

        }

        [Category("RulerOptions")]
        public double LeftTopMargin
        {
            get
            {
                return values[iLeftTopMargin];
            }
            set
            {
                values[iLeftTopMargin] = value;
                Invalidate();
            }
        }

        [Category("RulerOptions")]
        public double RightBottomMargin
        {
            get
            {
                return values[iRightBottomMargin];
            }
            set
            {
                values[iRightBottomMargin] = value;
                Invalidate();
            }
        }


        [Category("RulerOptions")]
        public double LeftUpperIndent
        {
            get
            {
                return values[iLeftUpperIndent];
            }
            set
            {
                values[iLeftUpperIndent] = value;
                Invalidate();
            }
        }


        [Category("RulerOptions")]
        public double LeftDownIndent
        {
            get
            {
                return values[iLeftDownIndent];
            }
            set
            {
                values[iLeftDownIndent] = value;
                Invalidate();
            }
        }

        [Category("RulerOptions")]
        public double RightIndent
        {
            get
            {
                return values[iRightIndent];
            }
            set
            {
                values[iRightIndent] = value;
                Invalidate();
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {

            if (_Bitmap == null)
            {
                _Bitmap = new Bitmap(Width, Height);
            }

            Graphics g = Graphics.FromImage(_Bitmap);

            DrawBackGround(g);
            
            DrawMargins(g);

            Draw(g);            

            if (Orientation == Orientation.Horizontal)
            {
                DrawIndents(g);
            }

            e.Graphics.DrawImage(_Bitmap, 0, 0);
        }

        private void DrawMargins(Graphics g)
        {


            if (Orientation == Orientation.Horizontal)
            {
                if (values[iLeftTopMargin] >= 0)
                {
                    items[iLeftTopMargin] = new Rectangle(0, 0, ValueToPixel(values[iLeftTopMargin]), Height);
                    g.FillRectangle(Brushes.DarkGray, items[iLeftTopMargin]);
                }
                if (values[iRightBottomMargin] >= 0)
                {
                    items[iRightBottomMargin] = new Rectangle(Width - ValueToPixel(_DocSize-values[iRightBottomMargin]), 0, Width, Height);
                    g.FillRectangle(Brushes.DarkGray, items[iRightBottomMargin]);
                }
            }
            else
            {
                if (values[iLeftTopMargin] >= 0)
                {
                    items[iLeftTopMargin] = new Rectangle(0, 0, Width, ValueToPixel(values[iLeftTopMargin]));
                    g.FillRectangle(Brushes.DarkGray, items[iLeftTopMargin]);
                }

                if (values[iRightBottomMargin] >= 0)
                {
                    items[iRightBottomMargin] = new Rectangle(0, Height - ValueToPixel(_DocSize - values[iRightBottomMargin]), Width, Height);
                    g.FillRectangle(Brushes.DarkGray, items[iRightBottomMargin]);
                }

            }
        }

        private void DrawIndents(Graphics g)
        {
            items[iLeftUpperIndent] = new Rectangle(ValueToPixel(values[iLeftUpperIndent]) - 4, 0, 9, 8);
            items[iLeftDownIndent] = new Rectangle(ValueToPixel(values[iLeftDownIndent]) - 4, Height - 14, 9, 14);
            items[iRightIndent] = new Rectangle(ValueToPixel(DocSize -values[iRightIndent]) - 4, Height - 9, 9, 9);

            g.DrawImage(Properties.Resources.l_indet_pos_upper, items[iLeftUpperIndent]);
            g.DrawImage(Properties.Resources.l_indent_pos_lower, items[iLeftDownIndent]);
            g.DrawImage(Properties.Resources.r_indent_pos, items[iRightIndent]);

        }

        private void DrawTabs(Graphics g)
        {
            int i = 0;

            if (tabs.Count == 0)
                return;

            for (i = 0; i <= tabs.Count - 1; i++)
            {
                g.DrawImage(Properties.Resources.tab_pos, tabs[i]);
            }
        }

        private int captured = -1;
        private int downPixel;
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            for (int i = 0; i < 5; i++)
            {

                if (Orientation == Orientation.Horizontal)
                {
                    if (items[i].Contains(new Point(e.X, e.Y)))
                    {
                        captured = i;
                        downPixel = e.X;

                    }
                }
                else
                {
                    downPixel = e.Y;
                }
            }

        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.None) return;

            if(captured >=0)
            {
                if (Orientation == Orientation.Horizontal)
                {
                    //Rectangle r = items[captured];
                    //r.X += (e.X - downPixel);
                    //items[captured] = r;

                    values[captured] = PixelToValue(e.X);

                    Refresh();
                }
            }

            base.OnMouseMove(e);
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
        }
    }
}
