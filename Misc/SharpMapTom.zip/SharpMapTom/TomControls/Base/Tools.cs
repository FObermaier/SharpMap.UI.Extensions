﻿#define DEBUG

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using System.Drawing.Text;

namespace TomControls
{

    public static class FontEnumerator
    {
        public static InstalledFontCollection InstalledFontCollection;
        public static FontFamily[] FontFamilies;

        static FontEnumerator()
        {
            InstalledFontCollection = new InstalledFontCollection();
            FontFamilies = InstalledFontCollection.Families;
        }
    }

    public static class Matematica
    {

//        using GeoAPI.Geometries;
//using GisSharpBlog.NetTopologySuite.Geometries;

//namespace GisSharpBlog.NetTopologySuite.Simplify
//{
//    /// <summary>
//    /// Simplifies a line (sequence of points) using
//    /// the standard Douglas-Peucker algorithm.
//    /// </summary>
//    public class DouglasPeuckerLineSimplifier
//    {
//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="pts"></param>
//        /// <param name="distanceTolerance"></param>
//        /// <returns></returns>
//        public static ICoordinate[] Simplify(ICoordinate[] pts, double distanceTolerance)
//        {
//            DouglasPeuckerLineSimplifier simp = new DouglasPeuckerLineSimplifier(pts);
//            simp.DistanceTolerance = distanceTolerance;
//            return simp.Simplify();
//        }

//        private ICoordinate[] pts;
//        private bool[] usePt;
//        private double distanceTolerance;       

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="pts"></param>
//        public DouglasPeuckerLineSimplifier(ICoordinate[] pts)
//        {
//            this.pts = pts;
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        public double DistanceTolerance
//        {
//            get
//            {
//                return distanceTolerance;
//            }
//            set
//            {
//                distanceTolerance = value;
//            }
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <returns></returns>
//        public ICoordinate[] Simplify()
//        {
//            usePt = new bool[pts.Length];
//            for (int i = 0; i < pts.Length; i++)
//                usePt[i] = true;
            
//            SimplifySection(0, pts.Length - 1);
//            CoordinateList coordList = new CoordinateList();
//            for (int i = 0; i < pts.Length; i++)            
//                if (usePt[i])
//                    coordList.Add(new Coordinate(pts[i]));            
//            return coordList.ToCoordinateArray();
//        }

//        private LineSegment seg = new LineSegment();

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="i"></param>
//        /// <param name="j"></param>
//        private void SimplifySection(int i, int j)
//        {
//            if ((i + 1) == j)
//                return;            
//            seg.P0 = pts[i];
//            seg.P1 = pts[j];
//            double maxDistance = -1.0;
//            int maxIndex = i;
//            for (int k = i + 1; k < j; k++)
//            {
//                double distance = seg.Distance(pts[k]);
//                if (distance > maxDistance)
//                {
//                    maxDistance = distance;
//                    maxIndex = k;
//                }
//            }
//            if (maxDistance <= DistanceTolerance)
//                for (int k = i + 1; k < j; k++)                
//                    usePt[k] = false;                            
//            else
//            {
//                SimplifySection(i, maxIndex);
//                SimplifySection(maxIndex, j);
//            }
//        }
//    }
//}

        //http://en.wikipedia.org/wiki/Ramer%E2%80%93Douglas%E2%80%93Peucker_algorithm
//        PointF[] DouglasPeucker(PointF[] PointList, float epsilon)
//        {
//            //Find the point with the maximum distance
//            float dmax = 0;
//            int index = 0;
//             for(int i = 2 ;i< PointList.Count(); i++)
//             {
//                TomLineSegment segment = new TomLineSegment(PointList[1], PointList[PointList.Count()-1]);
//                float d = segment.Distance( PointList[i]);// PerpendicularDistance(PointList[i], Line(PointList[1], PointList[end])) 
//                if (d > dmax)
//                {
//                index = i;
//                dmax = d;
//                }
//             }
 
// //If max distance is greater than epsilon, recursively simplify
// if (dmax >= epsilon)
// {
        
//          //Recursive call
//          recResults1[] = DouglasPeucker(PointList[1...index], epsilon)
//          recResults2[] = DouglasPeucker(PointList[index...end], epsilon)
  
//  // Build the result list
//  ResultList[] = {recResults1[1...end-1] recResults2[1...end]}

//        }
//  ResultList[] = {PointList[1], PointList[end]}
// end
 
// //Return the result
// return ResultList[];
//}


        public static float Distance(PointF p1, PointF p2)
        {
            return (float)Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2));
        }

        public static float DistanceSquare(PointF p1, PointF p2)
        {
            return (float)Math.Max(Math.Abs(p1.X - p2.X), Math.Abs(p1.Y - p2.Y));
        }

        //public static float DistanceSegment(PointF Pnt, PointF First, PointF Second)
        //{


        //    float M1, Q1;
        //    float M2, Q2;
        //    float xv, yv;

        //    if (Second.X == First.X)
        //    {
        //        if (First.Y == Second.Y)
        //        {
        //            return float.NaN;
        //        }
        //        else
        //        {
        //            if ((Pnt.Y >= First.Y && Pnt.Y <= Second.Y) || (Pnt.Y <= First.Y && Pnt.Y >= Second.Y))
        //            {
        //                PointF mnp;

        //                mnp.X = First.X;
        //                mnp.Y = Pnt.Y;

        //                return Distance(mnp, Pnt);
        //            }
        //            else
        //                return (float.NaN);
        //        }
        //    }

        //    M1 = (Second.Y - First.Y) / (Second.X - First.X);
        //    Q1 = First.Y - (M1 * First.X);

        //    M2 = -1 / M1;
        //    Q2 = Pnt.Y - (M2 * Pnt.X);

        //    xv = (Q2 - Q1) / (M1 - M2);
        //    yv = (M1 * xv) + Q1;

        //    PointF vpt;
        //    vpt.X = xv;
        //    vpt.Y = yv;

        //    double xmin, ymin, xmax, ymax;

        //    if (First.X < Second.X)
        //    {
        //        xmin = First.X;
        //        xmax = Second.X;
        //    }
        //    else
        //    {
        //        xmin = Second.X;
        //        xmax = First.X;
        //    }

        //    if (First.Y < Second.Y)
        //    {
        //        ymin = First.Y;
        //        ymax = Second.Y;
        //    }
        //    else
        //    {
        //        ymin = Second.Y;
        //        ymax = First.Y;
        //    }

        //    if (xv > xmin && xv < xmax && yv > ymin && yv < ymax)
        //        return Distance(Pnt, vpt);
        //    else { 
        //        return float.NaN;
        //    }
        //}


        public static PointF Rotate(PointF pt, float angle)
        {
            PointF pr = new PointF(  (float)(pt.X * Math.Cos(angle) - pt.Y * Math.Sin(angle)),
                                    -(float)(pt.X * Math.Sin(angle) + pt.Y * Math.Cos(angle)));

            return pr;
        }

        public static double DegreesToRadians(double degrees)
        {
            return degrees * System.Math.PI / 180;
        }

        public static double RadiansToDegrees(double radians)
        {
            return radians * 180 / System.Math.PI;
        }

        public static float ConvertToFloat(double d)
        {
            return (float)d;
        }

        public static float ConvertToFloat(int i)
        {
            return (float)i;
        }

        public static bool InsidePolygon(Point[] polygon, Point p)
        {
            //http://astronomy.swin.edu.au/~pbourke/geometry/insidepoly/
            //
            // Slick algorithm that checks if a point is inside a polygon.  Checks how may time a line
            // origination from point will cross each side.  An odd result means inside polygon.
            //

            int N = polygon.Count();

            int counter = 0;
            int i;
            double xinters;
            PointF p1, p2;

            p1 = polygon[0];
            for (i = 1; i <= N; i++)
            {
                p2 = polygon[i % N];
                if (p.Y > System.Math.Min(p1.Y, p2.Y))
                {
                    if (p.Y <= System.Math.Max(p1.Y, p2.Y))
                    {
                        if (p.X <= System.Math.Max(p1.X, p2.X))
                        {
                            if (p1.Y != p2.Y)
                            {
                                xinters = (p.Y - p1.Y) * (p2.X - p1.X) / (p2.Y - p1.Y) + p1.X;
                                if (p1.X == p2.X || p.X <= xinters)
                                    counter++;
                            }
                        }
                    }
                }
                p1 = p2;
            }

            if (counter % 2 == 0)
                return false;
            else
                return true;
        }

        public static bool InsidePolygon(PointF[] polygon, PointF p)
        {
            //http://astronomy.swin.edu.au/~pbourke/geometry/insidepoly/
            //
            // Slick algorithm that checks if a point is inside a polygon.  Checks how may time a line
            // origination from point will cross each side.  An odd result means inside polygon.
            //

            int N = polygon.Count();

            int counter = 0;
            int i;
            double xinters;
            PointF p1, p2;

            p1 = polygon[0];
            for (i = 1; i <= N; i++)
            {
                p2 = polygon[i % N];
                if (p.Y > System.Math.Min(p1.Y, p2.Y))
                {
                    if (p.Y <= System.Math.Max(p1.Y, p2.Y))
                    {
                        if (p.X <= System.Math.Max(p1.X, p2.X))
                        {
                            if (p1.Y != p2.Y)
                            {
                                xinters = (p.Y - p1.Y) * (p2.X - p1.X) / (p2.Y - p1.Y) + p1.X;
                                if (p1.X == p2.X || p.X <= xinters)
                                    counter++;
                            }
                        }
                    }
                }
                p1 = p2;
            }

            if (counter % 2 == 0)
                return false;
            else
                return true;
        }

        public static double AngleFromPoint(PointF Point)
        {

            double dAngle = System.Math.Atan2((double)Point.Y, (double)Point.X);

	        return (dAngle * 180.0/Math.PI);
        }

        public static double AngleFromPoint(Point Point)
        {

            double dAngle = System.Math.Atan2((double)Point.Y, (double)Point.X);

            return (dAngle * 180.0 / Math.PI);
        }

        public static double AngleFormPoints(PointF Center, PointF p1, PointF p2)
        {
            PointF pp1 = new PointF(p1.X - Center.X, p1.Y - Center.Y);
            PointF pp2 = new PointF(p2.X - Center.X, p2.Y - Center.Y);

            double A1 = AngleFromPoint(pp1);
            double A2 = AngleFromPoint(pp2);

            return A2 - A1;

        }
 
        public static Color InterpolateColor(double v1, Color c1, double v2, Color c2, double v)
        {
            double r = (v - v1) / (v2 - v1);

            int A = (int)Math.Round(((double)c2.A - (double)c1.A) * r + (double)c1.A);
            int R = (int)Math.Round(((double)c2.R - (double)c1.R) * r + (double)c1.R);
            int G = (int)Math.Round(((double)c2.G - (double)c1.G) * r + (double)c1.G);
            int B = (int)Math.Round(((double)c2.B - (double)c1.B) * r + (double)c1.B);

            return Color.FromArgb(A, R, G, B);

        }

        public static RectangleF GetNormalizedRectangle(PointF p1, PointF p2)
        {
            RectangleF rc = new Rectangle();

            // Normalize the rectangle.
            if (p1.X < p2.X)
            {
                rc.X = p1.X;
                rc.Width = p2.X - p1.X;
            }
            else
            {
                rc.X = p2.X;
                rc.Width = p1.X - p2.X;
            }
            if (p1.Y < p2.Y)
            {
                rc.Y = p1.Y;
                rc.Height = p2.Y - p1.Y;
            }
            else
            {
                rc.Y = p2.Y;
                rc.Height = p1.Y - p2.Y;
            }

            return rc;
        }

        public static Rectangle GetNormalizedRectangle(Point p1, Point p2)
        {
            Rectangle rc = new Rectangle();

            // Normalize the rectangle.
            if (p1.X < p2.X)
            {
                rc.X = p1.X;
                rc.Width = p2.X - p1.X;
            }
            else
            {
                rc.X = p2.X;
                rc.Width = p1.X - p2.X;
            }
            if (p1.Y < p2.Y)
            {
                rc.Y = p1.Y;
                rc.Height = p2.Y - p1.Y;
            }
            else
            {
                rc.Y = p2.Y;
                rc.Height = p1.Y - p2.Y;
            }

            return rc;
        }

        public static Point GetRectangleCenter(Rectangle r)
        {
            return new Point(r.X + r.Width / 2, r.Y + r.Height / 2);
        }

        public static PointF GetRectangleCenter(RectangleF r)
        {
            return new PointF(r.X + r.Width / 2, r.Y + r.Height / 2);
        }
    
    }

    public static class EnumTools
    {
        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());
            DescriptionAttribute[] attributes =
              (DescriptionAttribute[])fi.GetCustomAttributes
              (typeof(DescriptionAttribute), false);
            return (attributes.Length > 0) ? attributes[0].Description : value.ToString();
        }
    }


}
