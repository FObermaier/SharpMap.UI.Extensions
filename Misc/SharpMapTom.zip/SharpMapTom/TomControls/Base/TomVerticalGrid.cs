﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Drawing.Drawing2D;

namespace TomControls.Base
{
    public partial class TomVerticalGrid : UserControl
    {

        private Bitmap Img;

        private bool _GridBorder = true;
        public bool GridBorder
        {
            get
            {
                return _GridBorder;
            }
            set
            {
                _GridBorder = value;
                Refresh();
                //panel.Refresh();
            }
        }

        public int GridBorderSize
        {
            get;
            set;
        }

        public Color GridBorderColor
        {
            get;
            set;
        }

        private int gridRows = 10;
        public int GridRows
        {
            get
            {
                return gridRows;
            }
            set
            {
                gridRows = value;
                if (gridRows < 1)
                {
                    gridRows = 1;
                }

                Structure();

            }

        }

        private int gridCols = 10;
        public int GridCols
        {
            get
            {
                return gridCols;
            }
            set
            {
                gridCols = value;
                if (gridCols < 1)
                {
                    gridCols = 1;
                }

                Structure();

            }

        }

        private float gridCellHeight = 20;
        public int GridCellHeight
        {
            get
            {
                return (int)gridCellHeight;
            }
            set
            {
                gridCellHeight = value;
                if (gridCellHeight < 1)
                {
                    gridCellHeight = 1;
                }

                Structure();

            }

        }

        private float gridCellWidth;
        public int SelRow = -1;
        public int SelCol = -1;

        public TomVerticalGrid()
        {
            InitializeComponent();

            GridBorderColor = SystemColors.ActiveBorder;
        }

        //public void Reset()
        //{
        //    SelCol = -1;
        //    SelRow = -1;
        //    scrollBar.Value = 0;
        //    panel.Top = 0;
        //}

        public int SelectedItem
        {
            set
            {
                int r, c;
                int i = value;

                r = (int)(i / gridCols);
                c = i - (r * gridCols);

                SetSel(r, c);
                //panel.Invalidate();
            }
            get
            {
                if (SelCol < 0 | SelRow < 0) return -1;

                return SelRow * gridCols + SelCol;
            }
        }

        public void SetSel(int selRow, int selCol)
        {

            if (selCol >= 0 && selRow >= 0 && selRow <= gridRows && selCol <= gridCols)
            {
                SelCol = selCol;
                SelRow = selRow;

                if (scrollBar.Visible == true)
                {
                    int scrollto;
                    if (selRow * gridCellHeight > scrollBar.Maximum)
                        scrollto = scrollBar.Maximum;
                    else
                        scrollto = (int)(selRow * gridCellHeight);

                    scrollBar.Value = scrollto;
                    panel.Top = -scrollto;
                    //panel.Invalidate();

                }
            }
        }

        private void TomVerticalGrid_Load(object sender, EventArgs e)
        {
            Structure();

            panel.Left = 0;
            panel.Top = 0;

        }

        public delegate void OnDrawItem(int r, int c, bool Selected, Rectangle Rect, Graphics g);
        public event OnDrawItem DrawItem;

        public void Redraw()
        {
            DrawItems();
            panel.Image = Img;
        }

        private void DrawItems()
        {
            if (Img != null) Img.Dispose();

            Img = new Bitmap(panel.Width, panel.Height);

            DateTime dt = DateTime.Now;
            Debug.Print(dt.ToString());

            Graphics g = Graphics.FromImage(Img);

            g.SmoothingMode = SmoothingMode.HighQuality;

            Pen p = new Pen(GridBorderColor, (float)GridBorderSize);

            for (int r = 0; r < gridRows; r++)
            {
                for (int c = 0; c < gridCols; c++)
                {
                   Rectangle rec;

                   rec = new Rectangle((int)(c * gridCellWidth), (int)(r * gridCellHeight), (int)gridCellWidth, (int)gridCellHeight);

                    //if (_GridBorder)
                    //    g.DrawRectangle(p, rec);

                    bool selected = false;
                    if (SelCol == c && SelRow == r)
                    {
                        selected = true;
                    }

                    if (DrawItem != null)
                    {
                        DrawItem(r, c, selected, rec, g);
                    }

                }
            }


            if (_GridBorder)
            {
                for (int r = 1; r < gridRows; r++)
                {
                    g.DrawLine(p, 0, (int)(r * gridCellHeight), Width, (int)(r * gridCellHeight));
                }

                for (int c = 1; c < gridCols; c++)
                {
                    g.DrawLine(p, (int)(c * gridCellWidth), 0, (int)(c * gridCellWidth), panel.Height);
                }

                g.DrawRectangle(p, 0, 0, panel.ClientRectangle.Width - 1, panel.ClientRectangle.Height - 1);
            }

            p.Dispose();
            g.Dispose();
        }

        private void Structure()
        {


            gridCellWidth = (float)panel.Width / (float)gridCols;

            int vsb = panel.Height - ClientRectangle.Height;

            if (vsb > 0)
            {
                scrollBar.Enabled = true;
                scrollBar.Minimum = 0;
                scrollBar.Maximum = vsb + 10;// +(int)gridCellHeight;
                scrollBar.SmallChange = (int)gridCellHeight;
            }
            else
            {
                scrollBar.Value = 0;
                scrollBar.Enabled = false;
            }
     
          
        }

        private void scrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            panel.Top = -scrollBar.Value + 1;
        }

        private void TomVerticalGrid_Resize(object sender, EventArgs e)
        {
            panel.Left = 0;
            panel.Top = 0;
            panel.Height = (int)(gridCellHeight * gridRows) + 1;
            panel.Width = ClientRectangle.Width - scrollBar.Width;

            Structure();
        }

        private void panel_MouseClick(object sender, MouseEventArgs e)
        {
            Rectangle rec;
            if (SelCol != -1 && SelRow != -1)
            {
                rec = new Rectangle((int)(SelCol * gridCellWidth), (int)(SelRow * gridCellHeight), (int)gridCellWidth, (int)gridCellHeight);
                //panel.Invalidate(rec);
            }

            SelCol = (int)(e.X / gridCellWidth);
            SelRow = (int)(e.Y / GridCellHeight);

            rec = new Rectangle((int)(SelCol * gridCellWidth), (int)(SelRow * gridCellHeight), (int)gridCellWidth, (int)gridCellHeight);

            Redraw();

        }

        public new delegate void DoubleClick();
        public new event DoubleClick OnDoubleClick;

        private void panelGrid_DoubleClick(object sender, EventArgs e)
        {
            if (OnDoubleClick != null)
                OnDoubleClick();
        }

        public void ManageKeyPress(Keys KeyCode)
        {

            //if (SelCol != -1 && SelRow != -1)
            //{
            //    rec = new Rectangle((int)(SelCol * gridCellWidth), (int)(SelRow * gridCellHeight), (int)gridCellWidth, (int)gridCellHeight);
            //    panel.Invalidate(rec);
            //}

            int newSelCol = SelCol;
            int newSelRow = SelRow;

            switch (KeyCode)
            {
                case Keys.Up:
                    newSelRow -= 1;
                    break;

                case Keys.Down:
                    newSelRow += 1;
                    break;

                case Keys.Left:
                    newSelCol -= 1;
                    break;

                case Keys.Right:
                    newSelCol += 1;
                    break;
                    
            }

            if (newSelCol < 0) newSelCol = 0;
            if (newSelCol > GridCols) newSelCol = GridCols;

            if (newSelRow < 0) newSelRow = 0;
            if (newSelRow > GridRows) newSelRow = GridRows;

            SelCol = newSelCol;
            SelRow = newSelRow;

            SetSel(newSelRow, newSelCol);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);

            ManageKeyPress(e.KeyCode);
        }


        private void panel_Paint(object sender, PaintEventArgs e)
        {
            panel.Image = Img;
        }


    }
}
