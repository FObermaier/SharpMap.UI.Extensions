﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomDoubleUpDown : UserControl
    {
        public TomDoubleUpDown()
        {
            InitializeComponent();
        }


        private bool settingvalue = false;

        public decimal Value1
        {
            get
            {
                return numericUpDown1.Value;
            }
            set
            {
                settingvalue = true;
                numericUpDown1.Value = value;
                settingvalue = false;
            }
        }

        public decimal Value2
        {
            get
            {
                return numericUpDown2.Value;
            }
            set
            {
                settingvalue = true;
                numericUpDown2.Value = value;
                settingvalue = false;
            }
        }


        public event EventHandler ValueChanged;

        public void OnValueChanged(object sender, EventArgs e)
        {
            if (!settingvalue)
            {
                if (ValueChanged != null)
                {
                    ValueChanged(sender, e);
                }
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (!settingvalue)
            {
                OnValueChanged(sender, e);
            }
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (!settingvalue)
            {
                OnValueChanged(sender, e);
            }
        }

    }
}
