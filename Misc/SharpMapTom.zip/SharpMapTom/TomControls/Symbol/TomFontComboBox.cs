﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomFontComboBox : ComboBox
    {
        public TomFontComboBox()
        {
            InitializeComponent();

            DrawMode = DrawMode.OwnerDrawFixed;
            DropDownStyle = ComboBoxStyle.DropDownList;
            DisplayMember = "Name";

            Fill();
        }

        private void Fill()
        {
            FontFamily[] F = FontFamily.Families;

            foreach (FontFamily family in FontFamily.Families)
            {

                if (family.IsStyleAvailable(FontStyle.Regular))
                {
                    int i = Items.Add(family.Name);
                    if (family.Name == "Arial") SelectedIndex = i;
                }
            }


        }



        protected override void OnMeasureItem(MeasureItemEventArgs e)
        {
            TomImageComboBoxItem Itm = (TomImageComboBoxItem)Items[e.Index];
            
            Font f = new Font(Items[e.Index] as string, 4);

            e.ItemHeight = (int)f.SizeInPoints + 1;
            e.ItemWidth = this.DropDownWidth;

            f.Dispose();

            base.OnMeasureItem(e);
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            Rectangle rect = e.Bounds;

            //Rectangle TextRect = e.Bounds;
            //TextRect.Inflate(new Size(-1, -1));

            e.DrawBackground();

            Brush brush;

            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                brush = SystemBrushes.HighlightText;
            else
                brush = SystemBrushes.WindowText;


            if (DesignMode)
            {
                e.Graphics.DrawString("Font selector", Font, brush, rect); ;
            }
            else
            {
                if (e.Index >= 0)
                {

                    string FontName = Items[e.Index] as string;

                    e.Graphics.DrawString(FontName + " - ", Font, brush, rect);
                    SizeF s1 = e.Graphics.MeasureString(FontName + " - ", Font);

                    
                    StringFormat stringFormat = new StringFormat();
                    stringFormat.Alignment = StringAlignment.Center;
                    stringFormat.LineAlignment = StringAlignment.Center;


                    Font fSpecific = new Font(FontName, ItemHeight - 4);
                    SizeF s2 = e.Graphics.MeasureString(FontName, fSpecific);

                    Rectangle rcFont = new Rectangle((rect.Left + (int)s1.Width), rect.Top, (int)Math.Ceiling(s2.Width), (int)rect.Height);

                    e.Graphics.DrawString(FontName, fSpecific, brush, rcFont, stringFormat);

                    fSpecific.Dispose();
                }
            }

            e.DrawFocusRectangle();

            base.OnDrawItem(e);
        }
    }
}
