﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    public partial class TomCharSymbol : UserControl
    {
        public string FontName
        {
            get
            {
                return tomFontComboBox.SelectedItem as string;
            }
            set
            {
                tomFontComboBox.SelectedItem = value;
            }
        }

        public int SelectedGlyph
        {
            get
            {
                return tomVerticalGrid.SelectedItem;
            }
            set
            {
                tomVerticalGrid.SelectedItem = value;
            }
        }

        public TomCharSymbol()
        {
            InitializeComponent();
        }

        private void TomCharSymbol_Load(object sender, EventArgs e)
        {
            Redraw();
        }

        private void tomFontComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Redraw();
        }

        private void Redraw()
        {
            string fontName = tomFontComboBox.SelectedItem as string;
            tomVerticalGrid.Font = new Font(fontName, 14);

            tomVerticalGrid.Redraw();
        }

        private void tomVerticalGrid_DrawItem(int r, int c, bool Selected, Rectangle Rect, Graphics g)
        {
            int i = r * tomVerticalGrid.GridCols + c;

            string s = "" + Convert.ToChar(i + 33);

            SizeF sz = g.MeasureString(s, tomVerticalGrid.Font);

            sz.Width /= 2f;
            sz.Height /= 2f;

            Point p = new Point(Rect.Left + Rect.Width / 2 - (int)sz.Width, Rect.Top + Rect.Height / 2 - (int)sz.Height);

            if (Selected)
            {
                g.FillRectangle(new SolidBrush(SystemColors.Highlight), Rect);
                g.DrawString(s, tomVerticalGrid.Font, new SolidBrush(SystemColors.HighlightText), p);
            }
            else
            {
                g.FillRectangle(new SolidBrush(SystemColors.Window), Rect);
                g.DrawString(s, tomVerticalGrid.Font, new SolidBrush(SystemColors.WindowText), p);
            }
        }

    }
}
