﻿namespace TomControls
{
    partial class TomGradientBrush
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelGradientSampleContainer = new System.Windows.Forms.Panel();
            this.panelGradientSample = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.numericUpDownAngle = new System.Windows.Forms.NumericUpDown();
            this.comboBoxGradientType = new System.Windows.Forms.ComboBox();
            this.buttonHue = new System.Windows.Forms.Button();
            this.tomPaletteEditor = new TomControls.TomPaletteEditor();
            this.panelGradientSampleContainer.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAngle)).BeginInit();
            this.SuspendLayout();
            // 
            // panelGradientSampleContainer
            // 
            this.panelGradientSampleContainer.BackColor = System.Drawing.Color.White;
            this.panelGradientSampleContainer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelGradientSampleContainer.Controls.Add(this.panelGradientSample);
            this.panelGradientSampleContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelGradientSampleContainer.Location = new System.Drawing.Point(0, 79);
            this.panelGradientSampleContainer.Name = "panelGradientSampleContainer";
            this.panelGradientSampleContainer.Padding = new System.Windows.Forms.Padding(10);
            this.panelGradientSampleContainer.Size = new System.Drawing.Size(343, 114);
            this.panelGradientSampleContainer.TabIndex = 14;
            // 
            // panelGradientSample
            // 
            this.panelGradientSample.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGradientSample.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelGradientSample.Location = new System.Drawing.Point(10, 10);
            this.panelGradientSample.Name = "panelGradientSample";
            this.panelGradientSample.Size = new System.Drawing.Size(319, 90);
            this.panelGradientSample.TabIndex = 0;
            this.panelGradientSample.Paint += new System.Windows.Forms.PaintEventHandler(this.panelGradientSample_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.numericUpDownAngle);
            this.panel1.Controls.Add(this.comboBoxGradientType);
            this.panel1.Controls.Add(this.buttonHue);
            this.panel1.Controls.Add(this.tomPaletteEditor);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(343, 79);
            this.panel1.TabIndex = 13;
            // 
            // numericUpDownAngle
            // 
            this.numericUpDownAngle.Location = new System.Drawing.Point(206, 48);
            this.numericUpDownAngle.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.numericUpDownAngle.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.numericUpDownAngle.Name = "numericUpDownAngle";
            this.numericUpDownAngle.Size = new System.Drawing.Size(54, 20);
            this.numericUpDownAngle.TabIndex = 12;
            this.numericUpDownAngle.ValueChanged += new System.EventHandler(this.numericUpDownAngle_ValueChanged);
            // 
            // comboBoxGradientType
            // 
            this.comboBoxGradientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGradientType.FormattingEnabled = true;
            this.comboBoxGradientType.Items.AddRange(new object[] {
            "Lineare",
            "Circolare",
            "Rettangolare"});
            this.comboBoxGradientType.Location = new System.Drawing.Point(78, 48);
            this.comboBoxGradientType.Name = "comboBoxGradientType";
            this.comboBoxGradientType.Size = new System.Drawing.Size(122, 21);
            this.comboBoxGradientType.TabIndex = 9;
            // 
            // buttonHue
            // 
            this.buttonHue.Location = new System.Drawing.Point(279, 47);
            this.buttonHue.Name = "buttonHue";
            this.buttonHue.Size = new System.Drawing.Size(61, 21);
            this.buttonHue.TabIndex = 11;
            this.buttonHue.Text = "Rainbow";
            this.buttonHue.UseVisualStyleBackColor = true;
            this.buttonHue.Click += new System.EventHandler(this.buttonHue_Click);
            // 
            // tomPaletteEditor
            // 
            this.tomPaletteEditor.Dock = System.Windows.Forms.DockStyle.Top;
            this.tomPaletteEditor.Location = new System.Drawing.Point(0, 0);
            this.tomPaletteEditor.Max = 100D;
            this.tomPaletteEditor.Min = 0D;
            this.tomPaletteEditor.Name = "tomPaletteEditor";
            this.tomPaletteEditor.SelItem = 0;
            this.tomPaletteEditor.ShowValueNumericUpDown = false;
            this.tomPaletteEditor.Size = new System.Drawing.Size(343, 76);
            this.tomPaletteEditor.TabIndex = 10;
            this.tomPaletteEditor.PaletteChange += new TomControls.TomPaletteEditor.PaletteChangeEvent(this.tomPaletteEditor_PaletteChange);
            // 
            // TomGradientBrush
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelGradientSampleContainer);
            this.Controls.Add(this.panel1);
            this.Name = "TomGradientBrush";
            this.Size = new System.Drawing.Size(343, 193);
            this.Load += new System.EventHandler(this.TomGradientBrush_Load);
            this.panelGradientSampleContainer.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAngle)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelGradientSampleContainer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBoxGradientType;
        private System.Windows.Forms.Button buttonHue;
        private TomPaletteEditor tomPaletteEditor;
        private System.Windows.Forms.Panel panelGradientSample;
        private System.Windows.Forms.NumericUpDown numericUpDownAngle;
    }
}
