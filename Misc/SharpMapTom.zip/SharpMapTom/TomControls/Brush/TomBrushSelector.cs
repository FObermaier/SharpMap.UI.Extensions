﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomBrushSelector : UserControl
    {
        public TomBrushSelector()
        {
            InitializeComponent();
        }

        private void BrushSelector_Load(object sender, EventArgs e)
        {
            panelBrushHatch.Dock = DockStyle.Fill;
            panelGradient.Dock = DockStyle.Fill;

            comboBoxBrushType.Items.Add("Riempimento");
            comboBoxBrushType.Items.Add("Gradiente");
            comboBoxBrushType.Items.Add("Bitmap");

         
        }


        private void comboBoxBrushType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxBrushType.SelectedIndex)
            {
                case 0:
                    panelBrushHatch.Visible = true;
                    panelGradient.Visible = false;
                    break;
                case 1:
                    panelBrushHatch.Visible = false;
                    panelGradient.Visible = true;
                    panelGradient.Invalidate();
                    break;

            }
        }

  

    }
}
