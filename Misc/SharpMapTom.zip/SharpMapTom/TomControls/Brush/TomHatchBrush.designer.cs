﻿namespace TomControls
{
    partial class TomHatchBrush
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.labelBackColor = new System.Windows.Forms.Label();
            this.labelForeColor = new System.Windows.Forms.Label();
            this.tomColorComboBoxBackColor = new TomControls.TomColorComboBox();
            this.tomColorComboBoxForeColor = new TomControls.TomColorComboBox();
            this.tomVerticalGrid = new TomControls.Base.TomVerticalGrid();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.labelBackColor);
            this.panelTop.Controls.Add(this.labelForeColor);
            this.panelTop.Controls.Add(this.tomColorComboBoxBackColor);
            this.panelTop.Controls.Add(this.tomColorComboBoxForeColor);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Padding = new System.Windows.Forms.Padding(2);
            this.panelTop.Size = new System.Drawing.Size(260, 45);
            this.panelTop.TabIndex = 14;
            // 
            // labelBackColor
            // 
            this.labelBackColor.AutoSize = true;
            this.labelBackColor.Location = new System.Drawing.Point(92, 5);
            this.labelBackColor.Name = "labelBackColor";
            this.labelBackColor.Size = new System.Drawing.Size(59, 13);
            this.labelBackColor.TabIndex = 5;
            this.labelBackColor.Text = "BackColor:";
            // 
            // labelForeColor
            // 
            this.labelForeColor.AutoSize = true;
            this.labelForeColor.Location = new System.Drawing.Point(5, 5);
            this.labelForeColor.Name = "labelForeColor";
            this.labelForeColor.Size = new System.Drawing.Size(55, 13);
            this.labelForeColor.TabIndex = 4;
            this.labelForeColor.Text = "ForeColor:";
            // 
            // tomColorComboBoxBackColor
            // 
            this.tomColorComboBoxBackColor.Color = System.Drawing.Color.Empty;
            this.tomColorComboBoxBackColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.tomColorComboBoxBackColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tomColorComboBoxBackColor.FormattingEnabled = true;
            this.tomColorComboBoxBackColor.Location = new System.Drawing.Point(92, 19);
            this.tomColorComboBoxBackColor.Name = "tomColorComboBoxBackColor";
            this.tomColorComboBoxBackColor.Size = new System.Drawing.Size(81, 21);
            this.tomColorComboBoxBackColor.TabIndex = 3;
            // 
            // tomColorComboBoxForeColor
            // 
            this.tomColorComboBoxForeColor.Color = System.Drawing.Color.Empty;
            this.tomColorComboBoxForeColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.tomColorComboBoxForeColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tomColorComboBoxForeColor.FormattingEnabled = true;
            this.tomColorComboBoxForeColor.Location = new System.Drawing.Point(5, 19);
            this.tomColorComboBoxForeColor.Name = "tomColorComboBoxForeColor";
            this.tomColorComboBoxForeColor.Size = new System.Drawing.Size(81, 21);
            this.tomColorComboBoxForeColor.TabIndex = 2;
            // 
            // tomVerticalGrid
            // 
            this.tomVerticalGrid.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tomVerticalGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomVerticalGrid.GridBorder = true;
            this.tomVerticalGrid.GridBorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.tomVerticalGrid.GridBorderSize = 0;
            this.tomVerticalGrid.GridCellHeight = 40;
            this.tomVerticalGrid.GridCols = 13;
            this.tomVerticalGrid.GridRows = 4;
            this.tomVerticalGrid.Location = new System.Drawing.Point(0, 45);
            this.tomVerticalGrid.Name = "tomVerticalGrid";
            this.tomVerticalGrid.SelectedItem = -1;
            this.tomVerticalGrid.Size = new System.Drawing.Size(260, 165);
            this.tomVerticalGrid.TabIndex = 15;
            this.tomVerticalGrid.DrawItem += new TomControls.Base.TomVerticalGrid.OnDrawItem(this.tomVerticalGrid_DrawItem);
            // 
            // TomHatchBrush
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tomVerticalGrid);
            this.Controls.Add(this.panelTop);
            this.Name = "TomHatchBrush";
            this.Size = new System.Drawing.Size(260, 210);
            this.Load += new System.EventHandler(this.TomHatchBrush_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label labelBackColor;
        private System.Windows.Forms.Label labelForeColor;
        private TomColorComboBox tomColorComboBoxBackColor;
        private TomColorComboBox tomColorComboBoxForeColor;
        private Base.TomVerticalGrid tomVerticalGrid;
    }
}
