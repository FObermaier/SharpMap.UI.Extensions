﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomGradientBrush : UserControl
    {
        private Brush _Brush = null;

        public Brush Brush
        {
            get
            {
                return _Brush;
            }
            set
            {
                _Brush = value;
            }
        }

        public TomGradientBrush()
        {
            InitializeComponent();
        }

        private void buttonHue_Click(object sender, EventArgs e)
        {
            tomPaletteEditor.Items.CreateHue();
            tomPaletteEditor.SelItem = 0;

            //Invalidate();
        }

        private void TomGradientBrush_Load(object sender, EventArgs e)
        {
            comboBoxGradientType.SelectedIndex = 0;
            DrawSample();
            
        }

        //private void TomGradientBrush_Paint(object sender, PaintEventArgs e)
        //{

        //    Graphics g = panelGradientSample.CreateGraphics();

        //    Rectangle r = panelGradientSample.ClientRectangle;
            
        //    Brush b = CreateBrush(r);
        //    g.FillRectangle(b, r);

        //    //if (r.Width > 0 && r.Height > 0)
        //    //{
        //    //    Brush b = CreateBrush(r);
        //    //    g.FillRectangle(new SolidBrush(Color.White), r);
        //    //    if (b != null) g.FillRectangle(b, r);
        //    //    b.Dispose();
        //    //}

        //    g.Dispose();

        //}


        private void DrawSample()
        {
            Graphics g = panelGradientSample.CreateGraphics();

            Rectangle r = panelGradientSample.ClientRectangle;

            Brush b = CreateBrush(r);
            g.FillRectangle(b, r);

            //if (r.Width > 0 && r.Height > 0)
            //{
            //    Brush b = CreateBrush(r);
            //    g.FillRectangle(new SolidBrush(Color.White), r);
            //    if (b != null) g.FillRectangle(b, r);
            //    b.Dispose();
            //}

            g.Dispose();
        }

        private Brush CreateBrush(Rectangle rct)
        {
            if (comboBoxGradientType.SelectedIndex < 0) return Brushes.Black;

            switch (comboBoxGradientType.SelectedIndex)
            {
                case 0:
                    {
                        double angle = ((double)numericUpDownAngle.Value);
                        
                        GraphicsPath gp = new GraphicsPath(FillMode.Alternate);

                        Point[] p = { new Point(rct.Left,rct.Top),
                            new Point(rct.Right,rct.Top),
                            new Point(rct.Right,rct.Bottom),
                            new Point(rct.Left,rct.Bottom),
                            new Point(rct.Left,rct.Top)};

                        gp.AddPolygon(p);

                        return GetLinearBrushs(rct, gp, angle, tomPaletteEditor.Items);
                    }
                case 1:
                    {
                        double angle = ((double)numericUpDownAngle.Value);

                        GraphicsPath gp = new GraphicsPath(FillMode.Alternate);

                        gp.AddEllipse(rct);

                        return GetPathBrush(rct, gp, angle, tomPaletteEditor.Items);
                    }
                
                
                case 2:
                    {
                        double angle = ((double)numericUpDownAngle.Value);

                        GraphicsPath gp = new GraphicsPath(FillMode.Alternate);

                        Point[] p = { new Point(rct.Left,rct.Top),
                            new Point(rct.Right,rct.Top),
                            new Point(rct.Right,rct.Bottom),
                            new Point(rct.Left,rct.Bottom),
                            new Point(rct.Left,rct.Top)};

                        Point center = new Point(rct.Left + rct.Width / 2, rct.Top + rct.Height / 2);

                        p = GetRotated(p, center, Matematica.DegreesToRadians(angle));

                        gp.AddPolygon(p);

                        return GetPathBrush(rct, gp, angle, tomPaletteEditor.Items);
                    }
            }


            return Brushes.Black;
        }



        public Point[] GetRotated( Point[] vector, Point origin, double radians)
        {
            Point[] ret = new Point[vector.Count()];
            for (int i = 0; i < vector.Count(); i++)
            {
                ret[i] = RotatePoint(vector[i], origin, radians);
            }
            return ret;
        }

        public Point RotatePoint(Point point, Point origin, double angle)
        {
            Point ret = new Point();
            ret.X = (int)(origin.X + ((point.X - origin.X) * Math.Cos((float)angle)) - ((point.Y - origin.Y) * Math.Sin((float)angle)));
            ret.Y = (int)(origin.Y + ((point.X - origin.X) * Math.Sin((float)angle)) - ((point.Y - origin.Y) * Math.Cos((float)angle)));
            return ret;
        }


       

        private Brush GetLinearBrushs(Rectangle rct, GraphicsPath gp, double angle, TomPaletteItemList Items)
        {
            //Create Brush and ?declare? that I'm using it as a LinearG..Brush
            LinearGradientBrush lgb = new LinearGradientBrush(
                rct,
                Items[0].Color,
                Items[1].Color,
                (float)angle,
                false);
                        
            if (Items.Count > 2)
            {
                int n = Items.Count;

                Color[] colors = new Color[n];
                float[] values = new float[n];

                for (int i = 0; i < n; i++)
                {
                    colors[i] = Items[i].Color;
                    values[i] = (float)(Items[i].Value / Items[n-1].Value);
                }
                
                ColorBlend cb = new ColorBlend();

                cb.Colors = colors;
                cb.Positions = values;
                
                lgb.InterpolationColors = cb;

            }

            return lgb;
        }


        private Brush GetPathBrush(Rectangle rct, GraphicsPath gp,double angle, TomPaletteItemList Items)
        {
            PathGradientBrush pgb = new PathGradientBrush(gp);

            pgb.CenterPoint = new Point(rct.Left+rct.Width/2,rct.Top+rct.Height/2);
            pgb.CenterColor = Color.Black;

            
            
                int n = Items.Count;

                Color[] colors = new Color[n];
                float[] values = new float[n];

                for (int i = 0; i < n; i++)
                {
                    colors[i] = Items[i].Color;
                    values[i] = (float)(Items[i].Value / Items[n - 1].Value);
                }

                ColorBlend cb = new ColorBlend();

                cb.Colors = colors;
                cb.Positions = values;

                pgb.InterpolationColors = cb;

            //}


            //if (UseBlend)
            //{
            //    blnd.Positions = Positions.ToArray();
            //    blnd.Factors = Factors.ToArray();
            //    pgb.Blend = blnd;
            //}

            //if (UseColorBlend)
            //{
            //    //When shown together as below it creates much nicer/cleaner images!
            //    //NOTE SurroundingColors can not exceed number of points in the Path
            //    if (SurroundingColors.Count <= gp.PathData.Points.Length)
            //        pgb.SurroundColors = SurroundingColors.ToArray();

            //    cb.Colors = SurroundingColors.ToArray();
            //    cb.Positions = Positions.ToArray();
            //    pgb.InterpolationColors = cb;
            //}
            //else
            //    //TODO Is this a potential problem. 
            //    //  If not using ColorBlend use Color2 as the outer color
            //    pgb.SurroundColors = new Color[] { Color2 };

            return pgb;
        }

        private void tomPaletteEditor_PaletteChange()
        {
            //Invalidate();
        }

        private void panelGradientSample_Paint(object sender, PaintEventArgs e)
        {
            DrawSample();
        }

        private void numericUpDownAngle_ValueChanged(object sender, EventArgs e)
        {
            //Invalidate();
        }

    
    }
}
