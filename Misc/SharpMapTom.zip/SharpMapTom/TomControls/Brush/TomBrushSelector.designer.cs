﻿namespace TomControls
{
    partial class TomBrushSelector
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxBrushType = new System.Windows.Forms.ComboBox();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelGradient = new System.Windows.Forms.Panel();
            this.panelBrushHatch = new System.Windows.Forms.Panel();
            this.tomHatchBrush1 = new TomControls.TomHatchBrush();
            this.tomGradientBrush1 = new TomControls.TomGradientBrush();
            this.panelTop.SuspendLayout();
            this.panelGradient.SuspendLayout();
            this.panelBrushHatch.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBoxBrushType
            // 
            this.comboBoxBrushType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBrushType.FormattingEnabled = true;
            this.comboBoxBrushType.Location = new System.Drawing.Point(0, 0);
            this.comboBoxBrushType.Name = "comboBoxBrushType";
            this.comboBoxBrushType.Size = new System.Drawing.Size(168, 21);
            this.comboBoxBrushType.TabIndex = 0;
            this.comboBoxBrushType.SelectedIndexChanged += new System.EventHandler(this.comboBoxBrushType_SelectedIndexChanged);
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.comboBoxBrushType);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(5, 5);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(399, 23);
            this.panelTop.TabIndex = 9;
            // 
            // panelGradient
            // 
            this.panelGradient.Controls.Add(this.tomGradientBrush1);
            this.panelGradient.Location = new System.Drawing.Point(51, 46);
            this.panelGradient.Margin = new System.Windows.Forms.Padding(0);
            this.panelGradient.Name = "panelGradient";
            this.panelGradient.Size = new System.Drawing.Size(329, 176);
            this.panelGradient.TabIndex = 11;
            // 
            // panelBrushHatch
            // 
            this.panelBrushHatch.Controls.Add(this.tomHatchBrush1);
            this.panelBrushHatch.Location = new System.Drawing.Point(25, 251);
            this.panelBrushHatch.Name = "panelBrushHatch";
            this.panelBrushHatch.Size = new System.Drawing.Size(200, 100);
            this.panelBrushHatch.TabIndex = 14;
            // 
            // tomHatchBrush1
            // 
            this.tomHatchBrush1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomHatchBrush1.Location = new System.Drawing.Point(0, 0);
            this.tomHatchBrush1.Name = "tomHatchBrush1";
            this.tomHatchBrush1.Size = new System.Drawing.Size(200, 100);
            this.tomHatchBrush1.TabIndex = 13;
            // 
            // tomGradientBrush1
            // 
            this.tomGradientBrush1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tomGradientBrush1.Location = new System.Drawing.Point(0, 0);
            this.tomGradientBrush1.Name = "tomGradientBrush1";
            this.tomGradientBrush1.Size = new System.Drawing.Size(329, 176);
            this.tomGradientBrush1.TabIndex = 0;
            // 
            // TomBrushSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelBrushHatch);
            this.Controls.Add(this.panelGradient);
            this.Controls.Add(this.panelTop);
            this.Name = "TomBrushSelector";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Size = new System.Drawing.Size(409, 420);
            this.Load += new System.EventHandler(this.BrushSelector_Load);
            this.panelTop.ResumeLayout(false);
            this.panelGradient.ResumeLayout(false);
            this.panelBrushHatch.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxBrushType;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelGradient;
        private TomHatchBrush tomHatchBrush1;
        private System.Windows.Forms.Panel panelBrushHatch;
        private TomGradientBrush tomGradientBrush1;

    }
}
