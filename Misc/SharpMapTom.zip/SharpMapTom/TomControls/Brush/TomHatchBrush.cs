﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomHatchBrush : UserControl
    {
        public TomHatchBrush()
        {
            InitializeComponent();
        }

     
        private void listViewHatch_DrawItem(object sender, DrawListViewItemEventArgs e)
        {

            Rectangle r = e.Bounds;

            r.Inflate(-2, -2);

            e.DrawBackground();

            int i = Convert.ToInt32(e.Item.Text);


            if (e.Item.Selected)
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.Yellow), e.Bounds);
            }

            if (i >= 0)
            {
                HatchStyle h = (HatchStyle)i;
                e.Graphics.FillRectangle(new HatchBrush(h, Color.Black, Color.Transparent), r);
            }
            else
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.Black), r);
            }

            e.DrawFocusRectangle();
        }

        private void TomHatchBrush_Load(object sender, EventArgs e)
        {
            tomVerticalGrid.Redraw();

        }

        private void tomVerticalGrid_DrawItem(int r, int c, bool Selected, Rectangle Rect, Graphics g)
        {
            int i = r * tomVerticalGrid.GridCols + c - 1;
            Brush b = null;

            Color Back, Fore;

            if(Selected) 
            {
                Back = SystemColors.Highlight;
                Fore = SystemColors.HighlightText;
            }
            else
            {
                Back = SystemColors.Window;
                Fore = SystemColors.WindowText;
            }


            if (i >= 0)
            {
                HatchStyle h = (HatchStyle)i;
                b = new HatchBrush(h, Fore, Back);
            }
            else
            {
                b = new SolidBrush(Fore);
            }

            if (Selected)
            {
                g.FillRectangle(new SolidBrush(Back), Rect);
            }

            Rectangle rc = Rect;

            rc.Inflate(-2, -2);

            g.FillRectangle(b, rc);

            b.Dispose();


        }

    }
}
