﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace TomControls
{
    public class TomBrush
    {
        public enum BrushTypes
        {
            Solid,
            Hatched,
            Gradient,
            Bitmap
        }

        private BrushTypes _BrushType = BrushTypes.Solid;
        public BrushTypes BrushType
        {
            get
            {
                return _BrushType;
            }
            set
            {
                _BrushType = value;
            }
        }

        public Color ForeColor = Color.Red;
        public Color BackColor = Color.Transparent;

        public Brush GetBrush(RectangleF rc)
        {
            switch (_BrushType)
            {
                case BrushTypes.Solid:
                    {
                        return new SolidBrush(ForeColor);
                    }

                case BrushTypes.Hatched:
                    {
                        return new SolidBrush(ForeColor);
                    }
            
            
            }

            return new SolidBrush(Color.Transparent);
        }

        public TomBrush Clone()
        {
            TomBrush newBrush = new TomBrush();

            newBrush._BrushType = _BrushType;
            newBrush.ForeColor = ForeColor;
            newBrush.BackColor = BackColor;

            return newBrush;
        }
    }
}
