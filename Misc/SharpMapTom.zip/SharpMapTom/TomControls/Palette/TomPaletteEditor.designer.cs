﻿namespace TomControls
{
    partial class TomPaletteEditor
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelValue = new System.Windows.Forms.Label();
            this.numericUpDownValue = new System.Windows.Forms.NumericUpDown();
            this.tomPaletteBase = new TomControls.TomPaletteBase();
            this.tomColorComboBox = new TomControls.TomColorComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValue)).BeginInit();
            this.SuspendLayout();
            // 
            // labelValue
            // 
            this.labelValue.AutoSize = true;
            this.labelValue.Location = new System.Drawing.Point(79, 52);
            this.labelValue.Name = "labelValue";
            this.labelValue.Size = new System.Drawing.Size(37, 13);
            this.labelValue.TabIndex = 3;
            this.labelValue.Text = "Value:";
            this.labelValue.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // numericUpDownValue
            // 
            this.numericUpDownValue.DecimalPlaces = 2;
            this.numericUpDownValue.Location = new System.Drawing.Point(114, 49);
            this.numericUpDownValue.Name = "numericUpDownValue";
            this.numericUpDownValue.Size = new System.Drawing.Size(61, 20);
            this.numericUpDownValue.TabIndex = 6;
            this.numericUpDownValue.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDownValue.ValueChanged += new System.EventHandler(this.numericUpDownValue_ValueChanged);
            // 
            // tomPaletteBase
            // 
            this.tomPaletteBase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tomPaletteBase.Location = new System.Drawing.Point(0, 0);
            this.tomPaletteBase.Margin = new System.Windows.Forms.Padding(0);
            this.tomPaletteBase.Max = 100D;
            this.tomPaletteBase.MaxColor = System.Drawing.Color.Indigo;
            this.tomPaletteBase.Min = -100D;
            this.tomPaletteBase.MinColor = System.Drawing.Color.White;
            this.tomPaletteBase.Name = "tomPaletteBase";
            this.tomPaletteBase.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.tomPaletteBase.Size = new System.Drawing.Size(356, 25);
            this.tomPaletteBase.TabIndex = 0;
            this.tomPaletteBase.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Palette_MouseClick);
            // 
            // tomColorComboBox
            // 
            this.tomColorComboBox.Color = System.Drawing.Color.Empty;
            this.tomColorComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.tomColorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tomColorComboBox.FormattingEnabled = true;
            this.tomColorComboBox.Location = new System.Drawing.Point(3, 48);
            this.tomColorComboBox.Name = "tomColorComboBox";
            this.tomColorComboBox.Size = new System.Drawing.Size(73, 21);
            this.tomColorComboBox.TabIndex = 7;
            this.tomColorComboBox.ColorChange += new TomControls.TomColorComboBox.ColorChangeEvent(this.tomColorComboBox_ColorChange);
            // 
            // TomPaletteEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tomColorComboBox);
            this.Controls.Add(this.numericUpDownValue);
            this.Controls.Add(this.labelValue);
            this.Controls.Add(this.tomPaletteBase);
            this.Name = "TomPaletteEditor";
            this.Size = new System.Drawing.Size(398, 74);
            this.Load += new System.EventHandler(this.TomPaletteEditor_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.TomPaletteEditor_Paint);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TomPaletteEditor_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TomPaletteEditor_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TomPaletteEditor_MouseUp);
            this.Resize += new System.EventHandler(this.TomPaletteEditor_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TomPaletteBase tomPaletteBase;
        private System.Windows.Forms.Label labelValue;
        private System.Windows.Forms.NumericUpDown numericUpDownValue;
        private TomColorComboBox tomColorComboBox;
    }
}
