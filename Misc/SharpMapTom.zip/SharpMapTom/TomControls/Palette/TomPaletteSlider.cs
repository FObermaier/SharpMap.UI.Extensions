﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{

    public partial class TomPaletteSlider : TomPaletteBase
    {
        private double _Value = 0;

        public double Value
        {
            get
            {
                return _Value;
            }
            set
            {
                _Value = value;
                Invalidate();
            }
        }

      
        private int _MarkerSize = 9;
        public int MarkerSize
        {
            get
            {
                return _MarkerSize;
            }
            set
            {
                _MarkerSize = value;
                Invalidate();
            }
        }

        public TomPaletteSlider()
        {
            InitializeComponent();
        }

        private void Draw(Graphics g)
        {
            if (Max == Min) return;

            double v = (_Value - Min) / (Max - Min);

            if (Orientation == Orientation.Horizontal)
            {
                int x = (int)Math.Round(ClientRectangle.Width * v);

                Arrow.DrawArrow(g, Arrow.Orientation.North, new Point(x, 0), _MarkerSize);
                Arrow.DrawArrow(g, Arrow.Orientation.South, new Point(x, ClientRectangle.Height), _MarkerSize);
            }
            else
            {
                int y = (int)Math.Round(Height - (ClientRectangle.Height * v));

                Arrow.DrawArrow(g, Arrow.Orientation.West, new Point(0, y), _MarkerSize);
                Arrow.DrawArrow(g, Arrow.Orientation.East, new Point(ClientRectangle.Width, y), _MarkerSize);

            }


        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Draw(e.Graphics);
        }

        private void TomPaletteSlider_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != System.Windows.Forms.MouseButtons.None)
            {
                _Value = GetValue(e.X, e.Y);

                if (ValueChanged != null)
                {
                    ValueChanged(this);
                }

                Invalidate();
            }
        }

        private void TomPaletteSlider_MouseUp(object sender, MouseEventArgs e)
        {
            _Value = GetValue(e.X, e.Y);

            if (ValueChanged != null)
            {
                ValueChanged(this);
            }

            Invalidate();
        }


        public delegate void ValueChangedEvent(object sender);

        public event ValueChangedEvent ValueChanged;


 
    }
}
