﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing.Drawing2D;


namespace TomControls
{

    [Serializable()]
    public class TomPaletteItem : IComparable, IEquatable<TomPaletteItem>
    {
        public Color Color
        {
            get;
            set;
        }

        public double Value
        {
            get;
            set;
        }

        public TomPaletteItem()
        {
        }

        public TomPaletteItem(double value, Color color)
        {
            Color = color;
            Value = value;
        }

        #region IComparable Membri di

        public int CompareTo(object obj)
        {
            TomPaletteItem other = (TomPaletteItem)obj;

            if (Value < other.Value) return -1;
            if (Value > other.Value) return 1;
            return 0;
        }


        #endregion

        #region IEquatable<PaletteItem> Membri di

        public bool Equals(TomPaletteItem other)
        {
            if(Value == other.Value && Color == other.Color) return true;

            return false;
        }

        #endregion
    }

    public class TomPaletteItemList: List<TomPaletteItem>
    {

        public TomPaletteItemList()
        {
            CreateStandardItems();
        }

        
        public void Add(double value, Color c)
        {
            base.Add(new TomPaletteItem(value, c));
            base.Sort();
        }

        
        public double Min
        {
            set
            {
                if (base.Count > 0)
                {

                    base[0].Value = value;
                }
            }
            get
            {
                if (base.Count <= 0) return double.NaN;
                return base[0].Value;
            }
        }

        public Color MinColor
        {
            set
            {
                if (base.Count > 0)
                {
                    base[0].Color = value;
                }
            }
            get
            {
                if (base.Count <= 0) return Color.Empty;
                return base[0].Color;
            }
        }

        public double Max
        {
            set
            {
                if (base.Count > 0)
                {
                    base[base.Count - 1].Value = value;
                }
            }
            get
            {
                if (base.Count <= 0) return double.NaN;
                return base[base.Count - 1].Value;
            }
        }

        public Color MaxColor
        {
            set
            {
                if (base.Count > 0)
                {
                    base[base.Count - 1].Color = value;
                }
            }
            get
            {
                if (base.Count <= 0) return Color.Empty;
                return base[base.Count - 1].Color;
            }
        }

        public void CreateHue()
        {
            Clear();

            Color c = Color.Empty;

            for (int a = 0; a <= 360; a += 30)
            {
                if (a == 0) c = Color.FromArgb(255, 0, 0);
                if (a == 30) c = Color.FromArgb(255, 127, 0);
                if (a == 60) c = Color.FromArgb(255, 255, 0);
                if (a == 90) c = Color.FromArgb(127, 255, 0);
                if (a == 120) c = Color.FromArgb(0, 255, 0);
                if (a == 150) c = Color.FromArgb(0, 255, 127);
                if (a == 180) c = Color.FromArgb(0, 255, 255);
                if (a == 210) c = Color.FromArgb(0, 127, 255);
                if (a == 240) c = Color.FromArgb(0, 0, 255);
                if (a == 270) c = Color.FromArgb(127, 0, 255);
                if (a == 300) c = Color.FromArgb(255, 0, 255);
                if (a == 330) c = Color.FromArgb(255, 0, 128);
                if (a == 360) c = Color.FromArgb(255, 0, 0);

                Add(a, c);

            }
        }

        public void CreateStandardItems()
        {
            Clear();
            Add(0, Color.White);
            Add(255, Color.Indigo);
        }
        
        public Color GetColor(double value)
        {
            for (int i = 0; i < base.Count - 1; i++)
            {

                if (base[i].Value == value) return base[i].Color;
                if (base[i + 1].Value == value) return base[i + 1].Color;

                if (value > base[i].Value & value < base[i + 1].Value)
                {
                    double d = (value - base[i].Value) / (base[i + 1].Value - base[i].Value);

                    int A = (int)((base[i + 1].Color.A - base[i].Color.A) * d + base[i].Color.A);
                    int R = (int)((base[i + 1].Color.R - base[i].Color.R) * d + base[i].Color.R);
                    int G = (int)((base[i + 1].Color.G - base[i].Color.G) * d + base[i].Color.G);
                    int B = (int)((base[i + 1].Color.B - base[i].Color.B) * d + base[i].Color.B);

                    return Color.FromArgb(A, R, G, B);
                }

            }

            return Color.Transparent;
        }

        public void Draw(Graphics g, Rectangle r, Orientation orientation)
        {

            DrawBack(g,r);
            DrawPalette(g, r, orientation);

        }


        //private void DrawLinearGradientRect(Graphics g, Orientation o, Rectangle r, Color c1, Color c2)
        //{
        //    LinearGradientBrush Gb = new LinearGradientBrush(r, c1, c2, LinearGradientMode.Horizontal);

        //    g.FillRectangle(Gb, r);

        //}

        public void DrawPalette(Graphics g, Rectangle r, Orientation orientation )
        {
            int n =base.Count;


            double d = Max - Min;


            if (orientation == Orientation.Horizontal)
            {
                double rate = d / r.Width;

                for (int i = 0; i < r.Width; i++)
                {
                    Color c = GetColor(Min + i * rate);
                    g.FillRectangle(new SolidBrush(c), i, 0, 1, r.Height);
                }

            }
            else
            {
                double rate = d / r.Height;

                for (int i = 0; i < r.Height; i++)
                {
                    Color c = GetColor(Min + i * rate);
                    g.FillRectangle(new SolidBrush(c), 0, i, r.Width, 1);
                }
            }
        }

        public void DrawBack(Graphics g, Rectangle r)
        {
            HatchBrush hb = new HatchBrush(HatchStyle.SmallCheckerBoard, Color.Black, Color.White);
            g.FillRectangle(hb, r);
            hb.Dispose();
        }


    
    }

    public static class Arrow
    {
        public enum Orientation
        {
            North,
            East,
            South,
            West
        }

        public static Point[] CreateArrow(Orientation orientation, Point aPoint, int MarkerSize)
        {
            int MS2 = MarkerSize / 2;

            int dx1 = 0, dx2 = 0, dy1 = 0, dy2 = 0;

            switch (orientation)
            {
                case Orientation.North: 
                    {
                        dx1 = MS2; dy1 = MarkerSize;
                        dx2 = -MS2; dy2 = MarkerSize;
                    }
                    break;
                case Orientation.East: 
                    {
                        dx1 = -MarkerSize; dy1 = +MS2;
                        dx2 = -MarkerSize; dy2 = -MS2;

                    }
                    break;
                case Orientation.South:
                    {
                        dx1 = MS2; dy1 = -MarkerSize;
                        dx2 = -MS2; dy2 = -MarkerSize;
                    }
                    break;
                case Orientation.West: //left
                    {
                        dx1 = MarkerSize; dy1 = +MS2;
                        dx2 = MarkerSize; dy2 = -MS2;
                    }
                    break;
            }


            return new Point[]
                        {
                            new Point(aPoint.X,aPoint.Y),
                            new Point(aPoint.X+dx1,aPoint.Y+dy1),
                            new Point(aPoint.X+dx2,aPoint.Y+dy2),
                            new Point(aPoint.X,aPoint.Y)
                        };


        }


        public static void DrawArrow(Graphics g, Orientation orientation, Point aPoint, int MarkerSize)
        {

            Point[] pnt = CreateArrow(orientation, aPoint, MarkerSize);

            g.FillPolygon(new SolidBrush(Color.Black), pnt);
            g.DrawPolygon(new Pen(Color.White), pnt);


        }
    }
}
