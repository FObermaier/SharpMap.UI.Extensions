﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace TomControls
{
    public partial class TomPaletteEditor : UserControl
    {

        private int _selitem = -1;

        public int SelItem
        {
            get
            {
                return _selitem;
            }
            set
            {
                int si = value;

                if (si >= 0 && si < Items.Count())
                {
                    _selitem = si;
                    tomColorComboBox.Color = Items[si].Color;
                    Invalidate();
                }
            }
        }

        public double Min
        {
            get
            {
                return tomPaletteBase.Min;
            }
            set
            {
                tomPaletteBase.Min = value;
                this.Invalidate();
            }
        }

        public double Max
        {
            get
            {
                return tomPaletteBase.Max; 
            }
            set
            {
                tomPaletteBase.Max = value;
                this.Invalidate();
            }
        }

        public TomPaletteItemList Items
        {
            get
            {
                return tomPaletteBase.Items;
            }
        }

        public bool ShowValueNumericUpDown
        {
            get
            {
                return numericUpDownValue.Visible;
            }
            set
            {
                numericUpDownValue.Visible = value;
                labelValue.Visible = value;
                Invalidate();
            }
        }

        public void ClearItems()
        {
            tomPaletteBase.Items.Clear();
            
            if (PaletteChange != null)
            {
                PaletteChange();
            }

            _selitem = -1;
        }

        public void AddItem(double value, Color color)
        {

            tomPaletteBase.Items.Add(value, color);
            
            if (_selitem == -1)
            {
                _selitem = 0;
                tomColorComboBox.Color = tomPaletteBase.Items[_selitem].Color;
            }

            numericUpDownValue.Minimum = (decimal)Min;
            numericUpDownValue.Maximum = (decimal)Max;

            if (PaletteChange != null)
            {
                PaletteChange();
            }
        }

        public Color GetColor(double Value)
        {
            return tomPaletteBase.GetColor(Value);
        }

        public TomPaletteEditor()
        {
            InitializeComponent();

            //this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Draw(e.Graphics);
            
            base.OnPaint(e);
        }

 
        private void TomPaletteEditor_Load(object sender, EventArgs e)
        {
            ResizePalette();

            SelItem = 0;
        }

        private void ResizePalette()
        {
            int w = 5;

            tomPaletteBase.Width = this.Width - 2 * w - 1;
            tomPaletteBase.Left = w;
            tomPaletteBase.Top = 2;
        }
        
        private void Draw(Graphics g)
        {
            Pen p = new Pen(Color.Black,0.0f);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            
            g.DrawLine(p, new Point(tomPaletteBase.Left, tomPaletteBase.Top + tomPaletteBase.Height + 7), new Point(tomPaletteBase.Right, tomPaletteBase.Top + tomPaletteBase.Height + 7));

            p.Dispose();

            for (int i = 0; i < tomPaletteBase.Items.Count; i++)
            {
                DrawMarker(g, i, i==_selitem);
            }

            g.Dispose();
        }


        private int _MarkerWidth = 4;
        private int _MarkerHeight = 10;

        private void DrawMarker(Graphics g, int index, bool selected)
        {
            int x = (int)Math.Round(tomPaletteBase.Width * (tomPaletteBase.Items[index].Value - tomPaletteBase.Min) / (tomPaletteBase.Max - tomPaletteBase.Min)) + tomPaletteBase.Left;
            int y = tomPaletteBase.Height + tomPaletteBase.Top + 1;


            Point[] pnt = 
            {
                new Point(x,y),
                new Point(x+_MarkerWidth,y+_MarkerWidth),
                new Point(x+_MarkerWidth,y+_MarkerHeight),
                new Point(x-_MarkerWidth,y+_MarkerHeight),
                new Point(x-_MarkerWidth,y+_MarkerWidth) };


            g.FillPolygon(new SolidBrush(tomPaletteBase.Items[index].Color), pnt);

            if (selected)
            {
                g.DrawPolygon(new Pen(Color.Black, 3), pnt);
                g.DrawPolygon(new Pen(Color.White,0), pnt);
            }
            else
            {
                g.DrawPolygon(new Pen(Color.DarkGray), pnt);
            }

        }

        private int SelectItem(int X, int Y)
        {

            if (Y < tomPaletteBase.Top + tomPaletteBase.Height | Y > tomPaletteBase.Top + tomPaletteBase.Height + _MarkerHeight)
            {
                return -1;
            }


            for (int index = 0; index < tomPaletteBase.Items.Count; index++)
            {
                int x = (int)Math.Round(tomPaletteBase.Width * (tomPaletteBase.Items[index].Value - tomPaletteBase.Min) / (tomPaletteBase.Max - tomPaletteBase.Min)) +tomPaletteBase.Left;

                if (Math.Abs(X - x) <= _MarkerWidth)
                {
                    return index;
                }
            }

            return -1;
        }

        private bool mdown = false;

        private void TomPaletteEditor_MouseDown(object sender, MouseEventArgs e)
        {

            int selected  = SelectItem(e.X,e.Y);

            if (selected > -1)
            {
                _selitem = selected;
                tomColorComboBox.Color = tomPaletteBase.Items[_selitem].Color;
                tomColorComboBox.Refresh();

                mdown = true;
            }

            this.Invalidate();
        }

        private void TomPaletteEditor_MouseUp(object sender, MouseEventArgs e)
        {
            mdown = false;

            int selected = SelectItem(e.X, e.Y);

            if (selected > -1)
            {
                _selitem = selected;
                tomColorComboBox.Color = tomPaletteBase.Items[_selitem].Color;
                
                numericUpDownValue.Minimum = (decimal)Min;
                numericUpDownValue.Maximum = (decimal)Max;
                numericUpDownValue.Value = (decimal)tomPaletteBase.Items[_selitem].Value;

            }

            if (_selitem > 0 & _selitem < tomPaletteBase.Items.Count -1 & e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                tomPaletteBase.Items.RemoveAt(_selitem);
                _selitem = -1;

                if (PaletteChange != null)
                {
                    PaletteChange();
                }
            }


            this.Invalidate();
            

        }

        private void TomPaletteEditor_MouseMove(object sender, MouseEventArgs e)
        {

            double value = tomPaletteBase.GetValue(e.X,e.Y);

            double d = ((tomPaletteBase.Max - tomPaletteBase.Min) / tomPaletteBase.Width) * 8;

            if (value <= tomPaletteBase.Min + d || value >= tomPaletteBase.Max - d) return;

            if (e.Button != System.Windows.Forms.MouseButtons.Left) return;

            if (mdown == false) return;

            if (_selitem <= 0 | _selitem >= tomPaletteBase.Items.Count - 1) return;


            tomPaletteBase.Items[_selitem].Value = value;
            tomPaletteBase.Items.Sort();
            
            if (PaletteChange != null)
            {
                PaletteChange();
            }

            this.Invalidate();
            

        }

       
        private void TomPaletteEditor_Resize(object sender, EventArgs e)
        {
            ResizePalette();
            this.Invalidate();
            
        }

        private void Palette_MouseClick(object sender, MouseEventArgs e)
        {
            
            double value = tomPaletteBase.GetValue(e.X,e.Y);
            Color c = tomPaletteBase.GetColor(value);

            tomPaletteBase.Items.Add(value, c);
            tomPaletteBase.Items.Sort();           

            _selitem = SelectItem(e.X + tomPaletteBase.Left, tomPaletteBase.Height + tomPaletteBase.Top + _MarkerHeight / 2);

            if (_selitem >= 0)
            {
                tomColorComboBox.Color = tomPaletteBase.Items[_selitem].Color;
            }

            if (PaletteChange != null)
            {
                PaletteChange();
            }

            this.Invalidate();
            
        }

        private void numericUpDownValue_ValueChanged(object sender, EventArgs e)
        {
            if (_selitem < 0) return;

            if (tomPaletteBase.Items[_selitem].Value != (double)numericUpDownValue.Value)
            {
                tomPaletteBase.Items[_selitem].Value = (double)numericUpDownValue.Value;

                if (PaletteChange != null)
                {
                    PaletteChange();
                }

                this.Invalidate();
                
            };
        }

        private void TomPaletteEditor_Paint(object sender, PaintEventArgs e)
        {
            tomPaletteBase.Invalidate();
        }

        public delegate void PaletteChangeEvent();

        public event PaletteChangeEvent PaletteChange;

        private void tomColorComboBox_ColorChange(Color C)
        {
            if (_selitem < 0) return;
            tomPaletteBase.Items[_selitem].Color = C;
            
            if (PaletteChange != null)
            {
                PaletteChange();
            }

            Invalidate();
        }
       
    }

}
