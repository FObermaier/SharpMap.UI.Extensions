﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public partial class TomPaletteBase : UserControl
    {
        private Orientation _Orientation = Orientation.Horizontal;
        public Orientation Orientation
        {
            get
            {
                return _Orientation;
            }
            set
            {
                _Orientation = value;
                Invalidate();
            }
        }

        public TomPaletteItemList Items = new TomPaletteItemList();

        public double Min
        {
            set
            {
                Items.Min = value;
                Invalidate();
            }
            get
            {
                return Items.Min;
            }
        }

        public Color MinColor
        {
            set
            {
                Items.MinColor = value;
                Invalidate();
            }
            get
            {
                return Items.MinColor;
            }
        }

        public double Max
        {
            set
            {
                Items.Max = value;
                Invalidate();
            }
            get
            {
                return Items.Max;
            }
        }

        public Color MaxColor
        {
            set
            {
                Items.MaxColor = value;
                Invalidate();
            }
            get
            {
                return Items.MaxColor;
            }
        }
   

        public TomPaletteBase()
        {
            InitializeComponent();

            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Draw(e.Graphics);
        }

        private void Draw(Graphics g)
        {
            if (Items != null)
            {
                Items.Draw(g, this.ClientRectangle, Orientation);
            }
        }

        private void TomPalette_Resize(object sender, EventArgs e)
        {
            Invalidate();
        }

        public double GetValue(int X, int Y)
        {
            double sz = 0;

            double v = 0;

            if (Orientation == Orientation.Horizontal)
            {
                sz = ClientRectangle.Width;
                v = X;
            }
            else
            {
                sz = ClientRectangle.Height;
                v = Height - Y;
            }

            double vv = 1 - ((sz - v) / sz);
            vv = vv * (Max - Min) + Min;

            if (vv < Min) vv = Min;
            if (vv > Max) vv = Max;

            if (v == 0)
                vv = Min;
            if (v == sz)
                vv = Max;

            return vv;


        }

        public Color GetColor(double value)
        {
            return Items.GetColor(value);
        }

    }
}
