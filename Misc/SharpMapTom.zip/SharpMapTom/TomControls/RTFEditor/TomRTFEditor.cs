﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;



namespace TomControls
{

    

    public partial class TomRTFEditor : UserControl
    {
      

        public TomRTFEditor()
        {
            InitializeComponent();

        }

        private void TomRTFEditor_Load(object sender, EventArgs e)
        {
            foreach (FontFamily family in FontEnumerator.FontFamilies)
            {
                toolStripComboBoxFont.Items.Add(family.Name);
            }

            toolStripComboBoxFont.SelectedItem = "Verdana";

            for (int i = 6; i < 48; i += 2)
            {
                toolStripComboBoxFontSize.Items.Add(i.ToString().Trim());
            }

            toolStripComboBoxFontSize.Text = "10";
        }

        private void toolStripComboBoxFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            FontStyle style = richTextBox.SelectionFont.Style;
            float size = richTextBox.SelectionFont.Size;

            richTextBox.SelectionFont = new Font(
                toolStripComboBoxFont.Text,
                size,
                style);

            richTextBox.Focus();
        }

        private void toolStripComboBoxFontSize_TextChanged(object sender, EventArgs e)
        {
            float size = float.Parse(toolStripComboBoxFontSize.Text);

            if (size <= 0)
            {
                toolStripComboBoxFontSize.Text = "10";
                return;
            }

            FontStyle style = richTextBox.SelectionFont.Style;
            string name = richTextBox.SelectionFont.FontFamily.Name;

            richTextBox.SelectionFont = new Font(
                name,
                size,
                style);

            //richTextBox.Focus();
        }

        FontStyle GetStyle()
        {
            FontStyle f = FontStyle.Regular;

            if (toolStripButtonBold.Checked) f = f | FontStyle.Bold;
            if (toolStripButtonItalic.Checked) f = f | FontStyle.Italic;
            if (toolStripButtonUnderline.Checked) f = f | FontStyle.Underline;
            if (toolStripButtonStrike.Checked) f = f | FontStyle.Strikeout;

            return f;
        }

        private void toolStripButtonBold_Click(object sender, EventArgs e)
        {
            richTextBox.SelectionFont = new Font(richTextBox.SelectionFont,GetStyle());
        }

        private void toolStripButtonItalic_Click(object sender, EventArgs e)
        {
            richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, GetStyle());
        }

        private void toolStripButtonUnderline_Click(object sender, EventArgs e)
        {
            richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, GetStyle());
        }

        private void toolStripButtonStrike_Click(object sender, EventArgs e)
        {
            richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, GetStyle());
        }

        private void richTextBox_SelectionChanged(object sender, EventArgs e)
        {
            toolStripComboBoxFont.Text = richTextBox.SelectionFont.FontFamily.Name;
            toolStripComboBoxFontSize.Text = richTextBox.SelectionFont.Size.ToString();

            toolStripButtonBold.Checked = ((richTextBox.SelectionFont.Style & FontStyle.Bold) != 0);
            toolStripButtonItalic.Checked = ((richTextBox.SelectionFont.Style & FontStyle.Italic) != 0);
            toolStripButtonUnderline.Checked = ((richTextBox.SelectionFont.Style & FontStyle.Underline) != 0);
            toolStripButtonStrike.Checked = ((richTextBox.SelectionFont.Style & FontStyle.Strikeout) != 0);
        }

        private void toolStripButtonAlign_Click(object sender, EventArgs e)
        {
            switch (sender.ToString())
            {
                case "Left":
                    {
                        richTextBox.SelectionAlignment = TextAlign.Left;
                    }
                    break;
                case "Center":
                    {
                        richTextBox.SelectionAlignment = TextAlign.Center;
                    }
                    break;
                case "Right":
                    {
                        richTextBox.SelectionAlignment = TextAlign.Right;
                    }
                    break;
                case "Justify":
                    {
                        richTextBox.SelectionAlignment = TextAlign.Justify;
                    }
                    break;
            }
        }

     

       

    }
}
