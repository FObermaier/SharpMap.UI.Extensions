﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace TomControls
{
    public class TomCanvasDocumentManager
    {

        private bool _HasPageSize = true;
        public bool HasPageSize
        {
            get
            {
                return _HasPageSize;
            }
            set
            {
                _HasPageSize = value;
            }
        }

        private TomPageSize _PageSize = new TomPageSize();
        public TomPageSize PageSize
        {
            get
            {
                return _PageSize;
            }
            set
            {
                _PageSize = value;
            }
        }

        private List<TomCanvasShapeList> _ShapeList = new List<TomCanvasShapeList>();
        public List<TomCanvasShapeList> ShapeList
        {
            get
            {
                return _ShapeList;
            }
            set
            {
                _ShapeList = value;
            }
        }

        public TomCanvasDocumentManager()
        {
            _ShapeList.Add(new TomCanvasShapeList());
        }

        public TomCanvasShapeList LastList
        {
            get
            {
                return _ShapeList[_ShapeList.Count - 1];
            }
        }

        private List<string> _OperationNames = new List<string>();

        public TomCanvasShapeList EditListOriginal = new TomCanvasShapeList();
        public TomCanvasShapeList EditList = new TomCanvasShapeList();

        public bool Load(string filename)
        {
            return false;
        }

        public bool Save(string filename)
        {
            return false;
        }

        public bool CanUndo()
        {
            return false;
        }

        public void UnDo()
        {

        }

        public bool CanReDo()
        {
            return false;
        }

        public void ReDo()
        {

        }

        public void PushEdit(string OperationName, bool ClearEditList)
        {
            TomCanvasShapeList lst = EditList.Clone();

            _ShapeList.Add(lst);

            if(ClearEditList)EditList.Clear();
        }

        public void AddEdit(string OperationName)
        {
            PushEdit(OperationName, false);
                    
        }

        public TomCanvasShapeBase GetLastFromEditList()
        {
            return EditList.ElementAt(EditList.Count - 1);
        }

        public void SelectAll()
        {
            EditList.Clear();

            if (LastList.Count > 0)
            {
                EditList = LastList.Clone();

                for (int i = 0; i < EditList.Count; i++)
                {
                    EditList.SelectionList.Add(i);
                }

            }

        }

        public void Select(PointF point)
        {
            EditList.Clear();

            LastList.Select(point);

            if (LastList.SelectionList.Count > 0)
            {
                EditList = LastList.Clone();
            }
        }

        public void Select(RectangleF rectangle)
        {
            EditList.Clear();

            LastList.Select(rectangle);

            if (LastList.SelectionList.Count > 0)
            {
                EditList = LastList.Clone();
            }
        }
    }
}
