﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Diagnostics;
using System.Reflection;
using System.Collections;

namespace TomControls
{
    [Serializable]
    public class TomCanvasShapeList : List<TomCanvasShapeBase>
    {
        public List<int> SelectionList = new List<int>();

        /// <summary>
        /// Clone the object, and returning a reference to a cloned object.
        /// </summary>
        /// <returns>Reference to the new cloned 
        /// object.</returns>
        public TomCanvasShapeList Clone()
        {
            var newShapeList = new TomCanvasShapeList();

            foreach (var shp in this)
            {
                var newShape = shp.Clone();
                newShapeList.Add(newShape);
            }

            newShapeList.SelectionList.AddRange(this.SelectionList);

            return (TomCanvasShapeList)newShapeList;
        }

       
        public void Draw(Graphics g)
        {
            foreach (TomCanvasShapeBase shape in this)
            {
                shape.Draw(g);
            }

        }

        public void DrawDottedLines(Graphics g, Matrix m)
        {
 
            Pen p = new Pen(Color.Black, 1f);
     
            foreach (int index in SelectionList)
            {
                ShapeAt(index).Draw(g, m, p);
            }

            p.Dispose();
 
        
        }

      
        public void TransformSelected(Matrix m)
        {
            foreach (int index in SelectionList)
            {
                ShapeAt(index).Transform(m);
            } 
        }

        public void TransformSelected(RectangleF newPosition)
        {

            RectangleF OldPosition = GetSelectedRectangle();

            PointF [] Pts = new PointF[]
            {
                new PointF(newPosition.X,newPosition.Y),
                new PointF(newPosition.X+newPosition.Width,newPosition.Y),
                new PointF(newPosition.X,newPosition.Y+newPosition.Height)
            };

            Matrix m = new Matrix(OldPosition, Pts);
            
            foreach (int index in SelectionList)
            {
                ShapeAt(index).Transform(m);                
            }           
            
        }

        public void RotateSelected(float angle,PointF center)
        {
            Matrix m = new Matrix();

            m.RotateAt(angle, center);

            foreach (int index in SelectionList)
            {
                ShapeAt(index).Transform(m);
            }   
        }

        public void SetRotationCenterToSelected(PointF center)
        {
            foreach (int index in SelectionList)
            {
                ShapeAt(index).RotationCenter = center;
            }      
        }

        public void UnSelectAll()
        {
            SelectionList.Clear();
        }

        public void Select(int index)
        {
            SelectionList.Add(index);
        }

        public void SelectLast()
        {
            UnSelectAll();
            SelectionList.Add(this.Count - 1);
        }

        public void Select(PointF point)
        {

            SelectionList.Clear();

            for (int i = Count-1; i >=0; i--)
            {

                if (ShapeAt(i).HitTest(point))
                {
                    SelectionList.Add(i);
                    return;
                }
            }
        }

        public void Select(RectangleF rect)
        {
            SelectionList.Clear();

            for (int i = 0; i < Count; i++)
            {
                if (ShapeAt(i).HitTest(rect))
                {
                    SelectionList.Add(i);
                }
            }

        }

        public RectangleF GetRectangle()
        {
            
            RectangleF Rectangle = new RectangleF(0, 0, 0, 0);

            for(int i=0; i< this.Count;i++)
            {
                
                TomCanvasShapeBase shape = this.ShapeAt(i);

                if (i == 0)
                    Rectangle = shape.GetBounds();
                else
                    Rectangle = RectangleF.Union(Rectangle, shape.GetBounds());

            }

            return Rectangle;

        }

        public RectangleF GetSelectedRectangle()
        {
            RectangleF SelectedRectangle = new RectangleF(0, 0, 0, 0);

            for(int i=0; i< SelectionList.Count;i++)
            {
                
                int index = SelectionList.ElementAt(i);
                TomCanvasShapeBase shape = this.ShapeAt(index);

                if (i == 0)
                    SelectedRectangle = shape.GetBounds();
                else
                    SelectedRectangle = RectangleF.Union(SelectedRectangle, shape.GetBounds());

            }

            return SelectedRectangle;
        }

        public PointF GetSelectedCenter()
        {
            PointF center = new PointF(0, 0);

            bool assigned = false;

            for (int i = 0; i < SelectionList.Count; i++)
            {
                int index = SelectionList.ElementAt(i);
                TomCanvasShapeBase shape = this.ShapeAt(index);

                if (shape.hasRotationCenter())
                {
                    center = shape.RotationCenter;
                    assigned = true;
                    break;
                }
            }

            if (!assigned)
            {
                center = Matematica.GetRectangleCenter(GetSelectedRectangle());
            }

            return center;
        }

        public TomCanvasShapeBase GetFirst()
        {
            return ShapeAt(0);
        }

        public TomCanvasShapeBase GetLast()
        {
            return ShapeAt(Count-1);
        }

        public TomCanvasShapeBase ShapeAt(int index)
        {
            if (Count > 0 & index < Count) return this.ElementAt(index);
            return null;
        }

        public new void Clear()
        {
            base.Clear();
            SelectionList.Clear();
        }
    }
}
