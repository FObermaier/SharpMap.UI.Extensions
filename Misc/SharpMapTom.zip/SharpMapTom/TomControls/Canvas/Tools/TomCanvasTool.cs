﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace TomControls
{
    public abstract class TomCanvasTool
    {

        protected Cursor _Cursor;
        /// <summary>
        /// Tool cursor.
        /// </summary>
        public Cursor Cursor
        {
            get
            {
                return _Cursor;
            }
            set
            {
                _Cursor = value;
            }
        }

        protected Bitmap _Icon = null;
        /// <summary>
        /// Tool cursor.
        /// </summary>
        public Bitmap Icon
        {
            get
            {
                return _Icon;
            }
            set
            {
                _Icon = value;
            }
        }

        public virtual void InitializeToolsStrip()
        {
            toolStrip.Stretch = true;

            toolStrip.Items.Clear();
        }

        protected ToolStrip GetTopToolStrip(TomCanvas canvas)
        {
            return canvas.SecondaryToolStrip;

            //if (canvas.Parent.GetType() == typeof(ToolStripContentPanel))
            //{
            //    ToolStripContainer Container = (ToolStripContainer)canvas.Parent.Parent;
            //    TomApplicationManager AppManager = (TomApplicationManager)Container.Parent;

            //    if (AppManager != null)
            //    {
            //        return AppManager.toolStripTop;
            //    }

            //}

            //return null;

        }

        public abstract override string ToString();

        protected bool _NeedsInput = true;
        /// <summary>
        /// specify if the tool needs input or not (f.i.: ZoomAll)
        /// </summary>
        public bool NeedsInput
        {
            get
            {
                return _NeedsInput;
            }
            set
            {
                _NeedsInput = value;
            }
        }


        protected TomCanvas Canvas = null;
        protected ToolStrip toolStrip = null;
        /// <summary>
        /// Call the tool if does not needs input
        /// </summary>
        /// <param name="canvas"></param>
        public virtual void Initialize(TomCanvas theCanvas)
        {
            Canvas = theCanvas;

            toolStrip = GetTopToolStrip(Canvas);

            if (toolStrip != null) InitializeToolsStrip();
        }

        public virtual void LeaveTool()
        {

        }


        /// <summary>
        /// Mouse button is pressed
        /// </summary>
        /// <param name="canvas"></param>
        /// <param name="e"></param>
        public abstract void MouseDown(MouseEventArgs e);
       

        /// <summary>
        /// Mouse is moved
        /// </summary>
        /// <param name="canvas"></param>
        /// <param name="e"></param>
        public abstract void MouseMove(MouseEventArgs e);
       


        /// <summary>
        /// Mouse button is released
        /// </summary>
        /// <param name="canvas"></param>
        /// <param name="e"></param>
        public abstract void MouseUp(MouseEventArgs e);


    
    }
}
