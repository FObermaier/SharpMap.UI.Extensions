﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public enum TomCanvasNodeTypes
    {
        Square,
        circle,
        HandleToPrevious,
        HandleToNext
    }
    
    public class TomCanvasNode
    {
        public const float NodeHalfSize = 3f; //x+2, x-2;
        public const float NodeSize = NodeHalfSize * 2;

        public PointF Center = new PointF();
        public TomCanvasNodeTypes NodeType = TomCanvasNodeTypes.Square;
        public int ShapeIndex;
        public int NodeIndex;

      
        public void Drawighlight(Graphics g, Matrix m)
        {
            PointF[] p = new PointF[1];
            p[0] = Center;

            m.TransformPoints(p);

            switch (NodeType)
            {
                case TomCanvasNodeTypes.Square:
                    {
                        g.FillRectangle(Brushes.Red, p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                        g.DrawRectangle(new Pen(Color.Black), p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                    }
                    break;
                case TomCanvasNodeTypes.circle:
                case TomCanvasNodeTypes.HandleToPrevious:
                case TomCanvasNodeTypes.HandleToNext:
                    {
                        g.FillEllipse(Brushes.Red, p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                        g.DrawEllipse(new Pen(Color.Black), p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                    }
                    break;
                default:
                    {
                        g.FillRectangle(Brushes.Red, p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                        g.DrawRectangle(new Pen(Color.Black), p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                    }
                    break;
            }
        }

        public void Draw(Graphics g, Matrix m)
        {

            PointF[] p = new PointF[1];
            p[0] = Center;

            m.TransformPoints(p);

            switch (NodeType)
            {
                case(TomCanvasNodeTypes.Square):
                    {
                        g.FillRectangle(Brushes.White, p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                        g.DrawRectangle(new Pen(Color.Black), p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                    }
                    break;
                case TomCanvasNodeTypes.HandleToPrevious:
                case TomCanvasNodeTypes.HandleToNext:
                case (TomCanvasNodeTypes.circle):
                    {
                        g.FillEllipse(Brushes.White, p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                        g.DrawEllipse(new Pen(Color.Black), p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                    }
                    break;
                default:
                    {
                        g.FillRectangle(Brushes.White, p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                        g.DrawRectangle(new Pen(Color.Black), p[0].X - NodeHalfSize, p[0].Y - NodeHalfSize, NodeSize, NodeSize);
                    }
                    break;
            }
        }

    

        public TomCanvasNode(PointF point, TomCanvasNodeTypes type, int shapeIndex, int nodeIndex)
        {
            Center = point;
            NodeType = type;
            ShapeIndex = shapeIndex;
            NodeIndex = nodeIndex;
        }

        public bool HitTest(PointF point, Matrix m)
        {
            PointF[] p = new PointF[1];
            p[0] = Center;

            m.TransformPoints(p);

            switch (NodeType)
            {
                case (TomCanvasNodeTypes.Square):
                    {
                        if (Matematica.DistanceSquare(p[0], point) <= NodeHalfSize) return true;
                    }
                    break;
                case (TomCanvasNodeTypes.circle):
                    {
                        if (Matematica.Distance(p[0], point) <= NodeHalfSize) return true;
                    }
                    break;
                default:
                    {
                        if (Matematica.Distance(p[0], point) <= NodeHalfSize) return true;
                    }
                    break;
            }

            return false;
        }

    }

    public class TomCanvasNodeListTool 
    {
        public List<TomCanvasNode> NodeList = new List<TomCanvasNode>();

        public TomCanvas Canvas;

        public TomCanvasNodeListTool(TomCanvas canvas)
        {
            Canvas = canvas;
        }

        public void NodeClear()
        {
            NodeList.Clear();
        }

        public void Populate()
        {
            NodeList.Clear();

            foreach (int index in Canvas.Document.EditList.SelectionList)
            {
                TomCanvasShapeBase shape = Canvas.Document.EditList.ElementAt(index);

                shape.AddNodesToList(this, index);
            }

        }


        public void PopulateEnds()
        {
            NodeList.Clear();

            foreach (int index in Canvas.Document.EditList.SelectionList)
            {
                TomCanvasShapeBase shape = Canvas.Document.EditList.ElementAt(index);

                if (shape.GetType() == typeof(TomCanvasPath))
                {
                    shape.AddEndsToList(this, index);
                }
            }

        }

        public void NodeMove(int nodeIndex, PointF point)
        {

            int shapeI = NodeList[nodeIndex].ShapeIndex;
            int nodeI = NodeList[nodeIndex].NodeIndex;

            Canvas.Document.EditList[shapeI].MoveNode(nodeI, point);

            NodeList[nodeIndex].Center = point;

        }

        public void AddNode(PointF point, TomCanvasNodeTypes type, int shapeIndex, int nodeIndexInShape )
        {
            NodeList.Add(new TomCanvasNode(point, type, shapeIndex, nodeIndexInShape));
        }

        public void Draw(Graphics g, Matrix m)
        {
            
            int i=0;
            foreach (TomCanvasNode node in NodeList)
            {
                if (node.NodeType == TomCanvasNodeTypes.HandleToNext)
                {
                    g.DrawLine(Pens.Red, Canvas.ViewToPixel(node.Center), Canvas.ViewToPixel(NodeList[i + 1].Center));
                }

                if (node.NodeType == TomCanvasNodeTypes.HandleToPrevious)
                {
                    g.DrawLine(Pens.Red, Canvas.ViewToPixel(node.Center), Canvas.ViewToPixel(NodeList[i - 1].Center));
                }

                i++;
            }

            foreach (TomCanvasNode node in NodeList)
            {
                node.Draw(g, m);
            }
        }

        public int HitTest(PointF point)
        {

            for (int i = 0; i < NodeList.Count; i++)
            {
                TomCanvasNode node = NodeList.ElementAt(i);

                if (node.HitTest(point, Canvas.DrawingMatrix)) return i;
            }

            return -1;
        }

        public void HighligthNode(int nodeindex, bool highlight)
        {
            Graphics g = Canvas.CreateGraphics();

            if(highlight)
                NodeList[nodeindex].Drawighlight(g, Canvas.DrawingMatrix);
            else
                NodeList[nodeindex].Draw(g, Canvas.DrawingMatrix);

            g.Dispose();

        }


       

    }

}
