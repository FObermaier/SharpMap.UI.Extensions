﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Drawing.Drawing2D;

namespace TomControls
{

    public enum  TomHandleType
    {
        NW=0,
        N=1,
        NE=2,
        W=3,
        E=4,
        SW=5,
        S=6,
        SE=7,
        Center=8,
        //Node=9
        
    };

    public enum ResizingModes
    {
        Resize,
        Rotate,
    }

    public static class TomHandleImages
    {
        public static Bitmap [] Handle = new Bitmap[10];
        public static Bitmap[] Rotate = new Bitmap[10];


        static TomHandleImages()
        {

            Handle[(int)TomHandleType.NW] = Properties.Resources.nwhandle; //.h Properties.Resources.nwhandle;
            Handle[(int)TomHandleType.NE] = Properties.Resources.nwhandle;
            Handle[(int)TomHandleType.SW] = Properties.Resources.nwhandle;
            Handle[(int)TomHandleType.SE] = Properties.Resources.nwhandle;

            Handle[(int)TomHandleType.N] = Properties.Resources.nhandle;
            Handle[(int)TomHandleType.W] = Properties.Resources.nhandle;
            Handle[(int)TomHandleType.E] = Properties.Resources.nhandle;
            Handle[(int)TomHandleType.S] = Properties.Resources.nhandle;

            Handle[(int)TomHandleType.Center] = Properties.Resources.Center; //resourc new Bitmap(assembly.GetManifestResourceStream(center));
            //Handle[(int)TomHandleType.Node] = Properties.Resources.node;


            Rotate[(int)TomHandleType.NW] = Properties.Resources.nwrotate;
            Rotate[(int)TomHandleType.NE] = Properties.Resources.nwrotate;
            Rotate[(int)TomHandleType.SW] = Properties.Resources.nwrotate;
            Rotate[(int)TomHandleType.SE] = Properties.Resources.nwrotate;

            Rotate[(int)TomHandleType.N] = Properties.Resources.nhandle;
            Rotate[(int)TomHandleType.W] = Properties.Resources.nhandle;
            Rotate[(int)TomHandleType.E] = Properties.Resources.nhandle;
            Rotate[(int)TomHandleType.S] = Properties.Resources.nhandle;

            Rotate[(int)TomHandleType.Center] = Properties.Resources.Center;
            //Rotate[(int)TomHandleType.Node] = Properties.Resources.node;


            for (int i = 0; i < 9; i++)
            {
                Handle[i].MakeTransparent(Color.Magenta);
                Rotate[i].MakeTransparent(Color.Magenta);
            }

            Handle[(int)TomHandleType.NE].RotateFlip(RotateFlipType.Rotate90FlipNone);
            Handle[(int)TomHandleType.SW].RotateFlip(RotateFlipType.Rotate90FlipNone);

            Handle[(int)TomHandleType.E].RotateFlip(RotateFlipType.Rotate90FlipNone);
            Handle[(int)TomHandleType.S].RotateFlip(RotateFlipType.Rotate180FlipNone);
            Handle[(int)TomHandleType.W].RotateFlip(RotateFlipType.Rotate270FlipNone);


            Rotate[(int)TomHandleType.NE].RotateFlip(RotateFlipType.Rotate90FlipNone);
            Rotate[(int)TomHandleType.SW].RotateFlip(RotateFlipType.Rotate270FlipNone);
            Rotate[(int)TomHandleType.SE].RotateFlip(RotateFlipType.Rotate180FlipNone);

            Rotate[(int)TomHandleType.N].RotateFlip(RotateFlipType.Rotate90FlipNone);
            Rotate[(int)TomHandleType.S].RotateFlip(RotateFlipType.Rotate90FlipNone);

        }

        public static Bitmap GetHandle(TomHandleType HandleType)
        {
            return Handle[(int)HandleType];
        }

        public static Bitmap GetRotate(TomHandleType HandleType)
        {
            return Rotate[(int)HandleType];
        }

    }

    public class TomHandle
    {

        public bool Visible = true;

        private TomHandleType _HandleType;
        public TomHandleType HandleType
        {
            get
            {
                return _HandleType;
            }
            set
            {
                _HandleType = value;
            }
        }

        private PointF _Center = new Point(0, 0);
        public PointF Center
        {
            get
            {
                return _Center;
            }
            set
            {
                _Center = value;
            }
        }

        public Cursor GetCursor(ResizingModes resizingmode)
        {
            if (resizingmode == ResizingModes.Resize)
            {
                switch (_HandleType)
                {

                    case TomHandleType.NW:
                    case TomHandleType.SE:
                    case TomHandleType.NE:
                    case TomHandleType.SW:
                        {
                            return TomCanvasCursors.MoveNSEW;
                        }
                    case TomHandleType.N:
                    case TomHandleType.S:
                        {
                            return TomCanvasCursors.MoveNS;
                        }
                    case TomHandleType.W:
                    case TomHandleType.E:
                        {
                            return TomCanvasCursors.MoveEW;
                        }                    
                    default:
                        {
                            return TomCanvasCursors.Arrow;
                        }
                }
            }
            else
            {
                switch (_HandleType)
                {
                    case TomHandleType.NW:
                    case TomHandleType.SE:
                    case TomHandleType.NE:
                    case TomHandleType.SW:
                        {
                            return TomCanvasCursors.Rotate;
                        }
                    case TomHandleType.N:
                    case TomHandleType.S:
                        {
                            return TomCanvasCursors.WarpEW;
                        }
                    case TomHandleType.W:
                    case TomHandleType.E:
                        {
                            return TomCanvasCursors.WarpNS;
                        }
                    case TomHandleType.Center:
                        {
                            return TomCanvasCursors.MoveNSEW;
                        }
                    default:
                        {
                            return TomCanvasCursors.Arrow;
                        }
                }
            }
        }

        public SizeF Size
        {
            get
            {
                Bitmap bmp = TomHandleImages.GetHandle(_HandleType);
                return new SizeF(bmp.Width, bmp.Height);
            }
        }

        public TomHandle(TomHandleType handleType)
        {
            _HandleType = handleType;            
        }

        public Rectangle GetRectangle()
        {
                Bitmap bmp = TomHandleImages.GetHandle(_HandleType);

                return new Rectangle((int)(_Center.X - bmp.Width / 2), (int)(_Center.Y - bmp.Height / 2), bmp.Width, bmp.Height);
        }

        public bool HitTest(TomCanvas canvas, Point p)
        {
            if (!Visible) return false;

            RectangleF rect = GetRectangle();

            if (rect.Contains(p)) return true;

            return false;
        }

        public void Draw(Graphics g, ResizingModes resizeMode)
        {
            if (!Visible) return;

            Rectangle rect = GetRectangle();

            if (resizeMode == ResizingModes.Resize)
            {
                g.DrawImage(TomHandleImages.GetHandle(_HandleType), rect);
            }
            else
            {
                g.DrawImage(TomHandleImages.GetRotate(_HandleType), rect);
            }
           
        }

    }

    public class TomCanvasResizeRotator
    {

        private TomHandle[] ResizingHandles = new TomHandle[]
        {
            new TomHandle(TomHandleType.NW),
            new TomHandle(TomHandleType.N),
            new TomHandle(TomHandleType.NE),
            new TomHandle(TomHandleType.W),
            new TomHandle(TomHandleType.E),
            new TomHandle(TomHandleType.SW),
            new TomHandle(TomHandleType.S),
            new TomHandle(TomHandleType.SE),
            new TomHandle(TomHandleType.Center),
        };

        public TomCanvasResizeRotator(TomCanvas canvas)
        {
            _Canvas = canvas;
            ResizingHandles[(int)TomHandleType.Center].Visible = false;
        }

        private RectangleF _Position;
        public RectangleF Position
        {
            get
            {
                return _Position;
            }
            set
            {
                _Position = value;
                Structure();
            }
        }


        public TomCanvas _Canvas = null;
        public TomCanvas Canvas
        {
            get
            {
                return _Canvas;
            }
            set
            {
                _Canvas = value;
            }
        }

        private bool _Visible = false;
        public bool Visible
        {
            get
            {
                return _Visible;
            }
            set
            {
                bool b = _Visible;

                _Visible = value;

                if (_Visible == true & b == false)
                {
                    _ResizingMode = ResizingModes.Resize;
                    SetCenter(Canvas.ViewToPixel(Canvas.Document.EditList.GetSelectedCenter()));
                }
            }
        }

        private ResizingModes _ResizingMode = ResizingModes.Resize;
        public ResizingModes ResizingMode
        {
            get
            {
                return _ResizingMode;
            }
            set
            {
                _ResizingMode = value;

                ResizingHandles[(int)TomHandleType.Center].Visible = (_ResizingMode == ResizingModes.Rotate);

            }
        }

        private void Structure()
        {

            foreach (TomHandle th in ResizingHandles)
            {
                RectangleF rect = Position;

                rect.Inflate(th.Size.Width/2.0f, th.Size.Height/2.0f);

                switch (th.HandleType)
                {
                    case (TomHandleType.NW):
                        {
                            th.Center = new PointF(rect.X, rect.Y);
                        }
                        break;
                    case (TomHandleType.N):
                        {
                            th.Center = new PointF(rect.X+rect.Width/2, rect.Y);
                        }
                        break;
                    case (TomHandleType.NE):
                        {
                            th.Center = new PointF(rect.X + rect.Width, rect.Y);
                        }
                        break;
                    case (TomHandleType.W):
                        {
                            th.Center = new PointF(rect.X, rect.Y + rect.Height / 2);
                        }
                        break;
                    case (TomHandleType.E):
                        {
                            th.Center = new PointF(rect.X + rect.Width, rect.Y + rect.Height / 2);
                        }
                        break;
                    case (TomHandleType.SW):
                        {
                            th.Center = new PointF(rect.X, rect.Y + rect.Height);
                        }
                        break;
                    case (TomHandleType.S):
                        {
                            th.Center = new PointF(rect.X + rect.Width / 2, rect.Y + rect.Height);
                        }
                        break;
                    case (TomHandleType.SE):
                        {
                            th.Center = new PointF(rect.X + rect.Width, rect.Y + rect.Height);
                        }
                        break;
                    case (TomHandleType.Center):
                        {
                            //th.Center = new PointF(rect.X + rect.Width / 2, rect.Y + rect.Height / 2);
                        }
                        break;
                }
            }
        }

        public void SetCenter(PointF center)
        {
            foreach (TomHandle th in ResizingHandles)
            {
                if (th.HandleType == TomHandleType.Center)
                {
                    th.Center = center;
                }
            }
        }

        public void Draw(Graphics g)
        {
            if (!_Visible) return;

            foreach (TomHandle th in ResizingHandles)
            {
                th.Draw(g, _ResizingMode);
            }

            Pen p = new Pen(Color.Gray, 1f);
            p.DashStyle = DashStyle.Dash;

            g.DrawRectangle(p, Position.X, Position.Y, Position.Width, Position.Height);

            p.Dispose();
        }


        Point HandlePreviousPoint;

        public bool IsMoving = false;
        public bool IsResizing = false;
        private TomHandle ResizingHandle;

        private Point MouseDownPoint;

        public void MouseDown(MouseEventArgs e)
        {
            if (!_Visible) return;

            MouseDownPoint = new Point(e.X, e.Y);
            
            IsResizing = false;
            IsMoving = false;

            if (e.Button == MouseButtons.Left)
            {
                foreach (TomHandle th in ResizingHandles)
                {
                    if (th.HitTest(Canvas, MouseDownPoint))
                    {
                        Canvas.Document.EditListOriginal.Clear();
                        
                        Canvas.Document.EditListOriginal = Canvas.Document.EditList.Clone();
                        HandlePreviousPoint = MouseDownPoint;
                        IsResizing = true;
                        ResizingHandle = th;
                        break;
                    }
                }

                if (!IsResizing)
                {
                    foreach (int index in Canvas.Document.EditList.SelectionList)
                    {
                        if (Canvas.Document.EditList[index].HitTest(Canvas.PixelToView(MouseDownPoint)))
                        {
                            IsMoving = true;
                        }
                    }      
                }
            }

        }

        public void MouseMove(MouseEventArgs e)
        {
            if (!_Visible) return;

            Point pnt  = new Point(e.X,e.Y);

            if (e.Button == MouseButtons.None)
            {
                Canvas.Cursor = Cursors.Default;
            }



            if (e.Button == MouseButtons.Left)
            {
                if (IsResizing)
                {

                    RectangleF newPosition = Position;

                    if (_ResizingMode == ResizingModes.Resize)
                    {
                        int dx = e.X - HandlePreviousPoint.X;
                        int dy = e.Y - HandlePreviousPoint.Y;
                        
                        #region Resize
                        switch (ResizingHandle.HandleType)
                        {
                            case TomHandleType.NW:
                                {
                                    newPosition.X += dx; newPosition.Width -= dx;
                                    newPosition.Y += dy; newPosition.Height -= dy;
                                }
                                break;
                            case TomHandleType.N:
                                {
                                    newPosition.Y += dy; newPosition.Height -= dy;
                                }
                                break;
                            case TomHandleType.NE:
                                {
                                    newPosition.Width += dx;
                                    newPosition.Y += dy; newPosition.Height -= dy;
                                }
                                break;

                            case TomHandleType.W:
                                {
                                    newPosition.X += dx; newPosition.Width -= dx;
                                }
                                break;
                            case TomHandleType.E:
                                {
                                    newPosition.Width += dx;
                                }
                                break;

                            case TomHandleType.SW:
                                {
                                    newPosition.X += dx; newPosition.Width -= dx;
                                    newPosition.Height += dy;
                                }
                                break;
                            case TomHandleType.S:
                                {
                                    newPosition.Height += dy;
                                }
                                break;

                            case TomHandleType.SE:
                                {
                                    newPosition.Width += dx;
                                    newPosition.Height += dy;
                                }
                                break;

                            case TomHandleType.Center:
                                {
                                    PointF center = new PointF(e.X, e.Y);
                                    ResizingHandle.Center = center;

                                    Canvas.Document.EditList.SetRotationCenterToSelected(Canvas.PixelToView(center));

                                    Canvas.Refresh();
                                    return;
                                }

                        }
                        #endregion

                        Position = newPosition;


                        //SetCenter(canvas.PageToPixel(canvas.Document.EditList.GetSelectedCenter()));
                        Canvas.Document.EditList.TransformSelected(Canvas.PixelToView(Position));
                    
                    }
                    else
                    {
                        #region Rotate



                        switch (ResizingHandle.HandleType)
                        {
                            case TomHandleType.NW:
                            case TomHandleType.NE:
                            case TomHandleType.SW:
                            case TomHandleType.SE:
                                {
                                    PointF center = Canvas.PixelToView(ResizingHandles[(int)TomHandleType.Center].Center);

                                    PointF oldPoint = Canvas.PixelToView(MouseDownPoint);
                                    PointF newPoint = Canvas.PixelToView(new PointF(e.X, e.Y));


                                    float angle = (float)Matematica.AngleFormPoints(center, oldPoint, newPoint);

                                    Canvas.Document.EditList = Canvas.Document.EditListOriginal.Clone();
                                    Canvas.Document.EditList.RotateSelected(angle, center);

                                    Canvas.Refresh();
                                    return;

                                }

                            case TomHandleType.E:
                            case TomHandleType.N:
                            case TomHandleType.W:
                            case TomHandleType.S:
                                {
                                    PointF oldPoint = Canvas.PixelToView(MouseDownPoint);
                                    PointF newPoint = Canvas.PixelToView(new PointF(e.X, e.Y));

                                    float dx = newPoint.X - oldPoint.X;
                                    float dy = newPoint.Y - oldPoint.Y;            

                                    PointF[] warp = new PointF[3];

                                    short LTPoint = 0;
                                    short RTPoint = 1;
                                    short LBPoint = 2;

                                    RectangleF r = Canvas.PixelToView(Position);

                                    warp[LTPoint] = r.Location;
                                    warp[RTPoint] = new PointF(r.Right, r.Top);
                                    warp[LBPoint] = new PointF(r.Left, r.Bottom);

                                    if (ResizingHandle.HandleType == TomHandleType.N)
                                    {
                                        warp[LTPoint].X += dx; warp[RTPoint].X += dx;
                                        warp[LBPoint].X -= dx;
                                    }
                                    if (ResizingHandle.HandleType == TomHandleType.S)
                                    {
                                        warp[LTPoint].X -= dx; warp[RTPoint].X -= dx;
                                        warp[LBPoint].X += dx;
                                    }
                                    if (ResizingHandle.HandleType == TomHandleType.E)
                                    {
                                        warp[LTPoint].Y -= dy; warp[RTPoint].Y += dy;
                                        warp[LBPoint].Y -= dy;
                                    }
                                    if (ResizingHandle.HandleType == TomHandleType.W)
                                    {
                                        warp[LTPoint].Y += dy; warp[RTPoint].Y -= dy;
                                        warp[LBPoint].Y += dy;
                                    }

                                    Matrix m = new Matrix(r, warp);

                                    Canvas.Document.EditList = Canvas.Document.EditListOriginal.Clone();
                                    Canvas.Document.EditList.TransformSelected(m);

                                    Canvas.Refresh();
                                    return;
                                }

                            case TomHandleType.Center:
                                {
                                    PointF center = new PointF(e.X, e.Y);
                                    ResizingHandle.Center = center;

                                    Canvas.Document.EditList.SetRotationCenterToSelected(Canvas.PixelToView(center));
                                    Canvas.Refresh();
                                    return;
                                }

                        }                        
                        
                        #endregion
                    }



                }

                if (IsMoving)
                {
                    int dx = e.X - HandlePreviousPoint.X;
                    int dy = e.Y - HandlePreviousPoint.Y;            

                    RectangleF newPosition = Position;

                    newPosition.X += dx;
                    newPosition.Y += dy;

                    Position = newPosition;

                    Canvas.Document.EditList.TransformSelected(Canvas.PixelToView(Position));

                    //SetCenter(Canvas.PageToPixel(Canvas.Document.EditList.GetSelectedCenter()));
                }
            }
            else
            {

                if (!IsResizing & !IsMoving)
                {
                    bool hitted = false;

                    foreach (TomHandle th in ResizingHandles)
                    {
                        #region cursorSetting
                        if (th.HitTest(Canvas, pnt))
                        {
                            Canvas.Cursor = th.GetCursor(_ResizingMode);
                            hitted = true;
                            break;
                        }
                        #endregion
                    }

                    if (!hitted)
                    {
                        foreach (int index in Canvas.Document.EditList.SelectionList)
                        {
                            if (Canvas.Document.EditList[index].HitTest(Canvas.PixelToView(pnt)))
                            {
                                Canvas.Cursor = Cursors.Hand;
                            }
                        }
                    }
                }
            }


            if (Canvas.ActualTool == TomCanvas.ToolSelect)
            {
                TomCanvasToolSelect toolSelect = (TomCanvasToolSelect)Canvas.CanvasTools[TomCanvas.ToolSelect];
                toolSelect.ShowToolbarData();
            }

            Canvas.Refresh();

            HandlePreviousPoint = new Point(e.X, e.Y);
            
        }

        public void MouseUp( MouseEventArgs e)
        {

            if (IsResizing)
            {
                Canvas.Document.PushEdit("Transform", false);

                Canvas.Redraw();
                Canvas.Refresh();
                IsResizing = false;
            }

            if (IsMoving)
            {
                if (MouseDownPoint.X == e.X && MouseDownPoint.Y == e.Y)
                {
                    if (ResizingMode == ResizingModes.Resize)
                    {
                        ResizingMode = ResizingModes.Rotate;
                    }
                    else
                    {
                        ResizingMode = ResizingModes.Resize;
                    }
                }
                else
                {
                    Canvas.Document.PushEdit("Transform",false);

                    Canvas.Redraw();
                    Canvas.Refresh();

                }

                IsMoving = false;
            }

        }

    }

   

}


