﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Reflection;
using System.IO;

namespace TomControls
{
    public class TomCanvasToolZoomAll : TomCanvasTool
    {

        public TomCanvasToolZoomAll()
        {
            _NeedsInput = false;

            _Cursor = new Cursor(GetType(), @"CursorZoom.cur");
            Assembly assembly = Assembly.GetExecutingAssembly();
            Stream imageStream = assembly.GetManifestResourceStream("TomControls.IconZoomAll.bmp");

            _Icon = new Bitmap(imageStream);
        }

        public override string ToString()
        {
            return "Zoom All";
        }

        public override void Initialize(TomCanvas canvas)
        {
            canvas.ZoomAll();
        }

        public override void MouseDown(TomCanvas canvas, MouseEventArgs e)
        {
        }

        public override void MouseMove(TomCanvas canvas, MouseEventArgs e)
        {
        }

        public override void MouseUp(TomCanvas canvas, MouseEventArgs e)
        {
        }
    }
}
