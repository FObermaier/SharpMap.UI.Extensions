﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.IO;
using System.Windows.Forms;

namespace TomControls
{
    class TomCanvasToolPan : TomCanvasTool
    {

        public TomCanvasToolPan()
        {
            _Cursor = TomCanvasCursors.Pan;
            _Icon = Properties.Resources.iconpan;
        }

        public override string ToString()
        {
            return "Pan";
        }

        public override void Initialize(TomCanvas theCanvas)
        {
            Canvas = theCanvas;

            //hide toolbar
        }
        
        Point MouseActualPointPixel = new Point(0, 0);
        Point MousePreviousPointPixel = new Point(0, 0);

        protected PointF OriginalMatrixOffset = new PointF(0, 0);

        public override void MouseDown(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            MouseActualPointPixel = new Point(e.X, e.Y);
        }

        public override void MouseMove(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            MousePreviousPointPixel = MouseActualPointPixel;
            MouseActualPointPixel = new Point(e.X, e.Y);

            if (MousePreviousPointPixel.X != 0 && MousePreviousPointPixel.Y != 0)
            {
                Canvas.Pan(MouseActualPointPixel.X - MousePreviousPointPixel.X,
                           MouseActualPointPixel.Y - MousePreviousPointPixel.Y);
            }
        }

        public override void MouseUp(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            MousePreviousPointPixel = MouseActualPointPixel;
            MouseActualPointPixel = new Point(e.X, e.Y);

            if (MousePreviousPointPixel.X != 0 && MousePreviousPointPixel.Y != 0)
            {
                Canvas.Pan(MouseActualPointPixel.X - MousePreviousPointPixel.X,
                           MouseActualPointPixel.Y - MousePreviousPointPixel.Y);
            } 
        }
    }
}
