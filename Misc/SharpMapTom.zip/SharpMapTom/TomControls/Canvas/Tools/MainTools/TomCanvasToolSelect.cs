﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Reflection;
using System.IO;

namespace TomControls
{
    public class TomCanvasToolSelect: TomCanvasTool
    {
        public TomCanvasToolSelect()
        {

            _Cursor = TomCanvasCursors.Arrow;
            _Icon = Properties.Resources.iconarrow;
          
        }

        public override string ToString()
        {
            return "Select";
        }

        public override void Initialize(TomCanvas theCanvas)
        {
            base.Initialize(theCanvas);

            Canvas.Redraw();
            Canvas.Refresh();

            ShowToolbarData();
            

        }
     
        TomDoubleNumericUpDownToolStripItem LT = new TomDoubleNumericUpDownToolStripItem();
        TomDoubleNumericUpDownToolStripItem WH = new TomDoubleNumericUpDownToolStripItem();

        public override void InitializeToolsStrip()
        {

            if (toolStrip == null) return;

            toolStrip.SuspendLayout();

            base.InitializeToolsStrip();

            LT.Label1.Text = "Left:";
            LT.Label2.Text = "Top:";

            LT.ValueChanged += new EventHandler(LT_ValueChanged);

            WH.Label1.Text = "Width:";
            WH.Label2.Text = "Height:";

            WH.ValueChanged += new EventHandler(WH_ValueChanged);

            toolStrip.Items.Add(LT);
            toolStrip.Items.Add(WH);
          
            
            toolStrip.Items.Add(new ToolStripSeparator());

            Bitmap imgSelectAll = Properties.Resources.iconselectall;
            ToolStripButton BtnSelectAll = new ToolStripButton(imgSelectAll);
            BtnSelectAll.Name = "SelectAll";
            BtnSelectAll.Click += new EventHandler(ToolbarBtn_Click);
            BtnSelectAll.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnSelectAll);

            Bitmap imgSelectNone = Properties.Resources.iconselectnone;
            ToolStripButton BtnSelectNone = new ToolStripButton(imgSelectNone);
            BtnSelectNone.Name = "SelectNone";
            BtnSelectNone.Click += new EventHandler(ToolbarBtn_Click);
            BtnSelectNone.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnSelectNone);

            toolStrip.Items.Add(new ToolStripSeparator());

            toolStrip.ResumeLayout(true);

            toolStrip.Refresh();

        }

        void ToolbarBtn_Click(object sender, EventArgs e)
        {

            ToolStripButton btn = (ToolStripButton)sender;

            switch (btn.Name)
            {
                case "SelectAll":
                    {
                        Canvas.Document.SelectAll();
                        //Canvas.NodeListTool.Populate();
                        Canvas.Redraw();
                        Canvas.Refresh();
                    }
                    break;
                case "SelectNone":
                    {
                        Canvas.Document.EditList.Clear();
                        //Canvas.NodeListTool.Populate();
                        Canvas.Redraw();
                        Canvas.Refresh();
                    }
                    break;
            }

            ShowToolbarData();
        }

        public void ShowToolbarData()
        {
            if (Canvas.Document.EditList.SelectionList.Count > 0)
            {
                RectangleF r = Canvas.Document.EditList.GetSelectedRectangle();

                LT.Enabled = true;
                WH.Enabled = true;

                LT.Value1 = (decimal)r.Left;
                LT.Value2 = (decimal)r.Top;
                WH.Value1 = (decimal)r.Width;
                WH.Value2 = (decimal)r.Height;

                toolStrip.Refresh();
            }
            else
            {
                LT.Value1 = (decimal)0;
                LT.Value2 = (decimal)0;
                WH.Value1 = (decimal)0;
                WH.Value2 = (decimal)0;

                LT.Enabled = false;
                WH.Enabled = false;
            }
        }


        void WH_ValueChanged(object sender, EventArgs e)
        {
            RectangleF Position = Canvas.Document.EditList.GetSelectedRectangle();

            Position.Width = (float)WH.Value1;
            Position.Height = (float)WH.Value2;

            Canvas.Document.EditList.TransformSelected(Position);

            Canvas.Document.PushEdit("Transform", false);

            Canvas.Redraw();
            Canvas.Refresh();

        }

        void LT_ValueChanged(object sender, EventArgs e)
        {
            RectangleF Position = Canvas.Document.EditList.GetSelectedRectangle();

            Position.Location = new PointF((float)LT.Value1, (float)LT.Value2);

            Canvas.Document.EditList.TransformSelected(Position);

            Canvas.Document.PushEdit("Transform", false);

            Canvas.Redraw();
            Canvas.Refresh();
        }

        PointF MouseDownPointMap;
        PointF MouseUpPointMap;

        Point MouseDownPointPixel = new Point(0, 0);
        Point MouseUpPointPixel = new Point(0, 0);
        Point MouseActualPointPixel = new Point(0, 0);

        public override void MouseDown(MouseEventArgs e)
        {
            Canvas.ResizeRotator.MouseDown(e);

            MouseDownPointPixel = new Point(e.X, e.Y);
            MouseDownPointMap = Canvas.PixelToView(MouseDownPointPixel);

        }

        public override void MouseMove(MouseEventArgs e)
        {

            Canvas.ResizeRotator.MouseMove(e);

            if (e.Button != MouseButtons.Left) return;

            MouseActualPointPixel = new Point(e.X, e.Y);

            if (!Canvas.ResizeRotator.IsResizing & !Canvas.ResizeRotator.IsMoving)
            {
                Canvas.SetFocusRectangle(MouseDownPointPixel, MouseActualPointPixel);
                Canvas.Refresh();
            }
         
        }

        public override void MouseUp(System.Windows.Forms.MouseEventArgs e)
        {
            if (Canvas.ResizeRotator.IsResizing | Canvas.ResizeRotator.IsMoving)
            {
                Canvas.ResizeRotator.MouseUp(e);
            }
            else
            {
                Canvas.ResizeRotator.Visible = false;

                MouseUpPointPixel = new Point(e.X, e.Y);
                MouseUpPointMap = Canvas.PixelToView(MouseUpPointPixel);

                Rectangle pixelRec = Matematica.GetNormalizedRectangle(MouseDownPointPixel, MouseUpPointPixel);

                if (pixelRec.Width < 4 && pixelRec.Height < 4)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        Canvas.Document.Select(MouseUpPointMap);
                        //Canvas.NodeListTool.Populate();
                    }

                }
                else
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        PointF p1 = Canvas.PixelToView(MouseDownPointPixel);
                        PointF p2 = Canvas.PixelToView(MouseUpPointPixel);

                        RectangleF rf = Matematica.GetNormalizedRectangle(p1, p2);

                        Canvas.Document.Select(rf);
                        //Canvas.NodeListTool.Populate();
                    }
                }


                ShowToolbarData();


            }

            Canvas.Redraw();
            Canvas.Refresh();
        }



       
    }
}
