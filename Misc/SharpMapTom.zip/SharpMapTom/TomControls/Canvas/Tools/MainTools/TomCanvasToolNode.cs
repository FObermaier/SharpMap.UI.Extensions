﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Drawing;

namespace TomControls
{
    class TomCanvasToolNode: TomCanvasTool
    {

        public TomCanvasToolNode()
        {

            _Cursor = TomCanvasCursors.Node;
            _Icon = Properties.Resources.iconnode;

        }
        
        public override void InitializeToolsStrip()
        {

            toolStrip.SuspendLayout();
            base.InitializeToolsStrip();
            toolStrip.Items.Add(Properties.Resources.iconvoid);
            toolStrip.ResumeLayout(true);
            toolStrip.Refresh();

        }

        public override string ToString()
        {
            //throw new NotImplementedException();
            return "";
        }

        public override void Initialize(TomCanvas canvas)
        {
            base.Initialize(canvas);

        }

        int nodeindex = -1;
        TomCanvasShapeBase Shape = null;


        public override void MouseDown(MouseEventArgs e)
        {

            PointF p = new PointF(e.X, e.Y);


            //foreach (int i in Canvas.Document.EditList.SelectedList)
            //{

            //    Shape = Canvas.Document.EditList.ElementAt(i);
            //    Application.OpenForms[0].Text = e.X.ToString() + " " + e.Y.ToString();

            //    nodeindex = Shape.Nodes.HitTest(p, Canvas.DrawingMatrix);

            //    if (nodeindex >= 0)
            //    {
            //        break;
            //    }

            //}
        
        
        
        }

        public override void MouseMove(MouseEventArgs e)
        {
         
            PointF p = new PointF(e.X, e.Y);


            if (e.Button == MouseButtons.Left)
            {

                if (nodeindex>=0)
                {
                        PointF pPage = Canvas.PixelToView(p);

                        Shape.MoveNode(nodeindex, pPage);

                        Canvas.Refresh();
                }

            }
            else
            {
            //    Canvas.Cursor = TomCanvasCursors.NodeNSEW;
            //else
            //    Canvas.Cursor = TomCanvasCursors.Node;

            }


            

        }

        public override void MouseUp(MouseEventArgs e)
        {
            nodeindex = -1;

            Canvas.Document.PushEdit("Node move", false);
            Canvas.Redraw();
            Canvas.Refresh();
        }
    }
}
