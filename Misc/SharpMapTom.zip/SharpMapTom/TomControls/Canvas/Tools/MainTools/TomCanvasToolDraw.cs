﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Diagnostics;

namespace TomControls
{
    class TomCanvasToolDraw : TomCanvasTool
    {
        private List<PointF> Points = new List<PointF>();

        public TomCanvasToolDraw()
        {

            _Cursor = TomCanvasCursors.Pencil;
            _Icon = Properties.Resources.iconaddpencil;

        }

        public override string ToString()
        {
            return "Draw";
        }


        public override void Initialize(TomCanvas canvas)
        {

            base.Initialize(canvas);

            Points.Clear();
        }

        public override void InitializeToolsStrip()
        {

            toolStrip.SuspendLayout();
            base.InitializeToolsStrip();
            toolStrip.Items.Add(Properties.Resources.iconvoid);
            toolStrip.ResumeLayout(true);
            toolStrip.Refresh();

        }
   
        public override void MouseDown(MouseEventArgs e)
        {
            PointF MouseDownPointPixel = new Point(e.X, e.Y);
            PointF MouseDownPointMap = Canvas.PixelToView(MouseDownPointPixel);

            int nodeindex = Canvas.NodeListTool.HitTest(MouseDownPointPixel);

            if (nodeindex >= 0)
            {
                //MouseDownPointMap = Canvas.NodeListTool.GetNodeCoordinate(nodeindex);
                MouseDownPointMap = Canvas.NodeListTool.NodeList[nodeindex].Center;
                MouseDownPointPixel = Canvas.ViewToPixel(MouseDownPointMap);
            }


            if (Points.Count <= 0)
            {
                Points.Add(MouseDownPointMap);
            }


        }


        bool EditModeFreehand = false;

        public override void MouseMove(MouseEventArgs e)
        {
            PointF MouseMovePointPixel = new Point(e.X, e.Y);
            PointF MouseMovePointMap = Canvas.PixelToView(MouseMovePointPixel);


            int nodeindex = Canvas.NodeListTool.HitTest(MouseMovePointPixel);

            if (nodeindex >= 0)
            {
                MouseMovePointMap = Canvas.NodeListTool.NodeList[nodeindex].Center;
                MouseMovePointPixel = Canvas.ViewToPixel(MouseMovePointPixel);
            }

            int count = Points.Count;

            if (count == 0)
            {
                return;
            }

            Graphics g = Canvas.CreateGraphics();


            if (e.Button == MouseButtons.Left)
            {
                EditModeFreehand = true;

                float d = Matematica.Distance(Points[Points.Count - 1], MouseMovePointPixel);

                if (d> 10)
                {
                    Points.Add(MouseMovePointMap);
                }
            }
            else
            {
                if (count > 0)
                {
                   
                    if (count == 1)
                    {
                        Points.Add(MouseMovePointMap);
                    }
                    else
                    {
                        //Rectangle rc1 = new Rectangle();
                        //Rectangle rc2 = new Rectangle();

                        //rc1 = Matematica.GetNormalizedRectangle(Point.Round(Points[0]), Point.Round(Points[1]));
                        //rc2 = Matematica.GetNormalizedRectangle(Point.Round(Points[0]), Point.Round(MouseMovePointPixel));

                        //Rectangle rc = Rectangle.Union(rc1,rc2);

                        //Canvas.Invalidate(rc);

                        Canvas.Refresh();

                        Points[1] = MouseMovePointMap;


                    }


                }

            }

            if (Points.Count > 1)
            {
                g.DrawLines(Pens.Black, Canvas.ViewToPixel(Points.ToArray()));
            }

        }

        public override void MouseUp(MouseEventArgs e)
        {

            PointF MouseUpPointPixel = new Point(e.X, e.Y);
            PointF MouseUpPointMap = Canvas.PixelToView(MouseUpPointPixel);


            int nodeindex = Canvas.NodeListTool.HitTest(MouseUpPointPixel);

            if (nodeindex >= 0)
            {
                //MouseUpPointMap = Canvas.NodeListTool.GetNodeCoordinate(nodeindex);
                MouseUpPointMap = Canvas.NodeListTool.NodeList[nodeindex].Center;
                MouseUpPointPixel = Canvas.ViewToPixel(MouseUpPointMap);
            }


            if (Points.Count >= 2)
            {
                PointF[] pts = Points.ToArray();
                pts[pts.Count() - 1] = MouseUpPointMap;


                pts = DouglasPeuckerLineSimplifier.Simplify(pts);

                bool added = false;


                if (Canvas.Document.EditList.SelectionList.Count == 1 &&
                    Canvas.Document.EditList[Canvas.Document.EditList.SelectionList[0]].GetType() == typeof(TomCanvasPath))
                {
                 
                        TomCanvasPath shp = (TomCanvasPath)Canvas.Document.EditList[Canvas.Document.EditList.SelectionList[0]];
                        
                        if (EditModeFreehand == true)
                        {
                            added = shp.AddCurve(pts);
                        }
                        else
                        {
                            added = shp.AddLine(pts);
                        }
                    
                }


                if (added == false)
                {
                    TomCanvasPath shp;

                    shp = new TomCanvasPath();

                    if (EditModeFreehand == true)
                    {
                        shp.AddCurve(pts);
                    }
                    else
                    {
                        shp.AddLine(pts);
                    }

                    Canvas.Document.EditList.Add(shp);
                    Canvas.Document.EditList.SelectLast();

                }

                Canvas.Document.PushEdit("Add line", false);
               
                              

                Points.Clear();
                EditModeFreehand = false;
            }

            Canvas.Redraw();
            Canvas.Refresh();

        }

        private void CreateShapeFromPoints(TomCanvas canvas)
        {
            TomCanvasPath shp = canvas.Document.GetLastFromEditList() as TomCanvasPath;

            byte[] types = new byte[Points.Count];

            for (int i = 0; i < Points.Count; i++)
            {
                types[i] = (byte)PathPointType.Line;
            }
            types[0] = (byte)PathPointType.Start;

            shp.GPath = new GraphicsPath(Points.ToArray(), types);
        }

       
    }
}
