﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Reflection;
using System.IO;

namespace TomControls
{
    public class TomCanvasToolZoom : TomCanvasTool
    {
        public TomCanvasToolZoom()
        {

            _Cursor = TomCanvasCursors.Zoom;
            _Icon = Properties.Resources.iconzoom;
        }

        public override string ToString()
        {
            return "Zoom";
        }
       
        public override void InitializeToolsStrip()
        {
            toolStrip.SuspendLayout();
            base.InitializeToolsStrip();


            Bitmap imgZoomIn = Properties.Resources.iconzoomin;
            ToolStripButton BtnZoomIn = new ToolStripButton(imgZoomIn);
            BtnZoomIn.Name = "ZoomIn";
            BtnZoomIn.ToolTipText = "Zoom In";
            BtnZoomIn.Click += new EventHandler(ToolbarBtn_Click);
            BtnZoomIn.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnZoomIn);

            Bitmap imgZoomOut = Properties.Resources.iconzoomout;
            ToolStripButton BtnZoomOut = new ToolStripButton(imgZoomOut);
            BtnZoomOut.Name = "ZoomOut";
            BtnZoomOut.ToolTipText = "Zoom out";
            BtnZoomOut.Click += new EventHandler(ToolbarBtn_Click);
            BtnZoomOut.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnZoomOut);

            toolStrip.Items.Add(new ToolStripSeparator());

            Bitmap imgZoomPage = Properties.Resources.iconzoompage;
            ToolStripButton BtnZoomPage = new ToolStripButton(imgZoomPage);
            BtnZoomPage.Name = "ZoomPage";
            BtnZoomPage.ToolTipText = "Zoom all page";
            BtnZoomPage.Click += new EventHandler(ToolbarBtn_Click);
            BtnZoomPage.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnZoomPage);

            Bitmap imgZoomAll = Properties.Resources.iconzoomall;
            ToolStripButton BtnZoomAll = new ToolStripButton(imgZoomAll);
            BtnZoomAll.Name = "ZoomAll";
            BtnZoomAll.ToolTipText = "Zoom all object";
            BtnZoomAll.Click += new EventHandler(ToolbarBtn_Click);
            BtnZoomAll.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnZoomAll);


            Bitmap imgZoomSelected = Properties.Resources.iconzoomselected;
            ToolStripButton BtnZoomSelected = new ToolStripButton(imgZoomSelected);
            BtnZoomSelected.Name = "ZoomSelected";
            BtnZoomSelected.ToolTipText = "Zoom selected object";
            BtnZoomSelected.Click += new EventHandler(ToolbarBtn_Click);
            BtnZoomSelected.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnZoomSelected);


            toolStrip.Items.Add(new ToolStripSeparator());

            Bitmap imgPan = Properties.Resources.iconpan;
            ToolStripButton BtnPan = new ToolStripButton(imgPan);
            BtnPan.Name = "Pan";
            BtnPan.ToolTipText = "Pan";
            BtnPan.Click += new EventHandler(ToolbarBtn_Click);
            BtnPan.ImageTransparentColor = Color.Magenta;
            toolStrip.Items.Add(BtnPan);

            toolStrip.ResumeLayout(true);
            toolStrip.Refresh();

        }

        void ToolbarBtn_Click(object sender, EventArgs e)
        {

            Canvas.ActualTool = TomCanvas.ToolZoom;

            ToolStripButton btn = (ToolStripButton)sender;

            switch (btn.Name)
            {
                case "ZoomAll":
                    {
                        Canvas.ZoomAll();
                    }
                    break;
                case "ZoomSelected":
                    {
                        Canvas.ZoomSelected();
                    }
                    break;
                case "ZoomPage":
                    {
                        Canvas.ZoomPage();
                    }
                    break;
                case "ZoomIn":
                    {
                        Canvas.ZoomIn();
                    }
                    break;
                case "ZoomOut":
                    {
                        Canvas.ZoomOut();
                    }
                    break;
                case "Pan":
                    {
                        Canvas.ActualTool = TomCanvas.ToolPan;
                    }
                    break;
            }
        }

        PointF MouseDownPointMap;
        PointF MouseUpPointMap;

        Point MouseDownPointPixel = new Point(0, 0);
        Point MouseUpPointPixel = new Point(0, 0);
        Point MouseActualPointPixel = new Point(0, 0);
        Point MousePreviousPointPixel = new Point(0, 0);

        public override void MouseDown(MouseEventArgs e)
        {
            //if (e.Button != MouseButtons.Left & e.Button != MouseButtons.Right) return;

            MouseDownPointPixel = new Point(e.X, e.Y);
            MousePreviousPointPixel = MouseDownPointPixel;
            MouseDownPointMap = Canvas.PixelToView(MouseDownPointPixel);
  
        }

        public override void MouseMove(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            MousePreviousPointPixel = MouseActualPointPixel;
            MouseActualPointPixel = new Point(e.X, e.Y);

            if (MousePreviousPointPixel.X != 0 && MousePreviousPointPixel.Y != 0)
            {
                Canvas.SetFocusRectangle(MouseDownPointPixel, MousePreviousPointPixel);
            }

            Canvas.SetFocusRectangle(MouseDownPointPixel, MouseActualPointPixel);
            Canvas.Refresh();
        }

        public override void MouseUp(MouseEventArgs e)
        {
            MouseUpPointPixel = new Point(e.X, e.Y);
            MouseUpPointMap = Canvas.PixelToView(MouseUpPointPixel);

            Rectangle pixelRec = Matematica.GetNormalizedRectangle(MouseDownPointPixel, MouseUpPointPixel);

            if (pixelRec.Width < 4 && pixelRec.Height < 4)
            {
                if (e.Button == MouseButtons.Left)
                {
                    Canvas.ZoomIn(MouseUpPointPixel);
                }

                if (e.Button == MouseButtons.Right)
                {
                    Canvas.ZoomOut(MouseUpPointPixel);
                }

            }
            else
            {
                if (e.Button == MouseButtons.Left)
                {
                    PointF p1 = Canvas.PixelToView(MouseDownPointPixel);
                    PointF p2 = Canvas.PixelToView(MouseUpPointPixel);

                    RectangleF rf = Matematica.GetNormalizedRectangle(p1, p2);

                    Canvas.ZoomRect(rf);
                }
            }


            MouseDownPointPixel = new Point(0, 0);
            MouseUpPointPixel = new Point(0, 0);
            MouseActualPointPixel = new Point(0, 0);
            MousePreviousPointPixel = new Point(0, 0);

            Canvas.Redraw();
            Canvas.Invalidate();
        }

  

    }
}
