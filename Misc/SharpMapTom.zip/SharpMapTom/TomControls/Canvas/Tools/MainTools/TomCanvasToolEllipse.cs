﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace TomControls
{
    class TomCanvasToolEllipse : TomCanvasToolRectangle
    {
        public TomCanvasToolEllipse()
        {
            _Cursor = TomCanvasCursors.AddEllipse;
            _Icon = Properties.Resources.iconaddellipse;
        }

        public override string ToString()
        {
            return "Add new Ellipse";
        }




        //public override void MouseDown(MouseEventArgs e)
        //{
        //    if (e.Button != MouseButtons.Left) return;

        //    MouseDownPointPixel = new Point(e.X, e.Y);
        //    MouseDownPointMap = Canvas.PixelToPage(MouseDownPointPixel);

        //    TomCanvasEllipse ellipse = new TomCanvasEllipse();

        //    Random rnd = new Random();

        //    byte[] rgb = new byte[3];

        //    rnd.NextBytes(rgb);

        //    ellipse.TomBrush.ForeColor = Color.FromArgb((int)rgb[0], (int)rgb[1], (int)rgb[2]);
        //    ellipse.TomPen.Pen.Color = Color.FromArgb((int)rgb[0] / 2, (int)rgb[1] / 2, (int)rgb[2] / 2);

        //    Canvas.Document.EditList.Add(ellipse);
        //    Canvas.Document.EditList.SelectLast();


        //}

        public override void MouseMove(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            

            PointF MouseActualPointPixel = new Point(e.X, e.Y);
            PointF MouseActualPointMap = Canvas.PixelToView(MouseActualPointPixel);

            if (Math.Abs(MouseDownPointPixel.X - MouseActualPointPixel.X) < 3 |
                Math.Abs(MouseDownPointPixel.Y - MouseActualPointPixel.Y) < 3) return;


            if (!RectangleAdded)
            {
                TomCanvasEllipse ellipse = new TomCanvasEllipse();

                Random rnd = new Random();

                byte[] rgb = new byte[3];

                rnd.NextBytes(rgb);

                ellipse.TomBrush.ForeColor = Color.FromArgb((int)rgb[0], (int)rgb[1], (int)rgb[2]);
                ellipse.TomPen.Pen.Color = Color.FromArgb((int)rgb[0] / 2, (int)rgb[1] / 2, (int)rgb[2] / 2);

                Canvas.Document.EditList.Add(ellipse);
                Canvas.Document.EditList.SelectLast();

                RectangleAdded = true;
            }




            ((TomCanvasEllipse)(Canvas.Document.GetLastFromEditList())).BaseRectangle =       
            Matematica.GetNormalizedRectangle(MouseDownPointMap, MouseActualPointMap);

            Canvas.SetFocusRectangle(MouseDownPointPixel, MouseActualPointPixel);
            Canvas.Refresh();
        }
     
        public override void MouseUp(MouseEventArgs e)
        {
            Point  MouseUpPointPixel = new Point(e.X, e.Y);
            PointF MouseUpPointMap = Canvas.PixelToView(MouseUpPointPixel);

            if (RectangleAdded)
            {
                ((TomCanvasEllipse)(Canvas.Document.GetLastFromEditList())).BaseRectangle =
                Matematica.GetNormalizedRectangle(MouseDownPointMap, MouseUpPointMap);
                
                RectangleAdded = false;

                Canvas.Document.AddEdit("Add Ellipse");

                Canvas.Redraw();
                Canvas.Refresh();
            }
            else
            {
                if (e.Button == MouseButtons.Left)
                {
                    Canvas.Document.Select(MouseUpPointMap);
                }

                Canvas.Redraw();
                Canvas.Refresh();
            }
        }
    }
}
