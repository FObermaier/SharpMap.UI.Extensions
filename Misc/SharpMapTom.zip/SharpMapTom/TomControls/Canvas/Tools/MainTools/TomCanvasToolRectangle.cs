﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace TomControls
{
    class TomCanvasToolRectangle : TomCanvasTool
    {
        public TomCanvasToolRectangle()
        {
            _Cursor = TomCanvasCursors.AddRectangle;
            _Icon = Properties.Resources.iconaddrectangle;
        }

        public override string ToString()
        {
            return "Add new rectangle";
        }

        public override void Initialize(TomCanvas theCanvas)
        {
            base.Initialize(theCanvas);

            ShowToolbarData();
        }


        TomDoubleNumericUpDownToolStripItem WH = new TomDoubleNumericUpDownToolStripItem();
        TomDoubleNumericUpDownToolStripItem Rxy = new TomDoubleNumericUpDownToolStripItem();

        public override void InitializeToolsStrip()
        {

            if (toolStrip == null) return;

            toolStrip.SuspendLayout();
            base.InitializeToolsStrip();

            WH.Label1.Text = "Width:";
            WH.Label2.Text = "Height:";
            WH.ValueChanged += new EventHandler(WH_ValueChanged);

            toolStrip.Items.Add(WH);

            Rxy.Label1.Text = "Rx:";
            Rxy.Label2.Text = "Ry:";
            Rxy.ValueChanged += new EventHandler(Rxy_ValueChanged);

            toolStrip.Items.Add(Rxy);
          
            toolStrip.ResumeLayout(true);
            toolStrip.Refresh();


        
        }

        void Rxy_ValueChanged(object sender, EventArgs e)
        {
            foreach (int i in Canvas.Document.EditList.SelectionList)
            {
                TomCanvasShapeBase shape = Canvas.Document.EditList.ElementAt(i);
                if (shape.GetType() == typeof(TomCanvasRectangle))
                {
                    //WH.Value1 = (decimal)((TomCanvasRectangle)shape).GetRectangleWidth();
                    //WH.Value2 = (decimal)((TomCanvasRectangle)shape).GetRectangleHeight();
                    ((TomCanvasRectangle)shape).RX = (float)Rxy.Value1;
                    ((TomCanvasRectangle)shape).RY = (float)Rxy.Value2;
                }
            }

            Canvas.Document.PushEdit("Rectangle radius changed", false);

            Canvas.Redraw();
            Canvas.Refresh();
        }

        void WH_ValueChanged(object sender, EventArgs e)
        {
            
        }


        private void ShowToolbarData()
        {
            for(int i=0; i< Canvas.Document.EditList.SelectionList.Count;i++)
            //foreach (TomCanvasShapeBase shape in Canvas.Document.EditList)
            {
                TomCanvasShapeBase shape = Canvas.Document.EditList.ElementAt(Canvas.Document.EditList.SelectionList[i]);

                if (shape.GetType() == typeof(TomCanvasRectangle))
                {
                    WH.Value1 = (decimal)((TomCanvasRectangle)shape).TransformedWidth;
                    WH.Value2 = (decimal)((TomCanvasRectangle)shape).TransformedHeight;
                    Rxy.Value1 = (decimal)((TomCanvasRectangle)shape).RX;
                    Rxy.Value2 = (decimal)((TomCanvasRectangle)shape).RY;
                    return;
                }
            }
            
            

        }



        protected PointF MouseDownPointMap;
        protected Point MouseDownPointPixel;

        protected bool RectangleAdded = false;


        public override void MouseDown(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            MouseDownPointPixel = new Point(e.X, e.Y);
            MouseDownPointMap = Canvas.PixelToView(MouseDownPointPixel);

        }

        

        public override void MouseMove(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            PointF MouseActualPointPixel = new Point(e.X, e.Y);
            PointF MouseActualPointMap = Canvas.PixelToView(MouseActualPointPixel);

            if (Math.Abs(MouseDownPointPixel.X - MouseActualPointPixel.X) < 3 |
                Math.Abs(MouseDownPointPixel.Y - MouseActualPointPixel.Y) < 3) return;


            if (!RectangleAdded)
            {
                TomCanvasRectangle rectangle = new TomCanvasRectangle();

                Random rnd = new Random();

                byte[] rgb = new byte[3];

                rnd.NextBytes(rgb);

                rectangle.TomBrush.ForeColor = Color.FromArgb((int)rgb[0], (int)rgb[1], (int)rgb[2]);

                Canvas.Document.EditList.Add(rectangle);
                Canvas.Document.EditList.SelectLast();

                RectangleAdded = true;
            }




            ((TomCanvasRectangle)(Canvas.Document.GetLastFromEditList())).BaseRectangle =
            Matematica.GetNormalizedRectangle(MouseDownPointMap, MouseActualPointMap);

            Canvas.Refresh();
        }

        public override void MouseUp(MouseEventArgs e)
        {
            Point  MouseUpPointPixel = new Point(e.X, e.Y);
            PointF MouseUpPointMap = Canvas.PixelToView(MouseUpPointPixel);

            if (RectangleAdded)
            {
                ((TomCanvasRectangle)(Canvas.Document.GetLastFromEditList())).BaseRectangle =
                Matematica.GetNormalizedRectangle(MouseDownPointMap, MouseUpPointMap);

                RectangleAdded = false;

                Canvas.Document.AddEdit("Add Rectangle");

                Canvas.Redraw();
                Canvas.Refresh();

                ShowToolbarData();
            }

            else
            {
                if (e.Button == MouseButtons.Left)
                {
                    Canvas.Document.Select(MouseUpPointMap);
                }

                Canvas.Redraw();
                Canvas.Refresh();
            }
        }
    }
}
