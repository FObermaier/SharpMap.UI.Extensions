﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TomControls
{
    class TomCanvasToolPolygon: TomCanvasTool
    {

        public TomCanvasToolPolygon()
        {

            _Cursor = TomCanvasCursors.Arrow;
            _Icon = Properties.Resources.iconaddpolygon;

        }
        
        public override void InitializeToolsStrip()
        {

            toolStrip.SuspendLayout();
            base.InitializeToolsStrip();
            toolStrip.Items.Add(Properties.Resources.iconvoid);
            toolStrip.ResumeLayout(true);
            toolStrip.Refresh();

        }

        public override string ToString()
        {
            //throw new NotImplementedException();
            return "";
        }

        public override void Initialize(TomCanvas canvas)
        {
            base.Initialize(canvas);
        }

        public override void MouseDown(MouseEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public override void MouseMove(MouseEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public override void MouseUp(MouseEventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
}
