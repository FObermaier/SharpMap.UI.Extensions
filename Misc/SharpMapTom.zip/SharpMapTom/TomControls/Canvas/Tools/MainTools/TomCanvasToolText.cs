﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;

namespace TomControls
{

    public class CaretManager : IDisposable
    {
        public Point pBase = new Point();
        public Point pTop = new Point();

        public bool Visible
        {
            get
            {
                return T.Enabled;
            }
            set
            {
                T.Enabled = value;
            }
        }

        private Timer T = null;

        public TomCanvas Canvas;

        public CaretManager(TomCanvas canvas)
        {
            Canvas = canvas;
            T = new Timer();

            T.Interval = 500;
            T.Enabled = true;

            T.Tick += new EventHandler(T_Tick);
        }

        void T_Tick(object sender, EventArgs e)
        {
            ControlPaint.DrawReversibleLine(Canvas.PointToScreen(pBase), Canvas.PointToScreen(pTop), Color.Black);
        }



        #region IDisposable Membri di

        public void Dispose()
        {
            T.Enabled = false;
            T.Dispose();
        }

        #endregion
    }

    public class TomCanvasToolText: TomCanvasTool
    {

        private CaretManager Caret;

        public TomCanvasToolText()
        {
            _Cursor = TomCanvasCursors.Arrow;
            _Icon = Properties.Resources.iconaddtext;
        }

        ToolStripComboBox FontNameComboBox = new ToolStripComboBox();
        ToolStripComboBox FontSizeComboBox = new ToolStripComboBox();

        public override void InitializeToolsStrip()
        {

            if (toolStrip == null) return;

            toolStrip.SuspendLayout();
            base.InitializeToolsStrip();

            FontNameComboBox.Width = 200;
            FontNameComboBox.DropDownStyle= ComboBoxStyle.DropDownList;
            foreach (FontFamily family in FontEnumerator.FontFamilies)
            {
                FontNameComboBox.Items.Add(family.Name);
            }
            FontNameComboBox.SelectedItem = "Arial";
            toolStrip.Items.Add(FontNameComboBox);



            FontSizeComboBox.Width = 15;
            for (int i = 6; i < 48; i += 2)
            {
                FontSizeComboBox.Items.Add(i.ToString().Trim());
            }
            FontSizeComboBox.SelectedItem = "10";
            toolStrip.Items.Add(FontSizeComboBox);


            toolStrip.ResumeLayout(true);
            toolStrip.Refresh();

        }

        public override string ToString()
        {
            //throw new NotImplementedException();
            return "";
        }

        public override void Initialize(TomCanvas canvas)
        {
            base.Initialize(canvas);
            Caret = new CaretManager(canvas);
        }

        public override void LeaveTool()
        {            
            base.LeaveTool();
            Caret.Visible = false;
        }

        public PointF MouseDownPointPixel;
        public PointF MouseDownPointMap;

        public override void MouseDown(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            MouseDownPointPixel = new Point(e.X, e.Y);
            MouseDownPointMap = Canvas.PixelToView(MouseDownPointPixel);

        }

        bool ParagraphAdded = false;
        public override void MouseMove(MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;

            PointF MouseActualPointPixel = new Point(e.X, e.Y);
            PointF MouseActualPointMap = Canvas.PixelToView(MouseActualPointPixel);

            if (Math.Abs(MouseDownPointPixel.X - MouseActualPointPixel.X) < 3 |
                Math.Abs(MouseDownPointPixel.Y - MouseActualPointPixel.Y) < 3) return;


            if (!ParagraphAdded)
            {
                TomCanvasText Text = new TomCanvasText();

                Random rnd = new Random();

                byte[] rgb = new byte[3];

                rnd.NextBytes(rgb);

                Text.TomBrush.ForeColor = Color.Transparent;

                Canvas.Document.EditList.Add(Text);
                Canvas.Document.EditList.SelectLast();

                ParagraphAdded = true;
            }


            ((TomCanvasText)(Canvas.Document.GetLastFromEditList())).BaseRectangle =
            Matematica.GetNormalizedRectangle(MouseDownPointMap, MouseActualPointMap);

            Canvas.Refresh();
        }

        public override void MouseUp(MouseEventArgs e)
        {

            if(!ParagraphAdded)
            {
                Caret.pBase = new Point(e.X, e.Y);
                Caret.pTop = new Point(e.X, e.Y - 10);
                Caret.Visible = true;
            }

            ParagraphAdded = false;

        }

        public void OnKeyUp(KeyEventArgs e)
        {
            if(Canvas.Document.GetLastFromEditList().GetType() == typeof(TomCanvasText))
            {
                TomCanvasText text = (TomCanvasText)Canvas.Document.GetLastFromEditList();
                text.Text += e.KeyCode.ToString();
                Canvas.Redraw();
                Canvas.Refresh();
            }
        }


    }
}
