﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace TomControls
{
    public partial class FormPageSize : Form
    {

        public TomPageSize PaperSize = new TomPageSize();

        public FormPageSize()
        {
            InitializeComponent();
        }

        private void FormPageSize_Load(object sender, EventArgs e)
        {

            foreach (TomPaperKind pkind in Enum.GetValues(typeof(TomPaperKind)))
            {
                String s = TomPaperKindTools.GetDecoredName(pkind);

                int i = listBoxPageSizes.Items.Add(s);

                if (pkind == PaperSize.PaperKind)
                {
                    listBoxPageSizes.SelectedIndex = i;

                    if (TomPaperKindTools.GetUnit(pkind) == GraphicsUnit.Millimeter)
                    {
                        comboBoxUnit.SelectedIndex = 0;
                    }
                    else
                    {
                        comboBoxUnit.SelectedIndex = 1;
                    }

                }
            }

            if (PaperSize.Landscape)
            {
                comboBoxLandscape.SelectedIndex = 1;
            }
            else
            {
                comboBoxLandscape.SelectedIndex = 0;
            }

            numericUpDownWidth.Value = (decimal)PaperSize.Size.Width;
            numericUpDownHeight.Value = (decimal)PaperSize.Size.Height;
        }

        private void listBoxPageSizes_SelectedIndexChanged(object sender, EventArgs e)
        {
            Structure();
        }
        
        private void comboBoxLandscape_SelectedIndexChanged(object sender, EventArgs e)
        {
            Structure();
        }

        private void Structure()
        {
            TomPaperKind pkind = (TomPaperKind)listBoxPageSizes.SelectedIndex;

            if (pkind == TomPaperKind.CUSTOM)
            {
                SizeF s = PaperSize.Size;

                comboBoxLandscape.SelectedIndex = 0;
                comboBoxLandscape.Enabled = false;

                groupBoxCustom.Enabled = true;
            }
            else
            {
                SizeF s = TomPaperKindTools.GetSize(pkind);

                comboBoxLandscape.Enabled = true;

                if (comboBoxLandscape.SelectedIndex == 0)
                {
                    numericUpDownWidth.Value = (decimal)s.Width;
                    numericUpDownHeight.Value = (decimal)s.Height;
                }
                else
                {
                    numericUpDownWidth.Value = (decimal)s.Height;
                    numericUpDownHeight.Value = (decimal)s.Width;
                }

                groupBoxCustom.Enabled = false;

                GraphicsUnit gu = TomPaperKindTools.GetUnit(pkind);

                if (gu == GraphicsUnit.Millimeter)
                {
                    comboBoxUnit.SelectedIndex = 0;
                }
                else
                {
                    comboBoxUnit.SelectedIndex = 1;
                }
            }
        }
        private void buttonOK_Click(object sender, EventArgs e)
        {
            PaperSize.PaperKind = (TomPaperKind)listBoxPageSizes.SelectedIndex;
            PaperSize.Size = new SizeF((float)numericUpDownWidth.Value, (float)numericUpDownHeight.Value);
            PaperSize.Landscape = comboBoxLandscape.SelectedIndex == 1;
            
            if (comboBoxUnit.SelectedIndex == 0)
            {
                PaperSize.Units = GraphicsUnit.Millimeter;
            }
            else
            {
                PaperSize.Units = GraphicsUnit.Inch;
            }
            
            DialogResult = DialogResult.OK;
            Close();
        }



  
    }
}
