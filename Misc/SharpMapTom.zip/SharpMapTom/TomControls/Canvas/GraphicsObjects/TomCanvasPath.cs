﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace TomControls
{
    public enum SubPathTypes
    {
        Line,
        Curve
    }

    public class SubPathObject
    {
        public SubPathTypes PathThpe;
        public GraphicsPath GPath = new GraphicsPath();
        public int StartNodeIndex = -1;

        public SubPathObject()
        {
        }

        public SubPathObject (PointF[] points, SubPathTypes type)
        {
            PathThpe = type;

            switch (PathThpe)
            {
                case SubPathTypes.Curve:
                    GPath.AddCurve(points);
                    break;
                case SubPathTypes.Line:
                    GPath.AddLines(points);
                    break;
            }
        }

        public SubPathObject Clone()
        {
            SubPathObject newSubPath = new SubPathObject();
            
            newSubPath.PathThpe = PathThpe;
            newSubPath.GPath = (GraphicsPath)GPath.Clone();

            return newSubPath;
        }

        public void AddNodesToList(TomCanvasNodeListTool NodeList, int shapeIndex, int startNodeIndex)
        {
            StartNodeIndex = startNodeIndex;

            int subNodetypeCounter = 0;
            if (PathThpe == SubPathTypes.Line)
            {
                for (int i = 0; i < GPath.PathPoints.Count(); i++)
                {
                    NodeList.AddNode(GPath.PathPoints[i], TomCanvasNodeTypes.Square, shapeIndex, startNodeIndex + i);
                }
            }
            else
            {

                for (int i = 0; i < GPath.PathPoints.Count(); i++)
                {
                    TomCanvasNodeTypes nodetype = TomCanvasNodeTypes.Square;

                    switch (subNodetypeCounter)
                    {
                        case 0:
                            nodetype = TomCanvasNodeTypes.Square;
                            break;
                        case 1:
                            nodetype = TomCanvasNodeTypes.HandleToPrevious;
                            break;
                        case 2:
                            nodetype = TomCanvasNodeTypes.HandleToNext;
                            break;
                        case 3:
                            nodetype = TomCanvasNodeTypes.Square;
                            break;
                    }

                    subNodetypeCounter++;
                    if (subNodetypeCounter == 3) subNodetypeCounter = 0;

                    NodeList.AddNode(GPath.PathPoints[i], nodetype, shapeIndex, startNodeIndex + i);
                }
            }
        }

        public void AddToPath(GraphicsPath gp)
        {
            gp.AddPath(GPath,true);           
        }

    }

    public class SubPathObjectList : List<SubPathObject>
    {
        public void AddNodesToList(TomCanvasNodeListTool NodeList, int shapeIndex)
        {
            int n = 0;

            foreach (SubPathObject SubPath in this)
            {
                n += SubPath.GPath.PointCount;
            }

            NodeList.NodeList.Capacity += n;

            int startindex = 0;
            foreach(SubPathObject SubPath in this)
            {
                SubPath.AddNodesToList(NodeList, shapeIndex, startindex);
                startindex += SubPath.GPath.PathPoints.Count();
            }
        }

        public SubPathObjectList Clone()
        {
            SubPathObjectList newList = new SubPathObjectList();

            newList.Capacity = this.Count;

            foreach (SubPathObject SubPath in this)
            {
                newList.Add(SubPath.Clone());
            }

            return newList;
        }

        public void MoveNode(int nodeindex, PointF point)
        {
            for (int i = Count - 1; i >= 0; i--)
            {
                SubPathObject subpath = this.ElementAt(i);

                if (subpath.StartNodeIndex <= nodeindex)
                {
                    //subpath.GPath.PathPoints[nodeindex-subpath.StartNodeIndex]=point;

                    PointF[] points = (PointF[])subpath.GPath.PathPoints.Clone();
                    byte[] types = (byte[])subpath.GPath.PathTypes.Clone();

                    subpath.GPath.Reset();

                    points[nodeindex - subpath.StartNodeIndex] = point;

                    subpath.GPath = new GraphicsPath(points, types);

                    return;
                }
            }
            
        }

    }


    [Serializable]
    class TomCanvasPath: TomCanvasShapeBase
    {
        SubPathObjectList SubPats = new SubPathObjectList();

        public PointF StartPoint
        {
            get
            {
                if (SubPats.Count>0)
                {
                    return SubPats[0].GPath.PathPoints[0];
                }

                return PointF.Empty;
            }
        }

        public PointF EndPoint
        {
            get
            {
                if (SubPats.Count > 0)
                {
                    return SubPats[SubPats.Count - 1].GPath.PathPoints[SubPats[SubPats.Count - 1].GPath.PathPoints.Count() - 1];
                }

                return PointF.Empty;
            }
        }

        

        private bool AddObject(PointF[] points, SubPathTypes pathType)
        {

            bool Added = false;

            PointF InputStartPoint = points[0];
            PointF InputEndPoint = points[points.Count() - 1];

            if (SubPats.Count == 0)
            {
                Added = true;
                SubPats.Add(new SubPathObject(points, pathType));
            }

            else if (InputEndPoint == StartPoint)
            {
                Added = true;
                SubPats.Insert(0, new SubPathObject(points, pathType));
            }

            else if (InputStartPoint == EndPoint)
            {
                Added = true;
                SubPats.Add(new SubPathObject(points, pathType));
            }

            else if (InputStartPoint == StartPoint)
            {
                Added = true;
                Array.Reverse(points);
                SubPats.Insert(0, new SubPathObject(points, pathType));
            }
            else if (InputEndPoint == EndPoint)
            {
                Added = true;
                Array.Reverse(points);
                SubPats.Add(new SubPathObject(points, pathType));
            }

            if (Added)
            {

                if (StartPoint == EndPoint)
                {

                }

                BuildPath();
            }

            return Added;
        }

        public bool AddCurve(PointF[] points)
        {

            return AddObject(points, SubPathTypes.Curve);

        }

        public bool AddLine(PointF[] points)
        {
          
            return AddObject(points, SubPathTypes.Line);
          
        }

        public void BuildPath()
        {
            _GPath.Reset();

            foreach(SubPathObject subpath in SubPats)
            {
                subpath.AddToPath(_GPath);
            }
        }

        public override void Draw(Graphics g)
        {
            g.DrawPath(TomPen.Pen, GPath);
        }

        public override void Draw(Graphics g, Matrix m, Pen p)
        {
            GraphicsPath gp = (GraphicsPath)_GPath.Clone();

            gp.Transform(m);

            g.DrawPath(p, gp);
        }

        public override bool HitTest(PointF point)
        {
            if (_GPath.IsVisible(point) | _GPath.IsOutlineVisible(point, TomPen.Pen)  )
            {
                return true;
            }

            return false;
        }

        public override bool HitTest(RectangleF rect)
        {
            if (rect.Contains(GetBounds()))
            {
                return true;
            }

            return false;
        }


        public override TomCanvasShapeBase Clone()
        {
            TomCanvasPath newShape = new TomCanvasPath();

            newShape.SubPats = SubPats.Clone();

            newShape.GPath = (GraphicsPath)_GPath.Clone();
            newShape.RotationCenter = new PointF(_RotationCenter.X, _RotationCenter.Y);
            newShape.TomBrush = _TomBrush.Clone();
            newShape.TomPen = _TomPen.Clone();


            return newShape;
        }

        public override void Transform(Matrix m)
        {

            foreach (SubPathObject subpath in SubPats)
            {
                subpath.GPath.Transform(m);
            }
            
            BuildPath();
        }

        public override void MoveNode(int nodeindex, PointF point)
        {
            SubPats.MoveNode(nodeindex, point);
            BuildPath();
        }

        public override void AddNodesToList(TomCanvasNodeListTool NodeList, int shapeIndex)
        {
            SubPats.AddNodesToList(NodeList, shapeIndex);
        }

        public override void AddEndsToList(TomCanvasNodeListTool NodeList, int shapeIndex)
        {
            if (GPath.PointCount == 0) return;

            int i = 0;
            NodeList.AddNode(GPath.PathPoints[i], TomCanvasNodeTypes.Square, shapeIndex, i);

            if (GPath.PointCount < 2) return;

            i = GPath.PointCount - 1;
            NodeList.AddNode(GPath.PathPoints[i], TomCanvasNodeTypes.Square, shapeIndex, i);            
        }

        public override PointF GetNodeCoordinates(int index)
        {
            return GPath.PathPoints[index];
        }
    }
}
