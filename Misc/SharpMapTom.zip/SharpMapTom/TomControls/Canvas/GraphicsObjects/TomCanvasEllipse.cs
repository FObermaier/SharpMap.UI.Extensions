﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace TomControls
{
    [Serializable]
    public class TomCanvasEllipse : TomCanvasShapeBase
    {
        private const short LTPoint = 0;
        private const short RTPoint = 1;
        private const short LBPoint = 2;

        
        public PointF[] BasePoints = new PointF[3];
        public PointF[] TransformedPoints = new PointF[3];


        public PointF Location
        {
            get
            {
                return BasePoints[LTPoint];
            }
        }

        public float BaseWidth
        {
            get
            {
                return BasePoints[RTPoint].X - BasePoints[LTPoint].X;
            }
        }

        public float BaseHeight
        {
            get
            {
                return BasePoints[LBPoint].Y - BasePoints[LTPoint].Y;
            }
        }

        public RectangleF BaseRectangle
        {
            get
            {
                return new RectangleF(Location, new SizeF(BaseWidth, BaseHeight));
            }
            set
            {
                BasePoints[LTPoint] = value.Location;
                BasePoints[RTPoint] = new PointF(value.Right, value.Top);
                BasePoints[LBPoint] = new PointF(value.Left, value.Bottom);

                BuildPath();

            }
        }

        private void BuildPath()
        {
            TransformedPoints = (PointF[])BasePoints.Clone();

            TransformMatrix.TransformPoints(TransformedPoints);

            _GPath.Reset();

            _GPath.AddEllipse(BaseRectangle);

            _GPath.Transform(TransformMatrix);

        }

        public override void Draw(Graphics g, Matrix m, Pen p)
        {
            GraphicsPath gp = new GraphicsPath();


            if (_GPath.PointCount > 0)
            {
                gp.AddPath(_GPath, false);
            }

            gp.Transform(m);

            g.DrawPath(p, gp);



            gp.Dispose();

        }

        public override void Draw(Graphics g)
        {

            RectangleF bounds = GetBounds();

            Brush brush = TomBrush.GetBrush(bounds);
            g.FillPath(brush, _GPath);
            g.DrawPath(TomPen.Pen, _GPath);

        }

        public override bool HitTest(PointF point)
        {
            if (_GPath.IsVisible(point))
            {
                return true;
            }

            return false;
        }

        public override bool HitTest(RectangleF rect)
        {
            if (rect.Contains(GetBounds()))
            {
                return true;
            }

            return false;

        }


        public override TomCanvasShapeBase Clone()
        {
            TomCanvasEllipse newShape = new TomCanvasEllipse();

            newShape.BasePoints = (PointF[])BasePoints.Clone();
            newShape.TransformedPoints = (PointF[])TransformedPoints.Clone();

            newShape.GPath = (GraphicsPath)_GPath.Clone();
            newShape.RotationCenter = new PointF(_RotationCenter.X, _RotationCenter.Y);
            newShape.TomBrush = _TomBrush.Clone();
            newShape.TomPen = _TomPen.Clone();

            return (TomCanvasShapeBase)newShape;
        }


        public override void Transform(Matrix m)
        {
            m.TransformPoints(TransformedPoints);

            if (TransformedPoints[LTPoint].Y == TransformedPoints[RTPoint].Y &&
                TransformedPoints[LTPoint].X == TransformedPoints[LBPoint].X)
            {

                BasePoints = (PointF[])TransformedPoints.Clone();

                TransformMatrix = new Matrix();
            }
            else
            {

                PointF[] Warp = new PointF[] { TransformedPoints[LTPoint], TransformedPoints[RTPoint], TransformedPoints[LBPoint] };

                TransformMatrix = new Matrix(BaseRectangle, Warp);
            }

            if (hasRotationCenter())
            {
                _RotationCenter.X += m.OffsetX;
                _RotationCenter.Y += m.OffsetY;
            }

            BuildPath();
        }


        public override void MoveNode(int nodeindex, PointF point)
        {

            PointF[] p = new PointF[1];
            p[0] = point;

            InvertedMatrix.TransformPoints(p);


            switch (nodeindex)
            {
                case (0):
                    {
                        BasePoints[RTPoint] = p[0];
                        BasePoints[LTPoint].Y = p[0].Y;
                    }
                    break;
                case (1):
                    {
                        BasePoints[LBPoint] = p[0];
                        BasePoints[LTPoint].X = p[0].X;

                    }
                    break;
             
            }

            BuildPath();

        }

        public override void AddNodesToList(TomCanvasNodeListTool NodeList, int shapeIndex)
        {
            int count = 0;

            NodeList.AddNode(TransformedPoints[RTPoint], TomCanvasNodeTypes.Square, shapeIndex, count); count++;
            NodeList.AddNode(TransformedPoints[LBPoint], TomCanvasNodeTypes.Square, shapeIndex, count); count++;
        }


        public override void AddEndsToList(TomCanvasNodeListTool NodeList, int shapeIndex)
        {
            throw new NotImplementedException();
        }

        public override PointF GetNodeCoordinates(int index)
        {
            throw new NotImplementedException();
        }
    }
}
