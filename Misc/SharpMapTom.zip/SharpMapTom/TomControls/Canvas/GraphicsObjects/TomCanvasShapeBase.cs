﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.Reflection;

namespace TomControls
{

    [Serializable]
    public abstract class TomCanvasShapeBase 
    {

        protected GraphicsPath _GPath = new GraphicsPath();
        public GraphicsPath GPath
        {
            get
            {
                return _GPath;
            }
            set
            {
                _GPath = value;
            }
        }

        protected Matrix _Matrix = new Matrix();
        public Matrix TransformMatrix
        {
            get
            {
                return _Matrix;
            }
            set
            {
                _Matrix = value;
            }
        }

        public Matrix InvertedMatrix
        {
            get
            {
                if (_Matrix.IsInvertible)
                {
                    Matrix m = _Matrix.Clone();
                    m.Invert();
                    return m;
                }

                return null;
            }
        }

        public RectangleF GetBounds()
        {

            GraphicsPath p = (GraphicsPath)GPath.Clone();

            p.Flatten();

            RectangleF r = p.GetBounds();

            p.Dispose();

            return r;
        }

        protected TomPen _TomPen = new TomPen();
        public TomPen TomPen
        {
            get
            {
                return _TomPen;
            }
            set
            {
                _TomPen = value;
            }
        }

        protected TomBrush _TomBrush = new TomBrush();
        public TomBrush TomBrush
        {
            get
            {
                return _TomBrush;
            }
            set
            {
                _TomBrush = value;
            }
        }
        
        protected PointF _RotationCenter = new PointF(float.NaN, float.NaN);
        public PointF RotationCenter
        {
            set
            {
                _RotationCenter = value;
            }
            get
            {
                if (float.IsNaN(_RotationCenter.X) | float.IsNaN(_RotationCenter.Y))
                {
                    return Matematica.GetRectangleCenter(GetBounds());
                }
                else
                {
                    return _RotationCenter;
                }
            }
        }

        public bool hasRotationCenter()
        {
            
            if (float.IsNaN( _RotationCenter.X )| float.IsNaN(_RotationCenter.Y))
            {
                return false;
            }

            return true;
        }

        public abstract void Draw(Graphics g);
        public abstract void Draw(Graphics g, Matrix m, Pen p);

        public abstract bool HitTest(PointF point);
        public abstract bool HitTest(RectangleF rect);

        public abstract void Transform(Matrix m);

        public abstract void AddNodesToList(TomCanvasNodeListTool NodeList, int shapeIndex);
        public abstract void AddEndsToList(TomCanvasNodeListTool NodeList, int shapeIndex);

        public abstract PointF GetNodeCoordinates(int index);

        public abstract void MoveNode(int nodeindex, PointF point);

        public abstract TomCanvasShapeBase Clone();        

    }

}
