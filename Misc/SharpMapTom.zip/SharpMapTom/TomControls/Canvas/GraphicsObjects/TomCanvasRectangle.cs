﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace TomControls
{
    [Serializable]
    public class TomCanvasRectangle : TomCanvasShapeBase
    {
        private const short LTPoint = 0;
        private const short RTPoint = 1;
        private const short LBPoint = 2;
        private const short RXPoint = 3;
        private const short RYPoint = 4;

        public PointF[] BasePoints = new PointF[5];
        public PointF[] TransformedPoints = new PointF[5];

        public PointF Location
        {
            get
            {
                return BasePoints[LTPoint];
            }
        }

        public float BaseWidth
        {
            get
            {
                return BasePoints[RTPoint].X - BasePoints[LTPoint].X;
            }
        }

        public float BaseHeight
        {
            get
            {
                return BasePoints[LBPoint].Y - BasePoints[LTPoint].Y;
            }
        }


        public float TransformedWidth
        {
            get
            {
                return Matematica.Distance(TransformedPoints[RTPoint], TransformedPoints[LTPoint]);
            }
        }

        public float TransformedHeight
        {
            get
            {
                return Matematica.Distance(TransformedPoints[LBPoint], TransformedPoints[LTPoint]);
            }
        }


        public RectangleF BaseRectangle
        {
            get
            {
                return new RectangleF(Location, new SizeF(BaseWidth, BaseHeight));
            }
            set
            {
                BasePoints[LTPoint] = value.Location;
                BasePoints[RTPoint] = new PointF(value.Right, value.Top);
                BasePoints[LBPoint] = new PointF(value.Left, value.Bottom);
                BasePoints[RXPoint] = new PointF(value.Left + RX, value.Top);
                BasePoints[RYPoint] = new PointF(value.Left, value.Top - RY);

                BuildPath();

            }
        }


        private float _rx = 0f;
        public float RX
        {
            get
            {
                return _rx;
            }
            set
            {
                _rx = value;
            }
        }

        private float _ry = 0f;
        public float RY
        {
            get
            {
                return _ry;
            }
            set
            {
                _ry = value;
            }
        }

    
        private void BuildPath()
        {
            TransformedPoints = (PointF[])BasePoints.Clone();

            TransformMatrix.TransformPoints(TransformedPoints);
           
            if (BaseWidth <= 0 | BaseHeight <= 0) return;

            _GPath.Reset();

            _GPath.AddPath(GetRoundRect(BaseRectangle, _rx, _ry), false);

            _GPath.Transform(TransformMatrix);

        }

   
        private static GraphicsPath GetRoundRect(RectangleF r, float Rx, float Ry)
        {
            float rx = Rx, ry = Ry;

            if (rx == 0) rx = ry;
            if (ry == 0) ry = rx; 
            
            if (ry > r.Height / 2) ry = r.Height / 2;
            if (rx > r.Width / 2) rx = r.Width / 2;


            GraphicsPath g = new GraphicsPath();

            if (rx == 0 & ry == 0)
            {
                g.AddRectangle(r);
            }
            else
            {
                float dx = rx;
                float dy = ry;

                PointF TL = r.Location;
                PointF TR = new PointF(r.X + r.Width, r.Y);
                PointF BR = new PointF(r.X + r.Width, r.Y + r.Height);
                PointF BL = new PointF(r.X, r.Y + r.Height);

                //g.AddArc(TL.X, TL.Y, dx, dy, -180, 90);
                float k = 0.5522847498f; //4/3(sqrt(2)-1) http://hansmuller-flex.blogspot.it/2011/04/approximating-circular-arc-with-cubic.html
                float k1 = 1-k;

                g.AddBezier(new PointF(TL.X, TL.Y + dy),
                            new PointF(TL.X, TL.Y + k1 * dy),
                            new PointF(TL.X + k1 * dx, TL.Y),
                            new PointF(TL.X + dx, TL.Y));

                g.AddLine(TL.X + dx, TL.Y, TR.X - dx, TR.Y);

                //g.AddArc(TR.X - dx, TR.Y, dx, dy, -90, 90);
                g.AddBezier(new PointF(TR.X - dx, TL.Y),
                           new PointF(TR.X - k1 * dx, TL.Y),
                           new PointF(TR.X, TR.Y + k1 * dy),
                           new PointF(TR.X, TR.Y + dy));
                g.AddLine(TR.X, TR.Y + dy, BR.X, BR.Y - dy);

                //g.AddArc(BR.X - dx, BR.Y - dy, dx, dy, 0, 90);
                g.AddBezier(new PointF(BR.X, BR.Y - dy),
                          new PointF(BR.X, BR.Y - k1 * dy),
                          new PointF(BR.X - k1 * dx, BR.Y),
                          new PointF(BR.X - dx, BR.Y));
                g.AddLine(BR.X - dx, BR.Y, BL.X + dx, BL.Y);

                //g.AddArc(BL.X, BL.Y - dy, dx, dy, 90, 90);
                g.AddBezier(new PointF(BL.X + dx, BR.Y),
                          new PointF(BL.X + k1 * dx, BR.Y),
                          new PointF(BL.X, BL.Y - k1 * dy),
                          new PointF(BL.X, BL.Y - dy));
                g.AddLine(BL.X, BL.Y - dy, TL.X, TL.Y + dy);

                g.CloseFigure();
            }

            return g;
        }

        public override void Draw(Graphics g, Matrix m, Pen p)
        {
            GraphicsPath gp = new GraphicsPath();
            
            if (_GPath.PointCount > 0)
            {
                gp.AddPath(_GPath, false);
            }

            gp.Transform(m);
            
            g.DrawPath(p, gp);

            gp.Dispose();

        }

        public override void Draw(Graphics g)
        {

            RectangleF bounds = GetBounds();

            Brush brush = TomBrush.GetBrush(bounds);
            g.FillPath(brush, _GPath);
            g.DrawPath(TomPen.Pen, _GPath);

        }

        public override bool HitTest(PointF point)
        {
            if (_GPath.IsVisible(point))
            {
                return true;
            }

            return false;
        }

        public override bool HitTest(RectangleF rect)
        {
            if (rect.Contains(GetBounds()))
            {
                return true;
            }

            return false;

        }


        public override TomCanvasShapeBase Clone()
        {
            TomCanvasRectangle newShape = new TomCanvasRectangle();

            newShape.BasePoints = (PointF[])BasePoints.Clone();
            newShape.TransformedPoints = (PointF[])TransformedPoints.Clone();

            newShape.GPath = (GraphicsPath)_GPath.Clone();
            newShape.RX = RX;
            newShape.RY = RY;
            newShape.RotationCenter = new PointF(_RotationCenter.X, _RotationCenter.Y);
            newShape.TomBrush = _TomBrush.Clone();
            newShape.TomPen = _TomPen.Clone();

            return (TomCanvasShapeBase)newShape;
        }


        public override void Transform(Matrix m)
        {
            m.TransformPoints(TransformedPoints);

            if (TransformedPoints[LTPoint].Y == TransformedPoints[RTPoint].Y &&
                TransformedPoints[LTPoint].X == TransformedPoints[LBPoint].X)
            {
                
                BasePoints = (PointF[])TransformedPoints.Clone();

                TransformMatrix = new Matrix();
            }
            else
            {

                PointF[] Warp = new PointF[] { TransformedPoints[LTPoint], TransformedPoints[RTPoint], TransformedPoints[LBPoint] };

                TransformMatrix = new Matrix(BaseRectangle, Warp);
            }

            if (hasRotationCenter() )
            {
                _RotationCenter.X += m.OffsetX;
                _RotationCenter.Y += m.OffsetY;
            }

            BuildPath();
        }


        public override void MoveNode(int nodeindex, PointF point)
        {

            PointF[] p = new PointF[1];
            p[0] = point;

            InvertedMatrix.TransformPoints(p);


            switch (nodeindex)
            {
                case (0):
                    {
                        BasePoints[RTPoint] = p[0];
                        BasePoints[LTPoint].Y = p[0].Y;
                    }
                    break;
                case (1):
                    {
                        BasePoints[LBPoint] = p[0];
                        BasePoints[LTPoint].X = p[0].X;

                    }
                    break;
                case (2):
                    {
                        nodeindex = RXPoint;

                        RX = (float)(p[0].X - BasePoints[LTPoint].X);


                    }
                    break;
                case (3):
                    {
                        nodeindex = RYPoint;

                        RY = (float)(p[0].Y - BasePoints[LTPoint].Y);

                    }
                    break;
            }

            if (RX < 0) RX = 0;
            if (RX > BaseWidth / 2) RX = BaseWidth / 2;

            if (RY < 0) RY = 0;
            if (RY > BaseHeight / 2) RY = BaseHeight / 2;

            BasePoints[RXPoint].X = BasePoints[LTPoint].X + RX;
            BasePoints[RXPoint].Y = BasePoints[LTPoint].Y;

            BasePoints[RYPoint].Y = BasePoints[LTPoint].Y + RY;
            BasePoints[RYPoint].X = BasePoints[LTPoint].X;

            BuildPath();

        }

        public override void AddNodesToList(TomCanvasNodeListTool NodeList, int shapeIndex)
        {
            int count = 0;

            NodeList.AddNode(TransformedPoints[RTPoint], TomCanvasNodeTypes.Square, shapeIndex, count); count++;
            NodeList.AddNode(TransformedPoints[LBPoint], TomCanvasNodeTypes.Square, shapeIndex, count); count++;
            NodeList.AddNode(TransformedPoints[RXPoint], TomCanvasNodeTypes.circle, shapeIndex, count); count++;
            NodeList.AddNode(TransformedPoints[RYPoint], TomCanvasNodeTypes.circle, shapeIndex, count); count++;
        }

        public override void AddEndsToList(TomCanvasNodeListTool NodeList, int shapeIndex)
        {
            throw new NotImplementedException();
        }

        public override PointF GetNodeCoordinates(int index)
        {
            throw new NotImplementedException();
        }
    }
}
