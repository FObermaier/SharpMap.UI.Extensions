﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.Drawing.Drawing2D;

namespace TomControls
{

    public partial class TomCanvas : UserControl
    {


        #region ToolsManagementVars
        public const int ToolNone         = -1;

        public const int ToolSelect       = 0;
        public const int ToolNode         = 1; 
        public const int ToolZoom         = 2;

        public const int ToolDraw         = 3;
        public const int ToolRectangle    = 4;
        public const int ToolEllipse      = 5;
        public const int ToolPolygon      = 6;
        public const int ToolText         = 7;
        public const int ToolMap          = 8;

        public const int MainToolsNumber  = 9;

        public const int ToolPan = 9;


        private int _ActualTool;
        public int ActualTool
        {
            get
            {
                return _ActualTool;
            }
            set
            {
                if (!DesignMode)
                {
                    if (_ActualTool >= 0)
                    {
                        CanvasTools[_ActualTool].LeaveTool();
                    }

                    if (value >= 0)
                    {

                        CanvasTools[value].Initialize(this);

                        if (!CanvasTools[value].NeedsInput)
                        {
                            return;
                        }

                        Cursor = CanvasTools[value].Cursor;

                    }

                    _ActualTool = value;

                    Redraw();
                    Refresh();

                    if (_MainToolStrip != null && _ActualTool < MainToolsNumber)
                    {
                        MainToolStripToolsUnCheckAll();

                        ToolStripButton itm = (ToolStripButton)_MainToolStrip.Items[_ActualTool];

                        itm.Checked = true;
                    }
                }
                else
                {
                    _ActualTool = value;
                }
            }

        }

        public List<TomCanvasTool> CanvasTools = new List<TomCanvasTool>();
        private void CreateTools()
        {
            CanvasTools.Add(new TomCanvasToolSelect());
            CanvasTools.Add(new TomCanvasToolNode());
            CanvasTools.Add(new TomCanvasToolZoom());

            CanvasTools.Add(new TomCanvasToolDraw());
            CanvasTools.Add(new TomCanvasToolRectangle());
            CanvasTools.Add(new TomCanvasToolEllipse());
            CanvasTools.Add(new TomCanvasToolPolygon());
            CanvasTools.Add(new TomCanvasToolText());
            CanvasTools.Add(new TomCanvasToolMap());

            CanvasTools.Add(new TomCanvasToolPan());
        }
        #endregion

       
        public TomCanvasDocumentManager Document = new TomCanvasDocumentManager();

        public TomCanvasNodeListTool NodeListTool;
        public TomCanvasResizeRotator ResizeRotator;

        private bool _DrawFocusRectangle = false;
        private RectangleF _FocusRectangle = new Rectangle();

        #region CreateAndLoad

        private void SetStyle()
        {
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);
            SetStyle(ControlStyles.UserMouse, true);
        }

        public TomCanvas()
        {
            SetStyle();
            CreateTools();

            InitializeComponent();

            Document.PageSize.PaperKind = TomPaperKind.A4;
            this.MouseWheel += new MouseEventHandler(TomCanvas_MouseWheel);

            ResizeRotator = new TomCanvasResizeRotator(this);
            NodeListTool = new TomCanvasNodeListTool(this);

        }

        private ToolStrip _MainToolStrip;
        public ToolStrip MainToolStrip
        {
            get
            {
                return _MainToolStrip;
            }
            set
            {
                _MainToolStrip = value;
                PopulateMaintToolStrip();
            }
        }

        void PopulateMaintToolStrip()
        {
            if (_MainToolStrip == null) return;

            int ToolIndex = 0;

            for (int t = 0; t < TomCanvas.MainToolsNumber; t++)
            {

                TomCanvasTool tool = CanvasTools[t];

                ToolStripButton itm = (ToolStripButton)_MainToolStrip.Items.Add(tool.Icon);

                itm.ImageTransparentColor = Color.Magenta;
                itm.Name = ToolIndex.ToString();
                itm.ToolTipText = itm.ToString();

                itm.Click += new EventHandler(itm_Click);

                ToolIndex++;
            }
        }

        void itm_Click(object sender, EventArgs e)
        {

            ToolStripButton itm = (ToolStripButton)sender;
            int tool = Convert.ToInt32(itm.Name);

            if (CanvasTools[tool].NeedsInput)
            {
                MainToolStripToolsUnCheckAll();
                itm.Checked = true;
            }

            ActualTool = tool;
        }
        
        void MainToolStripToolsUnCheckAll()
        {
            foreach (ToolStripButton itm in _MainToolStrip.Items)
            {
                itm.Checked = false;
            }
        }

        private ToolStrip _SecondaryToolStrip;
        public ToolStrip SecondaryToolStrip
        {
            get
            {
                return _SecondaryToolStrip;
            }
            set
            {
                _SecondaryToolStrip = value;
            }
        }
        

        public void PageSetup()
        {
            Document.PageSize.PageSetup();

            ZoomPage();
        }

        private void TomCanvas_Load(object sender, EventArgs e)
        {
            ZoomPage();
        }
        #endregion

        #region ZoomManagement
        public void ZoomPage()
        {
            SizeF size = new SizeF(-1f, -1f);

            if (Document.HasPageSize)
            {
                size = Document.PageSize.Size;
            }
            else
            {
                MessageBox.Show("no page size!");
            }

            double w = (double)this.ClientRectangle.Width / (double)(size.Width * 1.10);
            double h = (double)this.ClientRectangle.Height / (double)(size.Height * 1.10);

            _MatrixRatio = (float)Math.Min(w, h);

            _MatrixOffset.X = (ClientRectangle.Width - size.Width * _MatrixRatio)/2.0f;
            _MatrixOffset.Y = (ClientRectangle.Height - size.Height * _MatrixRatio)/2.0f;

            Redraw();
            Invalidate();
            
        }


        public void ZoomAll()
        {
            RectangleF r = Document.LastList.GetRectangle();

            if (r.Width > 0 && r.Height > 0)
            {

                float f = Math.Max(r.Width / 20, r.Height / 20);

                r.Inflate(f, f);

                ZoomRect(r);
            }
        }

        public void ZoomSelected()
        {
            RectangleF r = Document.EditList.GetSelectedRectangle();

            if (r.Width > 0 && r.Height > 0)
            {

                float f = Math.Max(r.Width / 20, r.Height / 20);

                r.Inflate(f, f);

                ZoomRect(r);
            }
        }

        public void ZoomRect(RectangleF Rect)
        {
            double w = (double)this.ClientRectangle.Width / (double)(Rect.Width);
            double h = (double)this.ClientRectangle.Height / (double)(Rect.Height);

            _MatrixRatio = (float)Math.Min(w, h);

            _MatrixOffset.X = -Rect.X * _MatrixRatio;
            _MatrixOffset.Y = -Rect.Y * _MatrixRatio;

            Redraw();
            Refresh();

        }


        public void ZoomIn()
        {
            Point p = new Point(ClientRectangle.Width / 2, ClientRectangle.Height / 2);
            ZoomIn(p);
        }

        public void ZoomIn(Point point)
        {
            PointF p = PixelToView(point);

            //if (_MatrixRatio < 10000)
                _MatrixRatio *= 1.1f;
            //else
            //    _MatrixRatio = 10000;


            _MatrixOffset.X = point.X - p.X * _MatrixRatio;
            _MatrixOffset.Y = point.Y - p.Y * _MatrixRatio;

            Redraw();
            Refresh();
        }

        public void ZoomOut()
        {
            Point p = new Point(ClientRectangle.Width / 2, ClientRectangle.Height / 2);
            ZoomOut(p);
        }

        public void ZoomOut(Point point)
        {
            PointF p = PixelToView(point);

            //if (_MatrixRatio > 0.00000001f)
                _MatrixRatio /= 1.1f;
            //else
            //    _MatrixRatio = 0.00000001f;

            _MatrixOffset.X = point.X - p.X * _MatrixRatio;
            _MatrixOffset.Y = point.Y - p.Y * _MatrixRatio;

            Redraw();
            Refresh();
        }

        public void Pan(float dx, float dy)
        {
            _MatrixOffset.X += dx;
            _MatrixOffset.Y += dy;

            Redraw();
            Refresh();
        }
        #endregion

        private float _MatrixRatio = 1;
        private PointF _MatrixOffset = new PointF(0,0);

        private Matrix _DrawingMatrix = new Matrix();
        public Matrix DrawingMatrix
        {
            get
            {
                return _DrawingMatrix;
            }
            set
            {
                _DrawingMatrix = value;
            }
        }

        public Matrix InvertedMatrix
        {
            get
            {
                if (_DrawingMatrix.IsInvertible)
                {
                    Matrix im = _DrawingMatrix.Clone();
                    im.Invert();
                    return im;
                }

                return null;
            }

        }


        Bitmap DrawingImage = null;

        public RectangleF GetViewRectangle()
        {
            RectangleF r = new RectangleF(0, 0, ClientRectangle.Width, ClientRectangle.Height);

            return PixelToView(r);
        }

        public void Redraw()
        {
            if (DrawingImage != null)
            {
                DrawingImage.Dispose();
                DrawingImage = null;
            }

            DrawingImage = new Bitmap(ClientSize.Width, ClientSize.Height);

            _DrawingMatrix = new Matrix(_MatrixRatio, 0, 0, _MatrixRatio, _MatrixOffset.X, _MatrixOffset.Y);

            Graphics g = Graphics.FromImage(DrawingImage);

            g.Transform = _DrawingMatrix;

            SizeF sz = Document.PageSize.Size;

            //int shadow = (int)(Math.Min(sz.Width, sz.Height) / 100.0);

            //Bitmap bmp = new Bitmap((int)sz.Width, (int)sz.Height);

            //Graphics gShadow = Graphics.FromImage(bmp);

            //gShadow.FillRectangle(new SolidBrush(Color.Green), new Rectangle(0, 0, bmp.Width, bmp.Height));
            //ControlPaint.DrawImageDisabled(g, bmp, shadow, shadow, Color.Black);
            //gShadow.Dispose();

            g.FillRectangle(new SolidBrush(Color.White), 0f, 0f, sz.Width, sz.Height);

            Document.LastList.Draw(g);

            g.DrawRectangle(new Pen(Color.Black, 0f), 0f, 0f, sz.Width, sz.Height);

            g.Dispose();
         
            if (_ActualTool == ToolSelect)
            {
                if (Document.EditList.SelectionList.Count > 0)
                {
                    RectangleF rSelection = Document.EditList.GetSelectedRectangle();
                    ResizeRotator.Position = ViewToPixel(rSelection);
                    ResizeRotator.SetCenter(ViewToPixel(Document.EditList.GetSelectedCenter()));

                    //ResizeRotator.SetCenter(PageToPixel(Matematica.GetRectangleCenter(rSelection)));
                    
                    ResizeRotator.Visible = true;
                }
                else
                {
                    ResizeRotator.Visible = false;
                }
            }
            else
            {
                ResizeRotator.Visible = false;

                if (Document.EditList.SelectionList.Count > 0)
                {
                    RectangleF rSelection = ViewToPixel(Document.EditList.GetSelectedRectangle());
                    SetFocusRectangle(rSelection);
                }
            }
        }

        private void TomPageCanvas_Paint(object sender, PaintEventArgs e)
        {
            if (DrawingImage == null)
            {
                Redraw();
            }

            e.Graphics.DrawImage(DrawingImage, new Point(0, 0));


            Document.EditList.DrawDottedLines(e.Graphics, _DrawingMatrix);


            if (_DrawFocusRectangle)
            {
                _DrawFocusRectangle = false;

                Pen p = new Pen(Color.Red, 0f);
                p.DashStyle = DashStyle.Dash;

                //try
                //{
                    e.Graphics.DrawRectangle(p, _FocusRectangle.X, _FocusRectangle.Y, _FocusRectangle.Width, _FocusRectangle.Height);
                //}
                //catch
                //{
                    
                //}
                p.Dispose();


            }


            if (_ActualTool == ToolSelect | _ActualTool == ToolZoom)
            {
                NodeListTool.NodeClear();
            }
            else
            {
                if (ActualTool == ToolDraw)
                {
                    NodeListTool.PopulateEnds();
                }
                else
                {
                    if (!IsMovingNode) NodeListTool.Populate();
                }

            }

            NodeListTool.Draw(e.Graphics, _DrawingMatrix);


            if (ResizeRotator.Visible == true)
            {
                ResizeRotator.Draw(e.Graphics);
            }

         


        }

        #region TransformationBetweenPageViewAndPixel

        public PointF PixelToPage(PointF Pt)
        {
            return Document.PageSize.ToPageSize(PixelToView(Pt));
        }

        public PointF PageToPixel(PointF Pt)
        {
            return Document.PageSize.ToPrecisionSize(ViewToPixel(Pt));
        }

        public PointF PixelToView(PointF Pt)
        {
            PointF[] p = new PointF[] { Pt };

            InvertedMatrix.TransformPoints(p);

            return  p[0];
        }

        public PointF[] PixelToView(PointF [] Pts)
        {
            PointF[] p = Pts;

            InvertedMatrix.TransformPoints(p);
            
            return p;
        }
        
        public RectangleF PixelToView(RectangleF r)
        {

            PointF[] p = new PointF[] 
            {
                new PointF(r.X,r.Y),
                new PointF(r.X+r.Width,r.Y+r.Height)
            };

            InvertedMatrix.TransformPoints(p);

            RectangleF rc = Matematica.GetNormalizedRectangle(p[0], p[1]);

            return rc;

        }

        public PointF ViewToPixel(PointF Pt)
        {
            PointF[] p = new PointF[] { Pt };

            _DrawingMatrix.TransformPoints(p);

            return Document.PageSize.ToPrecisionSize(p[0]);
        }

        public PointF[] ViewToPixel(PointF[] Pts)
        {
            PointF[] p = Pts;

            _DrawingMatrix.TransformPoints(p);

            return p;
        }

        public RectangleF ViewToPixel(RectangleF rect)
        {
            PointF pt0 = ViewToPixel(new PointF(rect.X, rect.Y));
            PointF pt1 = ViewToPixel(new PointF(rect.X + rect.Width, rect.Y + rect.Height));

            return new RectangleF(pt0.X, pt0.Y, (pt1.X - pt0.X), (pt1.Y-pt0.Y));
        }

#endregion


        void TomCanvas_MouseWheel(object sender, MouseEventArgs e)
        {

            if (e.Delta > 0)
            {
                ZoomIn(new Point(e.X,e.Y));
            }
            else
            {
                ZoomOut(new Point(e.X,e.Y));
            }

        }


        private bool IsMovingNode = false;
        private int LastNodeHiligted = -1;

        private void TomCanvas_MouseDown(object sender, MouseEventArgs e)
        {
            int nodeindex = NodeListTool.HitTest(new PointF(e.X, e.Y));

            //if (nodeindex >= 0)
            //{
            //        if (nodeindex != LastNodeHiligted)
            //        {
            //            NodeListTool.HighligthNode(nodeindex, false);
            //        }

            //        NodeListTool.HighligthNode(nodeindex, true);
            //        LastNodeHiligted = nodeindex;
                    
            //}
            //else
            //{
                if (_ActualTool >= 0)
                {
                    CanvasTools[_ActualTool].MouseDown(e);
                }
            //}
        }

        private void TomCanvas_MouseMove(object sender, MouseEventArgs e)
        {

            if (_ActualTool >= 0 )
            {
                if (e.Button == MouseButtons.None)
                {
                    if (LastNodeHiligted >= 0)
                    {
                        NodeListTool.HighligthNode(LastNodeHiligted, false);
                        LastNodeHiligted = -1;
                    }

                    int nodeindex = NodeListTool.HitTest(new PointF(e.X, e.Y));
                    
                    if (nodeindex >= 0)
                    {
                        NodeListTool.HighligthNode(nodeindex, true);
                        LastNodeHiligted = nodeindex;
                    }

                }
                else
                {
                    if (ActualTool != ToolDraw)
                    {
                        if (LastNodeHiligted >= 0)
                        {
                            IsMovingNode = true;

                            NodeListTool.NodeMove(LastNodeHiligted, PixelToView(new PointF(e.X, e.Y)));

                            //int shapeI=NodeListTool.NodeList[LastNodeHiligted].ShapeIndex;
                            //int nodeI=NodeListTool.NodeList[LastNodeHiligted].NodeIndex;
                            //Document.EditList[shapeI].MoveNode(nodeI, PixelToPage(new PointF(e.X, e.Y)));

                            Refresh();
                        }
                    }
                }

              


            }

            if (!IsMovingNode)
            {
                CanvasTools[_ActualTool].MouseMove(e);
            }

           

        }

        private void TomCanvas_MouseUp(object sender, MouseEventArgs e)
        {
            if (IsMovingNode )
            {
                if (LastNodeHiligted >= 0 & ActualTool != ToolDraw)
                {
                        int shapeI = NodeListTool.NodeList[LastNodeHiligted].ShapeIndex;
                        int nodeI = NodeListTool.NodeList[LastNodeHiligted].NodeIndex;
                        Document.EditList[shapeI].MoveNode(nodeI, PixelToView(new PointF(e.X, e.Y)));
                        Document.PushEdit("Node editing", false);
                }

                LastNodeHiligted = -1;
                IsMovingNode = false;

                Redraw();
                Refresh();
                
            }
            else
            {
                if (_ActualTool >= 0)
                {
                    CanvasTools[_ActualTool].MouseUp(e);
                }
            }
        }

        public void SetFocusRectangle(PointF p1, PointF p2)
        {
            RectangleF rc = Matematica.GetNormalizedRectangle(p1, p2);

            SetFocusRectangle(rc);
        }

        public void SetFocusRectangle(RectangleF rc)
        {
            _FocusRectangle = rc;
            _DrawFocusRectangle = true;

        }

        private void TomCanvas_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

         
    }
}
