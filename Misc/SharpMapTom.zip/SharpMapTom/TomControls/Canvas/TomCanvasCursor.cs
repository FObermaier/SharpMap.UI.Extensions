﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;

namespace TomControls
{
    public static class TomCanvasCursors
    {
        public static Cursor Arrow;
        public static Cursor ArrowBlack;
        public static Cursor Node;
        public static Cursor NodeNSEW;
        public static Cursor Pan;
        public static Cursor Pencil;
        public static Cursor Zoom;
        public static Cursor Rotate;
        public static Cursor MoveNSEW;
        public static Cursor MoveNS;
        public static Cursor MoveEW;
        public static Cursor WarpNS;
        public static Cursor WarpEW;

        public static Cursor AddEllipse;
        public static Cursor AddRectangle;

        static TomCanvasCursors()
        {
            Arrow = new Cursor(new MemoryStream(Properties.Resources.CursorArrow));
            ArrowBlack = new Cursor(new MemoryStream(Properties.Resources.CursorArrowBlack));
            Node = new Cursor(new MemoryStream(Properties.Resources.CursorNode));
            NodeNSEW = new Cursor(new MemoryStream(Properties.Resources.CursorNodeNSEW));
            Pan = new Cursor(new MemoryStream(Properties.Resources.CursorPan));
            Pencil = new Cursor(new MemoryStream(Properties.Resources.CursorPencil));
            Zoom = new Cursor(new MemoryStream(Properties.Resources.CursorZoom));
            Rotate = new Cursor(new MemoryStream(Properties.Resources.CursorRotate));
            MoveNSEW = new Cursor(new MemoryStream(Properties.Resources.CursorMoveNSEW));
            MoveNS = new Cursor(new MemoryStream(Properties.Resources.CursorMoveNS));
            MoveEW = new Cursor(new MemoryStream(Properties.Resources.CursorMoveEW));
            WarpNS = new Cursor(new MemoryStream(Properties.Resources.CursorWarpNS));
            WarpEW = new Cursor(new MemoryStream(Properties.Resources.CursorWarpEW));
            AddEllipse = new Cursor(new MemoryStream(Properties.Resources.CursorAddEllipse));
            AddRectangle = new Cursor(new MemoryStream(Properties.Resources.CursorAddRectangle));
        }

       
    }
}
