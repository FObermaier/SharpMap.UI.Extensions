﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

namespace TomControls
{

    public enum TomPaperKind
    {
        [Description("Custom page Size")]
        CUSTOM = 0,
        A4 = 1,
        [Description("US Letter")]
        US_LETTER = 2,
        [Description("US Legal")]
        US_LEGAL = 3,

        [Description("US Executive")]
        US_EXECUTIVE = 4,
        A0 = 5,
        A1 = 6,
        A2 = 7,
        A3 = 8,
        A5 = 9,
        A6 = 10,
        A7 = 11,
        A8 = 12,
        A9 = 13,
        A10 = 14,

        B0 = 15,
        B1 = 16,
        B2 = 17,
        B3 = 18,
        B4 = 19,
        B5 = 20,
        B6 = 21,
        B7 = 22,
        B8 = 23,
        B9 = 24,
        B10 = 25,

        C0 = 26,
        C1 = 27,
        C2 = 28,
        C3 = 29,
        C4 = 30,
        C5 = 31,
        C6 = 32,
        C7 = 33,
        C8 = 34,
        C9 = 35,
        C10 = 36,

        [Description("ANSI A")]
        ANSI_A = 37,
        [Description("ANSI B")]
        ANSI_B = 38,
        [Description("ANSI C")]
        ANSI_C = 39,
        [Description("ANSI D")]
        ANSI_D = 40,
        [Description("ANSI E")]
        ANSI_E = 41,

        [Description("Arch A")]
        Arch_A = 42,
        [Description("Arch B")]
        Arch_B = 43,
        [Description("Arch C")]
        Arch_C = 44,
        [Description("Arch D")]
        Arch_D = 45,
        [Description("Arch E")]
        Arch_E = 46,
        [Description("Arch E1")]
        Arch_E1 = 47,
        [Description("Arch E2")]
        Arch_E2 = 48,
        [Description("Arch E3")]
        Arch_E3 = 49

     }

    public static class TomPaperKindTools
    {
        #region Sizes
        private static SizeF[] Sizes = new SizeF[]
        {
                new SizeF (0f,0f),                      //CUSTOM = 0,        
                new SizeF (210.0f,297.0f),              //A4 = 1,
                new SizeF (8.5f,11.0f),                 //US_LETTER = 2,
                new SizeF (8.5f,14.0f),                 //US_LEGAL = 3,
                new SizeF (7.2f,10.5f),                 //US_EXECUTIVE = 4,

                new SizeF (841.0f ,1189.0f),            //A0 = 5,
                new SizeF (594.0f ,841.0f),             //A1 = 6,
                new SizeF (420.0f ,594.0f),             //A2 = 7,
                new SizeF (297.0f ,420.0f),             //A3 = 8,

                new SizeF (148.0f ,210.0f),             //A5 = 9,
                new SizeF (105.0f ,148.0f),             //A6 = 10,
                new SizeF (74.0f ,105.0f),              //A7 = 11,
                new SizeF (52.0f ,74.0f),               //A8 = 12,
                new SizeF (37.0f ,52.0f),               //A9 = 13,
                new SizeF (26.0f ,37.0f),               //A10 = 14,

                new SizeF (1000.0f ,1414.0f),           //B0 = 15,
                new SizeF (707.0f ,1000.0f),            //B1 = 16,
                new SizeF (500.0f ,707.0f),             //B2 = 17,
                new SizeF (353.0f ,500.0f),             //B3 = 18,
                new SizeF (250.0f ,353.0f),             //B4 = 19,
                new SizeF (176.0f ,250.0f),             //B5 = 20,
                new SizeF (125.0f ,176.0f),             //B6 = 21,
                new SizeF (88.0f ,125.0f),              //B7 = 22,
                new SizeF (62.0f ,88.0f),               //B8 = 23,
                new SizeF (44.0f ,62.0f),               //B9 = 24,
                new SizeF (31.0f ,44.0f),               //B10 = 25,
        
                new SizeF (917.0f ,1297.0f),            //C0 = 26,
                new SizeF (648.0f ,917.0f),             //C1 = 27,
                new SizeF (458.0f ,648.0f),             //C2 = 28,
                new SizeF (324.0f ,458.0f),             //C3 = 29,
                new SizeF (229.0f ,324.0f),             //C4 = 30,
                new SizeF (162.0f ,229.0f),             //C5 = 31,
                new SizeF (114.0f ,162.0f),             //C6 = 32,
                new SizeF (81.0f ,114.0f),              //C7 = 33,
                new SizeF (57.0f ,81.0f),               //C8 = 34,
                new SizeF (40.0f ,57.0f),               //C9 = 35,
                new SizeF (28.0f ,40.0f),               //C10 = 36,
        
                new SizeF (8.5f,11.0f),                 //ANSI_A = 37,
                new SizeF (11.0f,17.0f),                //ANSI_B = 38,
                new SizeF (17.0f,22.0f),                //ANSI_C = 39,
                new SizeF (22.0f,34.0f),                //ANSI_D = 40,
                new SizeF (34.0f,44.0f),                //ANSI_E = 41,

                new SizeF ( 9.0f,12.0f),                //Arch_A = 42,
                new SizeF (12.0f,18.0f),                //Arch_B = 43,
                new SizeF (18.0f,24.0f),                //Arch_C = 44,
                new SizeF (24.0f,36.0f),                //Arch_D = 45,
                new SizeF (36.0f,48.0f),                //Arch_E = 46,
                new SizeF (30.0f,42.0f),                //Arch_E1 = 47,
                new SizeF (26.0f,38.0f),                //Arch_E2 = 48,
                new SizeF (27.0f,39.0f),                //Arch_E3 = 49,
        };

        private static GraphicsUnit[] Units = new GraphicsUnit[] 
        {
            GraphicsUnit.Millimeter,     //CUSTOM = 0,        
            GraphicsUnit.Millimeter,     //A4 = 1,
            GraphicsUnit.Inch      ,     //US_LETTER = 2,
            GraphicsUnit.Inch      ,     //US_LEGAL = 3,
            GraphicsUnit.Inch      ,     //US_EXECUTIVE = 4,

            GraphicsUnit.Millimeter,     //A0 = 5,
            GraphicsUnit.Millimeter,     //A1 = 6,
            GraphicsUnit.Millimeter,     //A2 = 7,
            GraphicsUnit.Millimeter,     //A3 = 8,

            GraphicsUnit.Millimeter,     //A5 = 9,
            GraphicsUnit.Millimeter,     //A6 = 10,
            GraphicsUnit.Millimeter,     //A7 = 11,
            GraphicsUnit.Millimeter,     //A8 = 12,
            GraphicsUnit.Millimeter,     //A9 = 13,
            GraphicsUnit.Millimeter,     //A10 = 14,

            GraphicsUnit.Millimeter,     //B0 = 15,
            GraphicsUnit.Millimeter,     //B1 = 16,
            GraphicsUnit.Millimeter,     //B2 = 17,
            GraphicsUnit.Millimeter,     //B3 = 18,
            GraphicsUnit.Millimeter,     //B4 = 19,
            GraphicsUnit.Millimeter,     //B5 = 20,
            GraphicsUnit.Millimeter,     //B6 = 21,
            GraphicsUnit.Millimeter,     //B7 = 22,
            GraphicsUnit.Millimeter,     //B8 = 23,
            GraphicsUnit.Millimeter,     //B9 = 24,
            GraphicsUnit.Millimeter,     //B10 = 25,

            GraphicsUnit.Millimeter,     //C0 = 26,
            GraphicsUnit.Millimeter,     //C1 = 27,
            GraphicsUnit.Millimeter,     //C2 = 28,
            GraphicsUnit.Millimeter,     //C3 = 29,
            GraphicsUnit.Millimeter,     //C4 = 30,
            GraphicsUnit.Millimeter,     //C5 = 31,
            GraphicsUnit.Millimeter,     //C6 = 32,
            GraphicsUnit.Millimeter,     //C7 = 33,
            GraphicsUnit.Millimeter,     //C8 = 34,
            GraphicsUnit.Millimeter,     //C9 = 35,
            GraphicsUnit.Millimeter,     //C10 = 36,

            GraphicsUnit.Inch      ,     //ANSI_A = 37,
            GraphicsUnit.Inch      ,     //ANSI_B = 38,
            GraphicsUnit.Inch      ,     //ANSI_C = 39,
            GraphicsUnit.Inch      ,     //ANSI_D = 40,
            GraphicsUnit.Inch      ,     //ANSI_E = 41,

            GraphicsUnit.Inch      ,     //Arch_A = 42,
            GraphicsUnit.Inch      ,     //Arch_B = 43,
            GraphicsUnit.Inch      ,     //Arch_C = 44,
            GraphicsUnit.Inch      ,     //Arch_D = 45,
            GraphicsUnit.Inch      ,     //Arch_E = 46,
            GraphicsUnit.Inch      ,     //Arch_E1 = 47,
            GraphicsUnit.Inch      ,     //Arch_E2 = 48,
            GraphicsUnit.Inch            //Arch_E3 = 49,
        };
        #endregion

        public static string GetDecoredName(TomPaperKind kind)
        {
            SizeF sz = GetSize(kind);
            GraphicsUnit un = GetUnit(kind);

            if (kind == TomPaperKind.CUSTOM) return "Custom page size";

            string k = EnumTools.GetEnumDescription(kind);

            if (k.Length > 10)
                k += "\t";
            else
                k += "\t\t";

            k += sz.Width.ToString() + " x " + sz.Height.ToString() + " ";



            if (un == GraphicsUnit.Millimeter)
                k += "mm";
            else
                k += "in";

            return k;
        }

        public static string GetName(TomPaperKind kind)
        {
            SizeF sz = GetSize(kind);
            GraphicsUnit un = GetUnit(kind);

            if (kind == TomPaperKind.CUSTOM) return "Custom page size";

            string k = EnumTools.GetEnumDescription(kind);

            return k;

        }
        public static SizeF GetSize(TomPaperKind paperKind)
        {

            int kind = (int)paperKind;

            if (kind == 0)
            {
                return new SizeF(-1, -1);
            }

            return Sizes[kind];
        }

        public static GraphicsUnit GetUnit(TomPaperKind paperKind)
        {
            int kind = (int)paperKind;
            return Units[kind];
        }

     
    }

    public class TomPageSize
    {
        private TomPaperKind _PaperKind = TomPaperKind.A4;
        public TomPaperKind PaperKind
        {
            get
            {
                return _PaperKind;
            }
            set
            {
                _PaperKind = value;
            }
        }

        private GraphicsUnit _Units = GraphicsUnit.Millimeter;
        public GraphicsUnit Units
        {
            get
            {
                if (PaperKind != TomPaperKind.CUSTOM)
                {
                    return TomPaperKindTools.GetUnit(_PaperKind);
                }
                else
                {
                    return _Units;
                }
            }
            set
            {
                if (_PaperKind == TomPaperKind.CUSTOM)
                {
                    _Units = value;
                }                
            }
        }

        private bool _Landscape = false;
        public bool Landscape
        {
            get
            {
                return _Landscape;
            }
            set
            {
                _Landscape = value;
            }
        }

        public float Precision = 100;
      
        private SizeF _Size = new SizeF(100.0f, 100.0f);
        public SizeF Size
        {
            get
            {
                if (PaperKind > TomPaperKind.CUSTOM)
                {

                    SizeF sz = TomPaperKindTools.GetSize(_PaperKind);

                    sz.Width *= Precision;
                    sz.Height *= Precision;

                    if (!_Landscape)
                    {
                        return sz;
                    }
                    else
                    {
                        return new SizeF(sz.Height, sz.Width);
                    }

                }
                else
                {
                    SizeF sz = _Size;

                    sz.Width *= Precision;
                    sz.Height *= Precision;

                    if (!_Landscape)
                    {
                        return sz;
                    }
                    else
                    {
                        return new SizeF(sz.Height, sz.Width);
                    }
                }

            }
            set
            {
                _Size = value;
            }
        }

        public RectangleF ToPageSize(RectangleF r)
        {

            r.X/=Precision;
            r.Y/=Precision;
            r.Width/=Precision;
            r.Height/=Precision;

            return r;

        }
        
        public PointF ToPageSize(PointF point)
        {
            point.X /= Precision;
            point.Y /= Precision;

            return point;
        }

        public SizeF ToPageSize(SizeF size)
        {
            size.Width /= Precision;
            size.Height /= Precision;

            return size;
        }


        public PointF[] ToPageSize(PointF[] points)
        {
            for (int i = 0; i < points.Count(); i++)
            {
                points[i].X /= Precision;
                points[i].Y /= Precision;
            }

            return points;
        }

        public RectangleF ToPrecisionSize(RectangleF r)
        {

            r.X *= Precision;
            r.Y *= Precision;
            r.Width *= Precision;
            r.Height *= Precision;

            return r;

        }

        public PointF ToPrecisionSize(PointF point)
        {
            point.X *= Precision;
            point.Y *= Precision;

            return point;
        }

        public SizeF ToPrecisionSize(SizeF size)
        {
            size.Width *= Precision;
            size.Height *= Precision;

            return size;
        }


        public PointF[] ToPrecisionSize(PointF[] points)
        {
            for (int i = 0; i < points.Count(); i++)
            {
                points[i].X *= Precision;
                points[i].Y *= Precision;
            }

            return points;
        }

        public void PageSetup()
        {
            FormPageSize frm = new FormPageSize();

            frm.PaperSize._PaperKind = _PaperKind;
            frm.PaperSize._Size = _Size;
            frm.PaperSize._Units = _Units;
            frm.PaperSize._Landscape = _Landscape; 
            
            
            if (frm.ShowDialog() == DialogResult.OK)
            {
                _PaperKind = frm.PaperSize.PaperKind;
                _Size = frm.PaperSize.Size;
                _Units = frm.PaperSize.Units;
                _Landscape = frm.PaperSize.Landscape;
            }
        }

        //public SizeF GetSizeMicron()
        //{

        //    SizeF SzMM = Size;

        //    if (_Units == GraphicsUnit.Inch)
        //    {
        //        SzMM.Width *= 25.4f;
        //        SzMM.Height *= 25.4f;
        //    }

        //    SzMM.Width *= 1000;
        //    SzMM.Height *= 1000;

        //    return SzMM;
        //}
    }
    
   

}
